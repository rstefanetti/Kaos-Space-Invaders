using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;

namespace SpaceInvaders.GraphicsMode
{
    /// <summary>
    /// Chat UI in stile fumetto per parlare con Cortana
    /// Risponde a domande su controlli, powerup, nemici, punteggio
    /// </summary>
    public class CortanaChatUI
    {
        // UI Properties
        private bool _isVisible;
        private Rectangle _chatBounds;
        private List<ChatMessage> _messages;
        private string _currentInput;
        private int _cursorBlinkFrame;
        private bool _showCursor;
        
        // Auto-hide timer
        private int _idleFrames;
        private const int AutoHideAfterFrames = 900; // 30 secondi a 30 FPS
        
        // Layout
        private const int ChatWidth = 300;
        private const int ChatHeight = 200;
        private const int MessageHeight = 20;
        private const int MaxMessages = 8;
        
        // Reference to game engine for contextual responses
        private GameEngine? _gameEngine;
        
        // Events
        public event Action<string>? OnUserMessage;
        public event Action<string>? OnCortanaResponse;

        public bool IsVisible => _isVisible;

        public CortanaChatUI()
        {
            _messages = new List<ChatMessage>();
            _currentInput = "";
            _isVisible = false;
            _cursorBlinkFrame = 0;
            _showCursor = true;
            _idleFrames = 0;
            
            // Messaggio di benvenuto
            AddCortanaMessage("Ciao! Premi 'C' per parlare con me. Chiedi 'help' per i comandi!");
        }

        public void SetGameEngine(GameEngine? engine)
        {
            _gameEngine = engine;
        }

        public void Toggle()
        {
            _isVisible = !_isVisible;
            _idleFrames = 0;
            
            if (_isVisible)
            {
                AddCortanaMessage("Come posso aiutarti? 💙");
            }
        }

        public void Show()
        {
            _isVisible = true;
            _idleFrames = 0;
        }

        public void Hide()
        {
            _isVisible = false;
        }

        public void Update()
        {
            if (!_isVisible) return;

            // Cursor blink animation
            _cursorBlinkFrame++;
            if (_cursorBlinkFrame >= 20) // Blink ogni 20 frame
            {
                _showCursor = !_showCursor;
                _cursorBlinkFrame = 0;
            }

            // Auto-hide dopo inattività
            _idleFrames++;
            if (_idleFrames >= AutoHideAfterFrames)
            {
                Hide();
                AddCortanaMessage("Mi hai dimenticato? Premi 'C' se hai bisogno di me!");
            }
        }

        public void HandleKeyPress(char key)
        {
            if (!_isVisible) return;

            _idleFrames = 0; // Reset idle timer

            if (key == '\b') // Backspace
            {
                if (_currentInput.Length > 0)
                {
                    _currentInput = _currentInput.Substring(0, _currentInput.Length - 1);
                }
            }
            else if (key == '\r' || key == '\n') // Enter
            {
                if (!string.IsNullOrWhiteSpace(_currentInput))
                {
                    ProcessUserInput(_currentInput.Trim());
                    _currentInput = "";
                }
            }
            else if (!char.IsControl(key))
            {
                if (_currentInput.Length < 50) // Max 50 caratteri
                {
                    _currentInput += key;
                }
            }
        }

        private void ProcessUserInput(string input)
        {
            // Aggiungi messaggio utente
            AddUserMessage(input);
            OnUserMessage?.Invoke(input);

            // Genera risposta Cortana
            string response = GenerateAIResponse(input.ToLower());
            AddCortanaMessage(response);
            OnCortanaResponse?.Invoke(response);
        }

        private string GenerateAIResponse(string input)
        {
            // Pattern matching per risposte contestuali

            // Help
            if (input.Contains("help") || input.Contains("aiuto") || input.Contains("comandi"))
            {
                return "Puoi chiedere: 'controlli', 'powerup', 'nemici', 'punteggio', 'meteo', 'yoda'";
            }

            // Controlli
            if (input.Contains("control") || input.Contains("tasti") || input.Contains("muov"))
            {
                return "Usa ← → o Mouse per muoverti, SPACE per sparare! Joystick supportato 🎮";
            }

            // Powerup
            if (input.Contains("power") || input.Contains("cuor") || input.Contains("doppio"))
            {
                return "❤️ Cuori guariscono scudi. 🔫 Doppio colpo dura 10 secondi!";
            }

            // Nemici
            if (input.Contains("nemic") || input.Contains("alien") || input.Contains("snake") || input.Contains("punt"))
            {
                return "👾 Alieni: 50/30/20 punti. 🐍 Snake: 1000 punti! 🛸 UFO: 100-500 punti!";
            }

            // Punteggio
            if (input.Contains("score") || input.Contains("punteggio") || input.Contains("quanto"))
            {
                if (_gameEngine != null)
                {
                    return $"Hai {_gameEngine.Player.Score} punti! 🎯 Livello {_gameEngine.CurrentLevel}";
                }
                return "Guarda in alto per il punteggio! 🎯";
            }

            // Meteo
            if (input.Contains("meteo") || input.Contains("tempo") || input.Contains("fulmin") || input.Contains("pioggia"))
            {
                return "⚡ Fulmini ogni 20s colpiscono alieni! 🌧️ Pioggia→Arcobaleno 🌈 Vento muove scudi";
            }

            // Yoda
            if (input.Contains("yoda") || input.Contains("jedi") || input.Contains("vita"))
            {
                return "Con 1 sola vita, Maestro YODA appare e ti regala una vita extra! 💚";
            }

            // Pac-Man
            if (input.Contains("pac") || input.Contains("insegue") || input.Contains("fantasma"))
            {
                return "Pac-Man ti insegue! Arriva a bordo schermo per scappare! 😱";
            }

            // Gandalf
            if (input.Contains("gandalf") || input.Contains("mago") || input.Contains("serpent"))
            {
                return "GANDALF appare casualmente e blocca i serpenti! 🧙‍♂️ 'Non passerete!'";
            }

            // Obi-Wan
            if (input.Contains("obi") || input.Contains("kenobi") || input.Contains("spada"))
            {
                return "Obi-Wan Kenobi appare col Game Over e usa la spada laser! May the Force be with you! ⚔️";
            }

            // Pausa
            if (input.Contains("pausa") || input.Contains("stop") || input.Contains("ferma"))
            {
                return "Premi P o il pulsante in alto a sinistra per mettere in pausa! ⏸️";
            }

            // Salvataggio
            if (input.Contains("salva") || input.Contains("save") || input.Contains("carica") || input.Contains("load"))
            {
                return "Usa F5 per salvare, F9 per caricare! Pulsanti in alto a destra 💾";
            }

            // Vite
            if (input.Contains("vit") || input.Contains("life"))
            {
                if (_gameEngine != null)
                {
                    return $"Hai {_gameEngine.Player.Lives} vite! ❤️";
                }
                return "Guarda in alto per le tue vite! ❤️";
            }

            // Scudi
            if (input.Contains("scud") || input.Contains("shield") || input.Contains("barriera"))
            {
                return "Gli scudi ti proteggono! Usa i cuori ❤️ per ripararli";
            }

            // Saluti
            if (input.Contains("ciao") || input.Contains("hello") || input.Contains("hi"))
            {
                return "Ciao comandante! 💙 Come posso aiutarti?";
            }

            if (input.Contains("grazie") || input.Contains("thanks"))
            {
                return "Prego! Sono qui per aiutarti! 💙";
            }

            // Default
            return "Non ho capito... Prova 'help' per vedere cosa posso fare! 🤔";
        }

        private void AddUserMessage(string text)
        {
            _messages.Add(new ChatMessage
            {
                Text = text,
                IsUser = true,
                Timestamp = DateTime.Now
            });

            // Mantieni solo gli ultimi MaxMessages
            if (_messages.Count > MaxMessages)
            {
                _messages.RemoveAt(0);
            }
        }

        private void AddCortanaMessage(string text)
        {
            _messages.Add(new ChatMessage
            {
                Text = text,
                IsUser = false,
                Timestamp = DateTime.Now
            });

            // Mantieni solo gli ultimi MaxMessages
            if (_messages.Count > MaxMessages)
            {
                _messages.RemoveAt(0);
            }
        }

        public void Draw(System.Drawing.Graphics g, int screenWidth, int screenHeight)
        {
            if (!_isVisible) return;

            // Posizione: lato destro dello schermo, a fianco di Cortana
            int chatX = screenWidth - ChatWidth - 20;
            int chatY = 100;

            _chatBounds = new Rectangle(chatX, chatY, ChatWidth, ChatHeight);

            // Disegna fumetto con bordo arrotondato
            DrawSpeechBubble(g, _chatBounds);

            // Disegna messaggi
            DrawMessages(g, chatX, chatY);

            // Disegna input box
            DrawInputBox(g, chatX, chatY + ChatHeight - 40);

            // Disegna hint
            DrawHint(g, chatX, chatY - 20);
        }

        private void DrawSpeechBubble(System.Drawing.Graphics g, Rectangle bounds)
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;

            // Background fumetto
            using (GraphicsPath path = CreateRoundedRectangle(bounds, 15))
            {
                // Riempimento con gradiente
                using (var brush = new LinearGradientBrush(
                    bounds,
                    Color.FromArgb(230, 20, 30, 60),
                    Color.FromArgb(230, 10, 15, 30),
                    LinearGradientMode.Vertical))
                {
                    g.FillPath(brush, path);
                }

                // Bordo fluorescente cyan (stile Cortana)
                using (var pen = new Pen(Color.FromArgb(200, 0, 200, 255), 3))
                {
                    g.DrawPath(pen, path);
                }

                // Glow esterno
                using (var glowPen = new Pen(Color.FromArgb(100, 0, 200, 255), 6))
                {
                    g.DrawPath(glowPen, path);
                }
            }

            // Codina del fumetto (punta verso Cortana, sinistra)
            Point[] tail = new Point[]
            {
                new Point(bounds.Left, bounds.Top + 30),
                new Point(bounds.Left - 20, bounds.Top + 20),
                new Point(bounds.Left, bounds.Top + 40)
            };

            using (var brush = new SolidBrush(Color.FromArgb(230, 20, 30, 60)))
            {
                g.FillPolygon(brush, tail);
            }

            using (var pen = new Pen(Color.FromArgb(200, 0, 200, 255), 2))
            {
                g.DrawPolygon(pen, tail);
            }
        }

        private void DrawMessages(System.Drawing.Graphics g, int x, int y)
        {
            int messageY = y + 10;

            foreach (var msg in _messages.TakeLast(MaxMessages))
            {
                Color textColor = msg.IsUser ? Color.LightGreen : Color.Cyan;
                string prefix = msg.IsUser ? "Tu: " : "Cortana: ";

                using (var font = new Font("Arial", 9, FontStyle.Bold))
                using (var brush = new SolidBrush(textColor))
                {
                    // Wrappa testo se troppo lungo
                    string displayText = prefix + msg.Text;
                    if (displayText.Length > 40)
                    {
                        displayText = displayText.Substring(0, 37) + "...";
                    }

                    g.DrawString(displayText, font, brush, x + 10, messageY);
                }

                messageY += MessageHeight;

                // Non disegnare oltre il bounds
                if (messageY > y + ChatHeight - 50)
                    break;
            }
        }

        private void DrawInputBox(System.Drawing.Graphics g, int x, int y)
        {
            Rectangle inputBox = new Rectangle(x + 10, y, ChatWidth - 20, 30);

            // Background input
            using (var brush = new SolidBrush(Color.FromArgb(200, 0, 0, 0)))
            {
                g.FillRectangle(brush, inputBox);
            }

            // Bordo
            using (var pen = new Pen(Color.Cyan, 2))
            {
                g.DrawRectangle(pen, inputBox);
            }

            // Testo input
            using (var font = new Font("Consolas", 10))
            using (var brush = new SolidBrush(Color.White))
            {
                string displayText = _currentInput;
                if (_showCursor)
                {
                    displayText += "|";
                }

                g.DrawString(displayText, font, brush, inputBox.X + 5, inputBox.Y + 7);
            }
        }

        private void DrawHint(System.Drawing.Graphics g, int x, int y)
        {
            string hint = "Premi C per chiudere | Enter per inviare";

            using (var font = new Font("Arial", 8, FontStyle.Italic))
            using (var brush = new SolidBrush(Color.FromArgb(150, 255, 255, 255)))
            {
                g.DrawString(hint, font, brush, x, y);
            }
        }

        private GraphicsPath CreateRoundedRectangle(Rectangle bounds, int radius)
        {
            GraphicsPath path = new GraphicsPath();
            int diameter = radius * 2;

            path.AddArc(bounds.X, bounds.Y, diameter, diameter, 180, 90);
            path.AddArc(bounds.Right - diameter, bounds.Y, diameter, diameter, 270, 90);
            path.AddArc(bounds.Right - diameter, bounds.Bottom - diameter, diameter, diameter, 0, 90);
            path.AddArc(bounds.X, bounds.Bottom - diameter, diameter, diameter, 90, 90);
            path.CloseFigure();

            return path;
        }

        private class ChatMessage
        {
            public string Text { get; set; } = "";
            public bool IsUser { get; set; }
            public DateTime Timestamp { get; set; }
        }
    }
}
