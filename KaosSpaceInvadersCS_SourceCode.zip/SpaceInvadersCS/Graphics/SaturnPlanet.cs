using System;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace SpaceInvaders.GraphicsMode;

/// <summary>
/// Pianeta Saturno con anelli in alto a sinistra
/// </summary>
public class SaturnPlanet
{
    private float _rotation;
    private float _ringRotation;
    private readonly Random _random;
    
    public SaturnPlanet()
    {
        _rotation = 0f;
        _ringRotation = 0f;
        _random = new Random();
    }
    
    public void Update()
    {
        // Rotazione lenta del pianeta
        _rotation += 0.15f;
        if (_rotation >= 360f) _rotation -= 360f;
        
        // Rotazione degli anelli (leggermente diversa per effetto dinamico)
        _ringRotation += 0.08f;
        if (_ringRotation >= 360f) _ringRotation -= 360f;
    }
    
    public void Draw(Graphics g, int screenWidth, int screenHeight)
    {
        g.SmoothingMode = SmoothingMode.AntiAlias;
        
        int saturnSize = 120;
        int saturnX = 80; // Alto a sinistra
        int saturnY = 60;
        
        // Salva stato grafico
        var state = g.Save();
        
        // Centro di rotazione
        int centerX = saturnX + saturnSize / 2;
        int centerY = saturnY + saturnSize / 2;
        
        // Disegna gli anelli DIETRO al pianeta (parte inferiore)
        DrawRingsBack(g, saturnX, saturnY, saturnSize);
        
        // Applica rotazione al pianeta
        g.TranslateTransform(centerX, centerY);
        g.RotateTransform(_rotation);
        g.TranslateTransform(-centerX, -centerY);
        
        // Disegna il corpo di Saturno
        DrawSaturnBody(g, saturnX, saturnY, saturnSize);
        
        // Ripristina trasformazione
        g.Restore(state);
        
        // Disegna gli anelli DAVANTI al pianeta (parte superiore)
        DrawRingsFront(g, saturnX, saturnY, saturnSize);
        
        // Glow attorno a Saturno
        DrawGlow(g, saturnX, saturnY, saturnSize);
    }
    
    private void DrawSaturnBody(Graphics g, int x, int y, int size)
    {
        // Corpo di Saturno con gradiente giallo-oro con bande
        using var saturnPath = new GraphicsPath();
        saturnPath.AddEllipse(x, y, size, size);
        
        using var saturnBrush = new LinearGradientBrush(
            new Rectangle(x, y, size, size),
            Color.FromArgb(255, 230, 180, 100), // Giallo dorato chiaro
            Color.FromArgb(255, 200, 150, 80),  // Giallo dorato scuro
            LinearGradientMode.Vertical
        );
        g.FillPath(saturnBrush, saturnPath);
        
        // Bande atmosferiche di Saturno (strisce orizzontali)
        using var bandBrush1 = new SolidBrush(Color.FromArgb(80, 180, 130, 70));
        using var bandBrush2 = new SolidBrush(Color.FromArgb(60, 210, 170, 100));
        
        // Bande più scure
        g.FillEllipse(bandBrush1, x + size/8, y + size/3, size*3/4, size/10);
        g.FillEllipse(bandBrush1, x + size/10, y + size/2, size*4/5, size/12);
        g.FillEllipse(bandBrush1, x + size/6, y + size*2/3, size*2/3, size/8);
        
        // Bande più chiare
        g.FillEllipse(bandBrush2, x + size/10, y + size/4, size*4/5, size/15);
        g.FillEllipse(bandBrush2, x + size/8, y + size*3/5, size*3/4, size/10);
        
        // Grande macchia esagonale al polo nord (caratteristica di Saturno)
        DrawHexagonStorm(g, x + size/2, y + size/6, size/8);
        
        // Ombreggiatura per effetto 3D (lato destro più scuro)
        using var shadowPath = new GraphicsPath();
        shadowPath.AddEllipse(x, y, size, size);
        using var shadowBrush = new PathGradientBrush(shadowPath);
        shadowBrush.CenterPoint = new PointF(x + size * 0.3f, y + size * 0.4f);
        shadowBrush.CenterColor = Color.Transparent;
        shadowBrush.SurroundColors = new[] { Color.FromArgb(100, 0, 0, 0) };
        g.FillPath(shadowBrush, shadowPath);
    }
    
    private void DrawHexagonStorm(Graphics g, int centerX, int centerY, int radius)
    {
        // Tempesta esagonale al polo nord di Saturno
        Point[] hexagon = new Point[6];
        for (int i = 0; i < 6; i++)
        {
            float angle = (float)(Math.PI / 3 * i - Math.PI / 2);
            hexagon[i] = new Point(
                centerX + (int)(radius * Math.Cos(angle)),
                centerY + (int)(radius * Math.Sin(angle))
            );
        }
        
        using var stormBrush = new SolidBrush(Color.FromArgb(120, 150, 100, 60));
        g.FillPolygon(stormBrush, hexagon);
        
        using var stormPen = new Pen(Color.FromArgb(150, 180, 130, 70), 2);
        g.DrawPolygon(stormPen, hexagon);
    }
    
    private void DrawRingsBack(Graphics g, int x, int y, int size)
    {
        // Parte degli anelli che passa DIETRO al pianeta
        int centerX = x + size / 2;
        int centerY = y + size / 2;
        
        // Clip per disegnare solo la parte inferiore (dietro)
        var clipRegion = new Region(new Rectangle(x - 50, centerY, size + 100, size));
        g.SetClip(clipRegion, CombineMode.Intersect);
        
        DrawRings(g, centerX, centerY, size, false);
        
        // Rimuovi clip
        g.ResetClip();
    }
    
    private void DrawRingsFront(Graphics g, int x, int y, int size)
    {
        // Parte degli anelli che passa DAVANTI al pianeta
        int centerX = x + size / 2;
        int centerY = y + size / 2;
        
        // Clip per disegnare solo la parte superiore (davanti)
        var clipRegion = new Region(new Rectangle(x - 50, y - 50, size + 100, centerY - y + 50));
        g.SetClip(clipRegion, CombineMode.Intersect);
        
        DrawRings(g, centerX, centerY, size, true);
        
        // Rimuovi clip
        g.ResetClip();
    }
    
    private void DrawRings(Graphics g, int centerX, int centerY, int planetSize, bool isFront)
    {
        // Anelli di Saturno (ellissi con prospettiva)
        int ringWidth = (int)(planetSize * 2.0f);
        int ringHeight = (int)(planetSize * 0.5f); // Prospettiva schiacciata
        
        // Ring A (più esterno, più chiaro)
        using (var ringABrush = new SolidBrush(Color.FromArgb(180, 200, 180, 150)))
        {
            g.FillEllipse(ringABrush, 
                centerX - ringWidth/2, 
                centerY - ringHeight/2, 
                ringWidth, 
                ringHeight);
        }
        
        // Ring B (medio, più scuro)
        int ringBWidth = (int)(ringWidth * 0.85f);
        int ringBHeight = (int)(ringHeight * 0.85f);
        using (var ringBBrush = new SolidBrush(Color.FromArgb(200, 190, 170, 140)))
        {
            g.FillEllipse(ringBBrush, 
                centerX - ringBWidth/2, 
                centerY - ringBHeight/2, 
                ringBWidth, 
                ringBHeight);
        }
        
        // Cassini Division (gap scuro tra gli anelli)
        int cassiniWidth = (int)(ringWidth * 0.75f);
        int cassiniHeight = (int)(ringHeight * 0.75f);
        using (var cassiniPen = new Pen(Color.FromArgb(100, 20, 20, 20), 3))
        {
            g.DrawEllipse(cassiniPen, 
                centerX - cassiniWidth/2, 
                centerY - cassiniHeight/2, 
                cassiniWidth, 
                cassiniHeight);
        }
        
        // Ring C (più interno, trasparente)
        int ringCWidth = (int)(ringWidth * 0.65f);
        int ringCHeight = (int)(ringHeight * 0.65f);
        using (var ringCBrush = new SolidBrush(Color.FromArgb(120, 160, 150, 130)))
        {
            g.FillEllipse(ringCBrush, 
                centerX - ringCWidth/2, 
                centerY - ringCHeight/2, 
                ringCWidth, 
                ringCHeight);
        }
        
        // Rimuovi il centro per creare l'effetto anello
        // (disegna ellisse nera al centro per "bucare" gli anelli)
        int innerWidth = (int)(planetSize * 1.05f);
        int innerHeight = (int)(planetSize * 0.26f);
        using (var innerBrush = new SolidBrush(Color.FromArgb(5, 5, 20))) // Colore spazio
        {
            g.FillEllipse(innerBrush, 
                centerX - innerWidth/2, 
                centerY - innerHeight/2, 
                innerWidth, 
                innerHeight);
        }
        
        // Aggiungi dettagli degli anelli (particelle e variazioni)
        if (isFront)
        {
            // Piccole variazioni di colore negli anelli per realismo
            for (int i = 0; i < 5; i++)
            {
                float angle = _random.Next(360);
                int particleX = centerX + (int)(Math.Cos(angle) * ringWidth * 0.4f);
                int particleY = centerY + (int)(Math.Sin(angle) * ringHeight * 0.4f);
                
                using var particleBrush = new SolidBrush(Color.FromArgb(100, 220, 200, 180));
                g.FillEllipse(particleBrush, particleX, particleY, 3, 2);
            }
        }
    }
    
    private void DrawGlow(Graphics g, int x, int y, int size)
    {
        // Glow luminoso attorno a Saturno
        using var glowPath = new GraphicsPath();
        glowPath.AddEllipse(x - 15, y - 15, size + 30, size + 30);
        
        using var glowBrush = new PathGradientBrush(glowPath);
        glowBrush.CenterPoint = new PointF(x + size/2, y + size/2);
        glowBrush.CenterColor = Color.FromArgb(20, 255, 230, 180);
        glowBrush.SurroundColors = new[] { Color.FromArgb(0, 0, 0, 0) };
        
        g.FillPath(glowBrush, glowPath);
    }
}
