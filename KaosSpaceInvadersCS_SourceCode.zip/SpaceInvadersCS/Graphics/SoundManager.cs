using System.Media;

namespace SpaceInvaders.GraphicsMode;

public class SoundManager
{
    private readonly Dictionary<string, SoundPlayer> _sounds;
    private bool _soundEnabled;
    private float _volume; // 0.0 to 1.0
    private CancellationTokenSource? _heartbeatCancellation;
    private Task? _heartbeatTask;
    
    public bool SoundEnabled
    {
        get => _soundEnabled;
        set => _soundEnabled = value;
    }
    
    public float Volume
    {
        get => _volume;
        set => _volume = Math.Clamp(value, 0f, 1f);
    }
    
    public SoundManager()
    {
        _sounds = new Dictionary<string, SoundPlayer>();
        _soundEnabled = true;
        _volume = 0.5f; // Default 50% volume
        InitializeSounds();
    }
    
    private void InitializeSounds()
    {
        // We'll generate simple beep sounds programmatically
        // In a full implementation, you would load .wav files
        try
        {
            // These would be actual .wav files in a real game
            // For now, we'll use Console.Beep as fallback
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Warning: Could not initialize sounds: {ex.Message}");
            _soundEnabled = false;
        }
    }
    
    public void PlayShoot()
    {
        if (!_soundEnabled || _volume <= 0) return;
        
        Task.Run(() =>
        {
            try
            {
                int duration = (int)(50 * _volume);
                if (duration > 0)
                    Console.Beep(800, duration); // High pitched short beep
            }
            catch { }
        });
    }
    
    public void PlayExplosion()
    {
        if (!_soundEnabled || _volume <= 0) return;
        
        Task.Run(() =>
        {
            try
            {
                int duration = (int)(100 * _volume);
                if (duration > 0)
                    Console.Beep(200, duration); // Low pitched explosion
            }
            catch { }
        });
    }
    
    public void PlayAlienShoot()
    {
        if (!_soundEnabled || _volume <= 0) return;
        
        Task.Run(() =>
        {
            try
            {
                int duration = (int)(80 * _volume);
                if (duration > 0)
                    Console.Beep(400, duration); // Medium pitched
            }
            catch { }
        });
    }
    
    public void PlayHit()
    {
        if (!_soundEnabled || _volume <= 0) return;
        
        Task.Run(() =>
        {
            try
            {
                int duration = (int)(150 * _volume);
                if (duration > 0)
                    Console.Beep(300, duration); // Damage sound
            }
            catch { }
        });
    }
    
    public void PlayUFO()
    {
        if (!_soundEnabled || _volume <= 0) return;
        
        Task.Run(() =>
        {
            try
            {
                // Wavy mysterious UFO sound
                int duration = (int)(80 * _volume);
                if (duration > 0)
                {
                    for (int i = 0; i < 3; i++)
                    {
                        Console.Beep(600, duration);
                        Thread.Sleep(20);
                        Console.Beep(700, duration);
                        Thread.Sleep(20);
                    }
                }
            }
            catch { }
        });
    }
    
    public void PlayGameOver()
    {
        if (!_soundEnabled || _volume <= 0) return;
        
        Task.Run(() =>
        {
            try
            {
                int duration1 = (int)(200 * _volume);
                int duration2 = (int)(400 * _volume);
                if (duration1 > 0)
                {
                    Console.Beep(400, duration1);
                    Thread.Sleep(50);
                    Console.Beep(300, duration1);
                    Thread.Sleep(50);
                    Console.Beep(200, duration2);
                }
            }
            catch { }
        });
    }
    
    public void PlayVictory()
    {
        if (!_soundEnabled || _volume <= 0) return;
        
        Task.Run(() =>
        {
            try
            {
                int duration = (int)(150 * _volume);
                int duration2 = (int)(400 * _volume);
                if (duration > 0)
                {
                    Console.Beep(523, duration); // C
                    Thread.Sleep(50);
                    Console.Beep(659, duration); // E
                    Thread.Sleep(50);
                    Console.Beep(784, duration); // G
                    Thread.Sleep(50);
                    Console.Beep(1047, duration2); // High C
                }
            }
            catch { }
        });
    }
    
    public void StartHeartbeat(int alienCount)
    {
        StopHeartbeat();
        
        _heartbeatCancellation = new CancellationTokenSource();
        var token = _heartbeatCancellation.Token;
        
        _heartbeatTask = Task.Run(async () =>
        {
            try
            {
                while (!token.IsCancellationRequested && _soundEnabled)
                {
                    // Calculate interval based on alien count (faster with fewer aliens)
                    // 55 aliens = 800ms, 1 alien = 200ms
                    int interval = Math.Max(200, 200 + (alienCount * 11));
                    
                    // Two-tone heartbeat: low-high
                    Console.Beep(150, 100); // Low boom
                    await Task.Delay(50, token);
                    Console.Beep(200, 100); // Higher boom
                    await Task.Delay(interval, token);
                }
            }
            catch (TaskCanceledException) { }
            catch { }
        }, token);
    }
    
    public void StopHeartbeat()
    {
        _heartbeatCancellation?.Cancel();
        _heartbeatTask?.Wait(100);
        _heartbeatCancellation?.Dispose();
        _heartbeatCancellation = null;
    }
    
    public void StopAll()
    {
        foreach (var sound in _sounds.Values)
        {
            sound?.Stop();
        }
    }
    
    public void Dispose()
    {
        StopHeartbeat();
        StopAll();
        foreach (var sound in _sounds.Values)
        {
            sound?.Dispose();
        }
        _sounds.Clear();
    }
}
