using System;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace SpaceInvaders.GraphicsMode;

// Earth background view from space with stars
public class EarthBackground
{
    private readonly Random _random;
    private readonly List<Star> _stars;
    private readonly List<Cloud> _clouds;
    private readonly List<BackgroundUFO> _ufos;
    private float _earthRotation;
    
    private class Star
    {
        public float X { get; set; }
        public float Y { get; set; }
        public float Size { get; set; }
        public float Brightness { get; set; }
        public float TwinkleSpeed { get; set; }
        public float TwinklePhase { get; set; }
        public float MoveSpeed { get; set; } // Velocità di movimento orizzontale
        public float Layer { get; set; } // Layer di profondità (0=lontano, 1=vicino) per parallax
    }
    
    private class Cloud
    {
        public float X { get; set; }
        public float Y { get; set; }
        public float Width { get; set; }
        public float Height { get; set; }
        public float Speed { get; set; }
        public float Opacity { get; set; }
    }
    
    private class BackgroundUFO
    {
        public float Angle { get; set; } // Angolo per orbita ellittica
        public float Speed { get; set; }
        public float OrbitRadiusX { get; set; }
        public float OrbitRadiusY { get; set; }
    }
    
    public EarthBackground()
    {
        _random = new Random(42); // Fixed seed for consistent stars
        _stars = new List<Star>();
        _clouds = new List<Cloud>();
        _ufos = new List<BackgroundUFO>();
        _earthRotation = 0;
        
        // Generate star field with parallax movement (3 layers)
        for (int i = 0; i < 200; i++)
        {
            float layer = (float)_random.NextDouble(); // 0 = lontano, 1 = vicino
            _stars.Add(new Star
            {
                X = (float)_random.NextDouble(),
                Y = (float)_random.NextDouble(),
                Size = 1f + layer * 2f, // Stelle vicine più grandi
                Brightness = 0.3f + (float)_random.NextDouble() * 0.7f,
                TwinkleSpeed = 0.01f + (float)_random.NextDouble() * 0.05f,
                TwinklePhase = (float)_random.NextDouble() * (float)Math.PI * 2,
                MoveSpeed = 0.0001f + layer * 0.0008f, // Stelle vicine si muovono più veloci (parallax)
                Layer = layer
            });
        }
        
        // Generate cloud layers (3 layers with different speeds)
        for (int layer = 0; layer < 3; layer++)
        {
            int cloudCount = 5 + _random.Next(5); // 5-10 clouds per layer
            float speed = (layer + 1) * 0.3f; // Near clouds move faster
            float opacity = 0.15f + (layer * 0.05f); // Near clouds more opaque
            
            for (int i = 0; i < cloudCount; i++)
            {
                _clouds.Add(new Cloud
                {
                    X = (float)_random.NextDouble(),
                    Y = 0.3f + (float)_random.NextDouble() * 0.4f, // Middle section
                    Width = 0.03f + (float)_random.NextDouble() * 0.08f,
                    Height = 0.015f + (float)_random.NextDouble() * 0.03f,
                    Speed = speed,
                    Opacity = opacity
                });
            }
        }
        
        // Generate UFOs near the moon (2-3 UFOs)
        for (int i = 0; i < 3; i++)
        {
            _ufos.Add(new BackgroundUFO
            {
                Angle = (float)_random.NextDouble() * 360f,
                Speed = 0.5f + (float)_random.NextDouble() * 1.0f,
                OrbitRadiusX = 60f + _random.Next(40),
                OrbitRadiusY = 40f + _random.Next(30)
            });
        }
    }
    
    public void Update()
    {
        _earthRotation += 0.1f;
        if (_earthRotation >= 360) _earthRotation -= 360;
        
        // Update star twinkle and parallax movement
        foreach (var star in _stars)
        {
            star.TwinklePhase += star.TwinkleSpeed;
            if (star.TwinklePhase > Math.PI * 2)
                star.TwinklePhase -= (float)(Math.PI * 2);
            
            // Move stars with parallax effect (stelle vicine si muovono più veloci)
            star.X += star.MoveSpeed;
            if (star.X > 1.0f) star.X -= 1.0f;
            
            // Leggero movimento verticale per alcune stelle (effetto di deriva spaziale)
            if (star.Layer > 0.7f) // Solo stelle vicine
            {
                star.Y += (float)Math.Sin(star.TwinklePhase) * 0.00005f;
                if (star.Y > 1.0f) star.Y = 0.0f;
                if (star.Y < 0.0f) star.Y = 1.0f;
            }
        }
        
        // Update clouds - parallax scrolling
        foreach (var cloud in _clouds)
        {
            cloud.X += cloud.Speed * 0.001f;
            if (cloud.X > 1.0f) cloud.X -= 1.0f + cloud.Width; // Wrap around
        }
        
        // Update UFOs - orbital movement
        foreach (var ufo in _ufos)
        {
            ufo.Angle += ufo.Speed;
            if (ufo.Angle >= 360f) ufo.Angle -= 360f;
        }
    }
    
    public void Draw(Graphics g, int width, int height)
    {
        // Draw deep space gradient background
        using var spaceBrush = new LinearGradientBrush(
            new Rectangle(0, 0, width, height),
            Color.FromArgb(5, 5, 20),      // Deep space blue-black
            Color.FromArgb(15, 10, 30),    // Slightly lighter at bottom
            90f
        );
        g.FillRectangle(spaceBrush, 0, 0, width, height);
        
        // Draw stars
        foreach (var star in _stars)
        {
            float twinkle = (float)Math.Sin(star.TwinklePhase);
            float alpha = star.Brightness + twinkle * 0.3f;
            alpha = Math.Clamp(alpha, 0f, 1f);
            
            int x = (int)(star.X * width);
            int y = (int)(star.Y * height);
            
            Color starColor = Color.FromArgb(
                (int)(255 * alpha),
                255, 255, 255
            );
            
            using var starBrush = new SolidBrush(starColor);
            g.FillEllipse(starBrush, x, y, star.Size, star.Size);
            
            // Add glow for brighter stars
            if (star.Brightness > 0.7f)
            {
                using var glowBrush = new SolidBrush(Color.FromArgb((int)(50 * alpha), 200, 200, 255));
                g.FillEllipse(glowBrush, x - 2, y - 2, star.Size + 4, star.Size + 4);
            }
        }
        
        // Draw Moon (top right corner)
        DrawMoon(g, width, height);
        
        // Draw UFOs orbiting near the moon
        DrawBackgroundUFOs(g, width, height);
        
        // Draw animated parallax clouds in space
        g.SmoothingMode = SmoothingMode.AntiAlias;
        foreach (var cloud in _clouds)
        {
            int cloudX = (int)(cloud.X * width);
            int cloudY = (int)(cloud.Y * height);
            int cloudWidth = (int)(cloud.Width * width);
            int cloudHeight = (int)(cloud.Height * height);
            
            using var cloudBrush = new SolidBrush(Color.FromArgb((int)(cloud.Opacity * 255), 255, 255, 255));
            
            // Draw fluffy cloud shape with multiple ellipses
            g.FillEllipse(cloudBrush, cloudX, cloudY, cloudWidth, cloudHeight);
            g.FillEllipse(cloudBrush, cloudX + cloudWidth/3, cloudY - cloudHeight/4, cloudWidth*2/3, cloudHeight);
            g.FillEllipse(cloudBrush, cloudX + cloudWidth/2, cloudY + cloudHeight/4, cloudWidth/2, cloudHeight*2/3);
        }
        
        // Draw Earth in bottom portion (partially visible)
        DrawEarth(g, width, height);
        
        // Draw distant nebula/galaxy
        DrawNebula(g, width, height);
    }
    
    private void DrawEarth(Graphics g, int width, int height)
    {
        int earthSize = (int)(height * 1.2f);
        int earthX = width / 2 - earthSize / 2;
        int earthY = height - earthSize / 3; // Partially below screen
        
        // Salva lo stato grafico originale
        var state = g.Save();
        
        // Applica rotazione al centro della Terra
        int centerX = earthX + earthSize / 2;
        int centerY = earthY + earthSize / 2;
        
        // Trasla al centro, ruota, poi trasla indietro
        g.TranslateTransform(centerX, centerY);
        g.RotateTransform(_earthRotation);
        g.TranslateTransform(-centerX, -centerY);
        
        // Earth shadow (night side)
        using var shadowPath = new GraphicsPath();
        shadowPath.AddEllipse(earthX, earthY, earthSize, earthSize);
        using var shadowBrush = new PathGradientBrush(shadowPath);
        shadowBrush.CenterPoint = new PointF(earthX + earthSize * 0.6f, earthY + earthSize * 0.4f);
        shadowBrush.CenterColor = Color.FromArgb(50, 100, 200); // Ocean blue lit
        shadowBrush.SurroundColors = new[] { Color.FromArgb(5, 10, 30) }; // Dark space
        
        g.FillEllipse(shadowBrush, earthX, earthY, earthSize, earthSize);
        
        // Earth continents (simplified green shapes)
        g.SmoothingMode = SmoothingMode.AntiAlias;
        DrawContinents(g, earthX, earthY, earthSize);
        
        // Clouds layer
        DrawClouds(g, earthX, earthY, earthSize);
        
        // Draw 3D mountains on Earth
        Draw3DMountains(g, earthX, earthY, earthSize);
        
        // Draw 3D pine trees on Earth
        Draw3DPineTrees(g, earthX, earthY, earthSize);
        
        // Atmosphere glow
        using var atmoPath = new GraphicsPath();
        atmoPath.AddEllipse(earthX - 20, earthY - 20, earthSize + 40, earthSize + 40);
        using var atmoBrush = new PathGradientBrush(atmoPath);
        atmoBrush.CenterColor = Color.Transparent;
        atmoBrush.SurroundColors = new[] { Color.FromArgb(40, 100, 150, 255) };
        g.FillPath(atmoBrush, atmoPath);
        
        // Ripristina lo stato grafico (rimuove la rotazione)
        g.Restore(state);
    }
    
    private void DrawContinents(Graphics g, int earthX, int earthY, int earthSize)
    {
        using var landBrush = new SolidBrush(Color.FromArgb(180, 80, 160, 80)); // Green land più intenso
        using var desertBrush = new SolidBrush(Color.FromArgb(150, 200, 180, 120)); // Deserti gialli
        using var mountainBrush = new SolidBrush(Color.FromArgb(200, 120, 100, 80)); // Montagne marroni
        
        // Africa
        var africa = new Point[]
        {
            new Point(earthX + earthSize / 2, earthY + earthSize / 3),
            new Point(earthX + earthSize / 2 + 90, earthY + earthSize / 3 + 40),
            new Point(earthX + earthSize / 2 + 80, earthY + earthSize / 2 + 20),
            new Point(earthX + earthSize / 2 + 50, earthY + earthSize / 2 + 70),
            new Point(earthX + earthSize / 2 - 20, earthY + earthSize / 2 + 40),
            new Point(earthX + earthSize / 2 - 10, earthY + earthSize / 3 + 20)
        };
        g.FillPolygon(landBrush, africa);
        
        // Sahara desert in Africa
        var sahara = new Point[]
        {
            new Point(earthX + earthSize / 2 + 10, earthY + earthSize / 3 + 15),
            new Point(earthX + earthSize / 2 + 70, earthY + earthSize / 3 + 30),
            new Point(earthX + earthSize / 2 + 60, earthY + earthSize / 3 + 50),
            new Point(earthX + earthSize / 2, earthY + earthSize / 3 + 40)
        };
        g.FillPolygon(desertBrush, sahara);
        
        // Europe
        var europe = new Point[]
        {
            new Point(earthX + earthSize / 2 + 20, earthY + earthSize / 4),
            new Point(earthX + earthSize / 2 + 70, earthY + earthSize / 4 + 10),
            new Point(earthX + earthSize / 2 + 60, earthY + earthSize / 3 - 10),
            new Point(earthX + earthSize / 2 + 30, earthY + earthSize / 3 - 15)
        };
        g.FillPolygon(landBrush, europe);
        
        // Americas (North + South)
        var northAmerica = new Point[]
        {
            new Point(earthX + earthSize / 4, earthY + earthSize / 3 - 20),
            new Point(earthX + earthSize / 4 + 90, earthY + earthSize / 3 - 10),
            new Point(earthX + earthSize / 4 + 80, earthY + earthSize / 2 - 20),
            new Point(earthX + earthSize / 4 + 50, earthY + earthSize / 2),
            new Point(earthX + earthSize / 4 + 20, earthY + earthSize / 2 - 10)
        };
        g.FillPolygon(landBrush, northAmerica);
        
        var southAmerica = new Point[]
        {
            new Point(earthX + earthSize / 4 + 50, earthY + earthSize / 2 + 10),
            new Point(earthX + earthSize / 4 + 70, earthY + earthSize / 2 + 20),
            new Point(earthX + earthSize / 4 + 60, earthY + earthSize / 2 + 90),
            new Point(earthX + earthSize / 4 + 40, earthY + earthSize / 2 + 100),
            new Point(earthX + earthSize / 4 + 30, earthY + earthSize / 2 + 60)
        };
        g.FillPolygon(landBrush, southAmerica);
        
        // Amazon (green intense)
        using var amazonBrush = new SolidBrush(Color.FromArgb(200, 40, 180, 40));
        var amazon = new Rectangle(earthX + earthSize / 4 + 45, earthY + earthSize / 2 + 30, 35, 40);
        g.FillEllipse(amazonBrush, amazon);
        
        // Himalaya mountains
        var himalaya = new Point[]
        {
            new Point(earthX + earthSize / 2 + 150, earthY + earthSize / 3 + 30),
            new Point(earthX + earthSize / 2 + 180, earthY + earthSize / 3 + 35),
            new Point(earthX + earthSize / 2 + 170, earthY + earthSize / 3 + 50),
            new Point(earthX + earthSize / 2 + 160, earthY + earthSize / 3 + 45)
        };
        g.FillPolygon(mountainBrush, himalaya);
        
        // Andes mountains
        var andes = new Point[]
        {
            new Point(earthX + earthSize / 4 + 35, earthY + earthSize / 2 + 40),
            new Point(earthX + earthSize / 4 + 45, earthY + earthSize / 2 + 45),
            new Point(earthX + earthSize / 4 + 42, earthY + earthSize / 2 + 85),
            new Point(earthX + earthSize / 4 + 38, earthY + earthSize / 2 + 82)
        };
        g.FillPolygon(mountainBrush, andes);
        
        // Rivers - Amazon River
        using var riverPen = new Pen(Color.FromArgb(120, 100, 150, 255), 2);
        g.DrawCurve(riverPen, new Point[]
        {
            new Point(earthX + earthSize / 4 + 75, earthY + earthSize / 2 + 50),
            new Point(earthX + earthSize / 4 + 60, earthY + earthSize / 2 + 52),
            new Point(earthX + earthSize / 4 + 45, earthY + earthSize / 2 + 55)
        });
        
        // Nile River
        g.DrawCurve(riverPen, new Point[]
        {
            new Point(earthX + earthSize / 2 + 50, earthY + earthSize / 3 + 50),
            new Point(earthX + earthSize / 2 + 45, earthY + earthSize / 3 + 30),
            new Point(earthX + earthSize / 2 + 40, earthY + earthSize / 3 + 10)
        });
    }
    
    private void DrawClouds(Graphics g, int earthX, int earthY, int earthSize)
    {
        using var cloudBrush = new SolidBrush(Color.FromArgb(100, 255, 255, 255));
        
        // Random cloud patches
        var cloud1 = new Rectangle(earthX + earthSize / 3, earthY + earthSize / 4, 80, 40);
        var cloud2 = new Rectangle(earthX + earthSize / 2, earthY + earthSize / 2, 60, 30);
        var cloud3 = new Rectangle(earthX + earthSize / 5, earthY + earthSize / 2 + 50, 70, 35);
        
        g.FillEllipse(cloudBrush, cloud1);
        g.FillEllipse(cloudBrush, cloud2);
        g.FillEllipse(cloudBrush, cloud3);
    }
    
    private void DrawNebula(Graphics g, int width, int height)
    {
        // Distant purple/pink nebula in upper left
        using var nebulaPath = new GraphicsPath();
        nebulaPath.AddEllipse(width / 8, height / 8, width / 3, height / 4);
        
        using var nebulaBrush = new PathGradientBrush(nebulaPath);
        nebulaBrush.CenterPoint = new PointF(width / 4, height / 5);
        nebulaBrush.CenterColor = Color.FromArgb(30, 150, 50, 150); // Purple center
        nebulaBrush.SurroundColors = new[] { Color.FromArgb(0, 0, 0, 0) }; // Fade to transparent
        
        g.FillPath(nebulaBrush, nebulaPath);
    }
    
    private void DrawMoon(Graphics g, int width, int height)
    {
        g.SmoothingMode = SmoothingMode.AntiAlias;
        
        int moonSize = 80;
        int moonX = width - moonSize - 40; // Top right corner
        int moonY = 30;
        
        // Moon glow
        using var glowPath = new GraphicsPath();
        glowPath.AddEllipse(moonX - 10, moonY - 10, moonSize + 20, moonSize + 20);
        using var glowBrush = new PathGradientBrush(glowPath);
        glowBrush.CenterColor = Color.FromArgb(50, 255, 255, 200);
        glowBrush.SurroundColors = new[] { Color.FromArgb(0, 0, 0, 0) };
        g.FillPath(glowBrush, glowPath);
        
        // Moon body with gradient (gray to light gray)
        using var moonPath = new GraphicsPath();
        moonPath.AddEllipse(moonX, moonY, moonSize, moonSize);
        using var moonBrush = new PathGradientBrush(moonPath);
        moonBrush.CenterPoint = new PointF(moonX + moonSize * 0.4f, moonY + moonSize * 0.4f);
        moonBrush.CenterColor = Color.FromArgb(240, 240, 230); // Light center
        moonBrush.SurroundColors = new[] { Color.FromArgb(180, 180, 170) }; // Darker edge
        g.FillPath(moonBrush, moonPath);
        
        // Moon craters (darker circles)
        using var craterBrush = new SolidBrush(Color.FromArgb(100, 150, 150, 140));
        g.FillEllipse(craterBrush, moonX + 15, moonY + 20, 18, 18);
        g.FillEllipse(craterBrush, moonX + 45, moonY + 15, 12, 12);
        g.FillEllipse(craterBrush, moonX + 25, moonY + 50, 15, 15);
        g.FillEllipse(craterBrush, moonX + 55, moonY + 45, 10, 10);
    }
    
    private void DrawBackgroundUFOs(Graphics g, int width, int height)
    {
        g.SmoothingMode = SmoothingMode.AntiAlias;
        
        int moonX = width - 120; // Moon center X
        int moonY = 30 + 40; // Moon center Y
        
        foreach (var ufo in _ufos)
        {
            // Calculate UFO position in elliptical orbit around moon
            float angleRad = ufo.Angle * (float)Math.PI / 180f;
            float ufoX = moonX + (float)Math.Cos(angleRad) * ufo.OrbitRadiusX;
            float ufoY = moonY + (float)Math.Sin(angleRad) * ufo.OrbitRadiusY;
            
            // UFO size
            int ufoWidth = 25;
            int ufoHeight = 12;
            
            // UFO body (silver/gray ellipse)
            using var ufoPath = new GraphicsPath();
            ufoPath.AddEllipse(ufoX - ufoWidth/2, ufoY - ufoHeight/2, ufoWidth, ufoHeight);
            using var ufoBrush = new LinearGradientBrush(
                new PointF(ufoX, ufoY - ufoHeight/2),
                new PointF(ufoX, ufoY + ufoHeight/2),
                Color.FromArgb(200, 220, 220, 220), // Light gray top
                Color.FromArgb(200, 140, 140, 140)  // Darker gray bottom
            );
            g.FillPath(ufoBrush, ufoPath);
            
            // UFO dome (transparent dome on top)
            using var domePath = new GraphicsPath();
            domePath.AddEllipse(ufoX - ufoWidth/3, ufoY - ufoHeight, ufoWidth*2/3, ufoHeight);
            using var domeBrush = new LinearGradientBrush(
                new PointF(ufoX, ufoY - ufoHeight),
                new PointF(ufoX, ufoY),
                Color.FromArgb(80, 150, 200, 255), // Light blue transparent
                Color.FromArgb(30, 150, 200, 255)
            );
            g.FillPath(domeBrush, domePath);
            
            // Small lights underneath (blinking effect based on angle)
            if ((int)ufo.Angle % 60 < 30)
            {
                using var lightBrush = new SolidBrush(Color.FromArgb(200, 255, 255, 100));
                g.FillEllipse(lightBrush, ufoX - 8, ufoY + 2, 4, 4);
                g.FillEllipse(lightBrush, ufoX + 4, ufoY + 2, 4, 4);
            }
        }
    }
    
    private void Draw3DMountains(Graphics g, int earthX, int earthY, int earthSize)
    {
        // Disegna catene montuose 3D sulla superficie terrestre
        // Montagne con prospettiva (più piccole in lontananza)
        
        var mountainColor1 = Color.FromArgb(200, 100, 80, 60); // Marrone scuro
        var mountainColor2 = Color.FromArgb(200, 140, 120, 100); // Marrone chiaro
        var snowColor = Color.FromArgb(220, 255, 255, 255); // Neve bianca
        
        // Montagne in Europa (Alpi)
        DrawMountain(g, earthX + earthSize / 2 + 40, earthY + earthSize / 4 + 15, 
                     30, 40, mountainColor1, snowColor);
        DrawMountain(g, earthX + earthSize / 2 + 50, earthY + earthSize / 4 + 20, 
                     25, 35, mountainColor2, snowColor);
        DrawMountain(g, earthX + earthSize / 2 + 65, earthY + earthSize / 4 + 18, 
                     28, 38, mountainColor1, snowColor);
        
        // Montagne in Nord America (Rockies)
        DrawMountain(g, earthX + earthSize / 4 + 30, earthY + earthSize / 3 - 5, 
                     35, 45, mountainColor2, snowColor);
        DrawMountain(g, earthX + earthSize / 4 + 45, earthY + earthSize / 3, 
                     32, 42, mountainColor1, snowColor);
        
        // Montagne in Asia (Himalaya - più grandi)
        DrawMountain(g, earthX + earthSize / 2 + 120, earthY + earthSize / 3 + 30, 
                     40, 55, mountainColor1, snowColor);
        DrawMountain(g, earthX + earthSize / 2 + 135, earthY + earthSize / 3 + 35, 
                     38, 52, mountainColor2, snowColor);
    }
    
    private void DrawMountain(Graphics g, int x, int y, int width, int height, 
                              Color baseColor, Color snowColor)
    {
        // Triangolo montagna 3D con neve in cima
        Point[] mountainPoints = new Point[]
        {
            new Point(x, y - height),           // Punta
            new Point(x - width/2, y),          // Base sinistra
            new Point(x + width/2, y)           // Base destra
        };
        
        // Ombreggiatura laterale per effetto 3D
        using (var path = new GraphicsPath())
        {
            path.AddPolygon(mountainPoints);
            using (var brush = new LinearGradientBrush(
                new Point(x - width/2, y),
                new Point(x + width/2, y),
                Color.FromArgb(baseColor.A, 
                    Math.Max(0, baseColor.R - 40), 
                    Math.Max(0, baseColor.G - 40), 
                    Math.Max(0, baseColor.B - 40)),
                baseColor))
            {
                g.FillPath(brush, path);
            }
        }
        
        // Neve sulla cima (terzo superiore)
        Point[] snowPoints = new Point[]
        {
            new Point(x, y - height),                      // Punta
            new Point(x - width/6, y - height * 2/3),      // Sinistra
            new Point(x + width/6, y - height * 2/3)       // Destra
        };
        using (var snowBrush = new SolidBrush(snowColor))
        {
            g.FillPolygon(snowBrush, snowPoints);
        }
    }
    
    private void Draw3DPineTrees(Graphics g, int earthX, int earthY, int earthSize)
    {
        // Disegna pini 3D sulla superficie terrestre
        // Distribuiti su varie zone (Europa, Nord America, Asia)
        
        var treeGreenDark = Color.FromArgb(200, 40, 80, 40);
        var treeGreenLight = Color.FromArgb(200, 60, 120, 60);
        var trunkBrown = Color.FromArgb(200, 80, 50, 30);
        
        // Pini in Europa
        DrawPineTree(g, earthX + earthSize / 2 + 35, earthY + earthSize / 4 + 25, 
                     8, 15, treeGreenDark, trunkBrown);
        DrawPineTree(g, earthX + earthSize / 2 + 42, earthY + earthSize / 4 + 28, 
                     7, 13, treeGreenLight, trunkBrown);
        DrawPineTree(g, earthX + earthSize / 2 + 55, earthY + earthSize / 4 + 30, 
                     9, 16, treeGreenDark, trunkBrown);
        DrawPineTree(g, earthX + earthSize / 2 + 48, earthY + earthSize / 4 + 32, 
                     6, 12, treeGreenLight, trunkBrown);
        
        // Pini in Nord America (foreste canadesi)
        DrawPineTree(g, earthX + earthSize / 4 + 25, earthY + earthSize / 3 - 8, 
                     10, 18, treeGreenLight, trunkBrown);
        DrawPineTree(g, earthX + earthSize / 4 + 35, earthY + earthSize / 3 - 5, 
                     9, 16, treeGreenDark, trunkBrown);
        DrawPineTree(g, earthX + earthSize / 4 + 42, earthY + earthSize / 3 - 2, 
                     8, 15, treeGreenLight, trunkBrown);
        DrawPineTree(g, earthX + earthSize / 4 + 52, earthY + earthSize / 3 + 2, 
                     7, 14, treeGreenDark, trunkBrown);
        
        // Pini in Asia (taiga siberiana)
        DrawPineTree(g, earthX + earthSize / 2 + 100, earthY + earthSize / 3 + 20, 
                     11, 20, treeGreenDark, trunkBrown);
        DrawPineTree(g, earthX + earthSize / 2 + 110, earthY + earthSize / 3 + 25, 
                     10, 18, treeGreenLight, trunkBrown);
        DrawPineTree(g, earthX + earthSize / 2 + 118, earthY + earthSize / 3 + 28, 
                     9, 17, treeGreenDark, trunkBrown);
    }
    
    private void DrawPineTree(Graphics g, int x, int y, int width, int height, 
                              Color greenColor, Color trunkColor)
    {
        // Tronco marrone
        int trunkWidth = width / 3;
        int trunkHeight = height / 4;
        using (var trunkBrush = new SolidBrush(trunkColor))
        {
            g.FillRectangle(trunkBrush, x - trunkWidth/2, y - trunkHeight, trunkWidth, trunkHeight);
        }
        
        // Chioma del pino (3 triangoli sovrapposti per forma conica)
        // Triangolo inferiore (più largo)
        Point[] bottom = new Point[]
        {
            new Point(x, y - trunkHeight - height * 2/3),
            new Point(x - width/2, y - trunkHeight),
            new Point(x + width/2, y - trunkHeight)
        };
        
        // Triangolo medio
        Point[] middle = new Point[]
        {
            new Point(x, y - trunkHeight - height * 5/6),
            new Point(x - width/3, y - trunkHeight - height/3),
            new Point(x + width/3, y - trunkHeight - height/3)
        };
        
        // Triangolo superiore (punta)
        Point[] top = new Point[]
        {
            new Point(x, y - trunkHeight - height),
            new Point(x - width/4, y - trunkHeight - height * 2/3),
            new Point(x + width/4, y - trunkHeight - height * 2/3)
        };
        
        using (var greenBrush = new SolidBrush(greenColor))
        {
            g.FillPolygon(greenBrush, bottom);
            
            // Aggiungi leggera variazione di colore per profondità
            using (var greenBrush2 = new SolidBrush(Color.FromArgb(
                greenColor.A,
                Math.Min(255, greenColor.R + 15),
                Math.Min(255, greenColor.G + 15),
                Math.Min(255, greenColor.B + 15))))
            {
                g.FillPolygon(greenBrush2, middle);
                g.FillPolygon(greenBrush, top);
            }
        }
    }
}
