using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;

namespace SpaceInvaders.GraphicsMode
{
    /// <summary>
    /// Maestro Yoda appare quando il giocatore ha solo 1 vita e regala una vita extra
    /// </summary>
    public class YodaHelper
    {
        private bool _isActive;
        private int _animationFrame;
        private readonly Image? _yodaImage;
        private int _lightsaberGlow;
        private bool _hasAppeared; // Previene apparizioni multiple
        private const int AnimationDuration = 180; // 6 secondi a 30 FPS
        
        public bool IsActive => _isActive;
        public bool HasAppeared => _hasAppeared;
        
        public event Action? OnYodaAppears;
        public event Action? OnLifeGranted;
        
        public YodaHelper()
        {
            _isActive = false;
            _animationFrame = 0;
            _lightsaberGlow = 0;
            _hasAppeared = false;
            
            // Carica immagine Yoda
            string imagePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "YodaAttack.png");
            if (File.Exists(imagePath))
            {
                try
                {
                    _yodaImage = Image.FromFile(imagePath);
                }
                catch
                {
                    _yodaImage = null;
                }
            }
        }
        
        public void CheckAndActivate(int playerLives)
        {
            // Attiva Yoda solo se il giocatore ha 1 vita e non è già apparso
            if (playerLives == 1 && !_hasAppeared && !_isActive)
            {
                Activate();
            }
        }
        
        public void Activate()
        {
            if (_hasAppeared) return; // Non appare più di una volta
            
            _isActive = true;
            _animationFrame = 0;
            _lightsaberGlow = 0;
            _hasAppeared = true;
            
            OnYodaAppears?.Invoke();
        }
        
        public void Update()
        {
            if (!_isActive) return;
            
            _animationFrame++;
            _lightsaberGlow = (int)(Math.Sin(_animationFrame * 0.2) * 50 + 150);
            
            // Regala la vita a metà animazione (dopo 3 secondi)
            if (_animationFrame == AnimationDuration / 2)
            {
                OnLifeGranted?.Invoke();
            }
            
            // Termina animazione dopo 6 secondi
            if (_animationFrame >= AnimationDuration)
            {
                _isActive = false;
            }
        }
        
        public void Draw(Graphics g, int screenWidth, int screenHeight)
        {
            if (!_isActive) return;
            
            g.SmoothingMode = SmoothingMode.AntiAlias;
            
            int centerX = screenWidth / 2;
            int centerY = screenHeight / 2;
            
            // Dimensioni Yoda (più grande per visibilità)
            int yodaWidth = 200;
            int yodaHeight = 250;
            
            // Effetto fade in/out
            float alpha = 1.0f;
            if (_animationFrame < 30)
            {
                alpha = _animationFrame / 30f; // Fade in
            }
            else if (_animationFrame > AnimationDuration - 30)
            {
                alpha = (AnimationDuration - _animationFrame) / 30f; // Fade out
            }
            
            // Bagliore di sfondo (aura verde Force)
            DrawForceAura(g, centerX, centerY, yodaWidth, yodaHeight, alpha);
            
            // Bordo fluorescente verde
            DrawFluorescentBorder(g, centerX, centerY, yodaWidth, yodaHeight, alpha);
            
            // Disegna Yoda
            if (_yodaImage != null)
            {
                // Effetto trasparenza
                ColorMatrix colorMatrix = new ColorMatrix();
                colorMatrix.Matrix33 = alpha;
                
                using (ImageAttributes attributes = new ImageAttributes())
                {
                    attributes.SetColorMatrix(colorMatrix, ColorMatrixFlag.Default, ColorAdjustType.Bitmap);
                    
                    Rectangle destRect = new Rectangle(
                        centerX - yodaWidth / 2,
                        centerY - yodaHeight / 2,
                        yodaWidth,
                        yodaHeight
                    );
                    
                    g.DrawImage(_yodaImage, destRect, 0, 0, _yodaImage.Width, _yodaImage.Height,
                               GraphicsUnit.Pixel, attributes);
                }
            }
            else
            {
                // Fallback: disegna sagoma Yoda stilizzata
                DrawYodaFallback(g, centerX, centerY, alpha);
            }
            
            // Spada laser verde animata
            DrawLightsaber(g, centerX, centerY, yodaWidth, yodaHeight, alpha);
            
            // Testo "Force I give you" con fade
            DrawYodaMessage(g, centerX, centerY, yodaHeight, alpha);
        }
        
        private void DrawForceAura(Graphics g, int centerX, int centerY, int width, int height, float alpha)
        {
            // Aura verde pulsante della Forza
            int auraSize = (int)(width * 1.5 + Math.Sin(_animationFrame * 0.1) * 20);
            
            using (GraphicsPath path = new GraphicsPath())
            {
                path.AddEllipse(centerX - auraSize / 2, centerY - auraSize / 2, auraSize, auraSize);
                
                using (PathGradientBrush brush = new PathGradientBrush(path))
                {
                    brush.CenterPoint = new PointF(centerX, centerY);
                    brush.CenterColor = Color.FromArgb((int)(100 * alpha), 0, 255, 100);
                    brush.SurroundColors = new[] { Color.FromArgb(0, 0, 255, 0) };
                    
                    g.FillPath(brush, path);
                }
            }
        }
        
        private void DrawFluorescentBorder(Graphics g, int centerX, int centerY, int width, int height, float alpha)
        {
            // Bordo fluorescente verde con effetto glow
            int borderWidth = 8;
            
            // Bagliore esterno
            using (Pen glowPen = new Pen(Color.FromArgb((int)(100 * alpha), 0, 255, 0), borderWidth * 2))
            {
                glowPen.LineJoin = LineJoin.Round;
                g.DrawRectangle(glowPen, 
                    centerX - width / 2 - borderWidth, 
                    centerY - height / 2 - borderWidth,
                    width + borderWidth * 2, 
                    height + borderWidth * 2);
            }
            
            // Bordo principale
            using (Pen borderPen = new Pen(Color.FromArgb((int)(255 * alpha), 50, 255, 50), borderWidth))
            {
                borderPen.LineJoin = LineJoin.Round;
                g.DrawRectangle(borderPen, 
                    centerX - width / 2, 
                    centerY - height / 2,
                    width, 
                    height);
            }
            
            // Linee di energia agli angoli
            using (Pen energyPen = new Pen(Color.FromArgb((int)(200 * alpha), 150, 255, 150), 3))
            {
                // Angolo alto sinistra
                g.DrawLine(energyPen, 
                    centerX - width / 2 - 15, centerY - height / 2,
                    centerX - width / 2 + 15, centerY - height / 2);
                g.DrawLine(energyPen, 
                    centerX - width / 2, centerY - height / 2 - 15,
                    centerX - width / 2, centerY - height / 2 + 15);
                
                // Angolo alto destra
                g.DrawLine(energyPen, 
                    centerX + width / 2 - 15, centerY - height / 2,
                    centerX + width / 2 + 15, centerY - height / 2);
                g.DrawLine(energyPen, 
                    centerX + width / 2, centerY - height / 2 - 15,
                    centerX + width / 2, centerY - height / 2 + 15);
                
                // Angolo basso sinistra
                g.DrawLine(energyPen, 
                    centerX - width / 2 - 15, centerY + height / 2,
                    centerX - width / 2 + 15, centerY + height / 2);
                g.DrawLine(energyPen, 
                    centerX - width / 2, centerY + height / 2 - 15,
                    centerX - width / 2, centerY + height / 2 + 15);
                
                // Angolo basso destra
                g.DrawLine(energyPen, 
                    centerX + width / 2 - 15, centerY + height / 2,
                    centerX + width / 2 + 15, centerY + height / 2);
                g.DrawLine(energyPen, 
                    centerX + width / 2, centerY + height / 2 - 15,
                    centerX + width / 2, centerY + height / 2 + 15);
            }
        }
        
        private void DrawLightsaber(Graphics g, int centerX, int centerY, int width, int height, float alpha)
        {
            // Spada laser verde animata
            int saberX = centerX + width / 4;
            int saberY = centerY;
            int saberLength = 80 + (int)(Math.Sin(_animationFrame * 0.3) * 10);
            
            // Bagliore della lama
            using (Pen glowPen = new Pen(Color.FromArgb((int)(150 * alpha), 0, 255, 0), 12))
            {
                glowPen.StartCap = LineCap.Round;
                glowPen.EndCap = LineCap.Round;
                g.DrawLine(glowPen, saberX, saberY, saberX, saberY - saberLength);
            }
            
            // Lama centrale brillante
            using (Pen bladePen = new Pen(Color.FromArgb((int)(255 * alpha), _lightsaberGlow, 255, _lightsaberGlow), 6))
            {
                bladePen.StartCap = LineCap.Round;
                bladePen.EndCap = LineCap.Round;
                g.DrawLine(bladePen, saberX, saberY, saberX, saberY - saberLength);
            }
            
            // Impugnatura
            using (SolidBrush handleBrush = new SolidBrush(Color.FromArgb((int)(255 * alpha), 80, 80, 80)))
            {
                g.FillRectangle(handleBrush, saberX - 4, saberY, 8, 25);
            }
            
            // Dettagli impugnatura
            using (Pen detailPen = new Pen(Color.FromArgb((int)(255 * alpha), 150, 150, 150), 1))
            {
                g.DrawLine(detailPen, saberX - 4, saberY + 8, saberX + 4, saberY + 8);
                g.DrawLine(detailPen, saberX - 4, saberY + 16, saberX + 4, saberY + 16);
            }
        }
        
        private void DrawYodaMessage(Graphics g, int centerX, int centerY, int yodaHeight, float alpha)
        {
            // Messaggio di Yoda con font caratteristico
            string message = _animationFrame < AnimationDuration / 2 
                ? "Much danger you face..." 
                : "A life I give you!";
            
            using (Font yodaFont = new Font("Arial", 24, FontStyle.Bold | FontStyle.Italic))
            using (SolidBrush shadowBrush = new SolidBrush(Color.FromArgb((int)(200 * alpha), 0, 0, 0)))
            using (SolidBrush textBrush = new SolidBrush(Color.FromArgb((int)(255 * alpha), 150, 255, 150)))
            {
                StringFormat format = new StringFormat();
                format.Alignment = StringAlignment.Center;
                
                int textY = centerY + yodaHeight / 2 + 30;
                
                // Ombra
                g.DrawString(message, yodaFont, shadowBrush, centerX + 2, textY + 2, format);
                
                // Testo principale
                g.DrawString(message, yodaFont, textBrush, centerX, textY, format);
            }
        }
        
        private void DrawYodaFallback(Graphics g, int centerX, int centerY, float alpha)
        {
            // Disegna sagoma stilizzata di Yoda se l'immagine non è disponibile
            using (SolidBrush yodaBrush = new SolidBrush(Color.FromArgb((int)(255 * alpha), 100, 150, 100)))
            {
                // Corpo
                g.FillEllipse(yodaBrush, centerX - 30, centerY - 20, 60, 80);
                
                // Testa
                g.FillEllipse(yodaBrush, centerX - 35, centerY - 60, 70, 60);
                
                // Orecchie grandi caratteristiche
                Point[] leftEar = new[] 
                {
                    new Point(centerX - 35, centerY - 50),
                    new Point(centerX - 60, centerY - 65),
                    new Point(centerX - 35, centerY - 35)
                };
                g.FillPolygon(yodaBrush, leftEar);
                
                Point[] rightEar = new[] 
                {
                    new Point(centerX + 35, centerY - 50),
                    new Point(centerX + 60, centerY - 65),
                    new Point(centerX + 35, centerY - 35)
                };
                g.FillPolygon(yodaBrush, rightEar);
                
                // Mantello
                using (SolidBrush robesBrush = new SolidBrush(Color.FromArgb((int)(255 * alpha), 101, 67, 33)))
                {
                    g.FillRectangle(robesBrush, centerX - 40, centerY + 20, 80, 60);
                }
            }
        }
        
        public void Reset()
        {
            // Resetta per un nuovo gioco (permette a Yoda di apparire di nuovo)
            _hasAppeared = false;
            _isActive = false;
            _animationFrame = 0;
        }
    }
}
