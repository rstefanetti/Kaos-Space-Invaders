using System.Drawing;

namespace SpaceInvaders.GraphicsMode;

/// <summary>
/// Barra messaggi in basso tipo flipper - mostra messaggi brevi che scorrono
/// </summary>
public class MessageBar
{
    private readonly Queue<(string Message, int Timer, Color Color)> _messages;
    private const int MessageDuration = 90; // 3 secondi a 30 FPS
    private const int MaxMessagesVisible = 3;
    private int _scrollOffset;
    private const int ScrollSpeed = 1;
    
    public MessageBar()
    {
        _messages = new Queue<(string, int, Color)>();
        _scrollOffset = 0;
    }
    
    public void AddMessage(string message, Color? color = null)
    {
        var msgColor = color ?? Color.Yellow;
        _messages.Enqueue((message, MessageDuration, msgColor));
        
        // Mantieni solo gli ultimi 10 messaggi in coda
        while (_messages.Count > 10)
        {
            _messages.Dequeue();
        }
    }
    
    public void Update()
    {
        // Aggiorna i timer dei messaggi
        var updatedMessages = new List<(string, int, Color)>();
        
        while (_messages.Count > 0)
        {
            var msg = _messages.Dequeue();
            if (msg.Timer > 0)
            {
                updatedMessages.Add((msg.Message, msg.Timer - 1, msg.Color));
            }
        }
        
        foreach (var msg in updatedMessages)
        {
            _messages.Enqueue(msg);
        }
        
        // Scorrimento automatico
        _scrollOffset += ScrollSpeed;
        if (_scrollOffset > 200)
        {
            _scrollOffset = 0;
        }
    }
    
    public void Draw(Graphics g, int screenWidth, int screenHeight)
    {
        if (_messages.Count == 0) return;
        
        // Barra nera in basso (tipo flipper) - aumentata per font più grande
        int barHeight = 50;
        int barY = screenHeight - barHeight;
        
        using var barBrush = new SolidBrush(Color.FromArgb(200, 0, 0, 0));
        g.FillRectangle(barBrush, 0, barY, screenWidth, barHeight);
        
        // Bordo superiore luminoso
        using var borderPen = new Pen(Color.FromArgb(150, 255, 255, 0), 3);
        g.DrawLine(borderPen, 0, barY, screenWidth, barY);
        
        // Disegna i messaggi (usa Segoe UI per emoji) - font più grande
        using var font = new Font("Segoe UI", 14, FontStyle.Bold);
        
        int startX = 10 - _scrollOffset;
        int y = barY + 15;
        
        var visibleMessages = _messages.Take(MaxMessagesVisible).ToList();
        
        for (int i = 0; i < visibleMessages.Count; i++)
        {
            var msg = visibleMessages[i];
            
            // Calcola alpha in base al timer (fade out)
            int alpha = Math.Min(255, (int)((msg.Timer / (float)MessageDuration) * 255));
            alpha = Math.Max(50, alpha);
            
            var msgColor = Color.FromArgb(alpha, msg.Color);
            
            using var brush = new SolidBrush(msgColor);
            using var shadowBrush = new SolidBrush(Color.FromArgb(alpha / 2, 0, 0, 0));
            
            // Ombra
            g.DrawString(msg.Message, font, shadowBrush, startX + 1, y + 1);
            
            // Testo
            g.DrawString(msg.Message, font, brush, startX, y);
            
            // Misura il testo per calcolare l'offset del prossimo
            var size = g.MeasureString(msg.Message, font);
            startX += (int)size.Width + 20;
            
            // Seconda riga se necessario
            if (i == 1)
            {
                y += 20;
                startX = 10 - _scrollOffset;
            }
        }
        
        // Indicatore di scorrimento (frecce)
        if (_messages.Count > MaxMessagesVisible)
        {
            using var arrowBrush = new SolidBrush(Color.FromArgb(150, 255, 255, 0));
            g.DrawString("►", new Font("Arial", 12, FontStyle.Bold), arrowBrush, screenWidth - 30, barY + 15);
        }
    }
}
