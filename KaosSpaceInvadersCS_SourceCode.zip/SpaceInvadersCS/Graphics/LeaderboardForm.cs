using System.Drawing;
using System.Windows.Forms;

namespace SpaceInvaders.GraphicsMode;

public class LeaderboardForm : Form
{
    private readonly LeaderboardManager _leaderboardManager;
    private DataGridView _gridView = null!;
    
    public LeaderboardForm()
    {
        _leaderboardManager = new LeaderboardManager();
        InitializeComponents();
        LoadScores();
    }
    
    private void InitializeComponents()
    {
        Text = "Punteggi Alti";
        Size = new Size(600, 500);
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        BackColor = Color.FromArgb(20, 20, 30);
        
        // Title label
        var titleLabel = new Label
        {
            Text = "🏆 PUNTEGGI ALTI 🏆",
            Font = new Font("Consolas", 24, FontStyle.Bold),
            ForeColor = Color.Gold,
            BackColor = Color.Transparent,
            Location = new Point(0, 20),
            Size = new Size(600, 40),
            TextAlign = ContentAlignment.MiddleCenter
        };
        Controls.Add(titleLabel);
        
        // Data grid view
        _gridView = new DataGridView
        {
            Location = new Point(50, 80),
            Size = new Size(500, 300),
            BackgroundColor = Color.FromArgb(30, 30, 40),
            ForeColor = Color.White,
            GridColor = Color.FromArgb(50, 50, 60),
            ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
            {
                BackColor = Color.FromArgb(40, 40, 50),
                ForeColor = Color.Cyan,
                Font = new Font("Consolas", 12, FontStyle.Bold),
                Alignment = DataGridViewContentAlignment.MiddleCenter
            },
            DefaultCellStyle = new DataGridViewCellStyle
            {
                BackColor = Color.FromArgb(30, 30, 40),
                ForeColor = Color.White,
                Font = new Font("Consolas", 11),
                SelectionBackColor = Color.FromArgb(70, 70, 80),
                SelectionForeColor = Color.Yellow
            },
            RowHeadersVisible = false,
            AllowUserToAddRows = false,
            AllowUserToDeleteRows = false,
            AllowUserToResizeRows = false,
            AllowUserToResizeColumns = false,
            ReadOnly = true,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            MultiSelect = false,
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
            EnableHeadersVisualStyles = false,
            BorderStyle = BorderStyle.Fixed3D
        };
        
        _gridView.ColumnHeadersHeight = 35;
        _gridView.RowTemplate.Height = 30;
        
        Controls.Add(_gridView);
        
        // Close button
        var closeButton = new Button
        {
            Text = "CHIUDI",
            Font = new Font("Arial", 14, FontStyle.Bold),
            Location = new Point(225, 400),
            Size = new Size(150, 50),
            BackColor = Color.FromArgb(100, 100, 255),
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            Cursor = Cursors.Hand
        };
        closeButton.FlatAppearance.BorderSize = 0;
        closeButton.Click += (s, e) => Close();
        Controls.Add(closeButton);
        
        // Clear scores button
        var clearButton = new Button
        {
            Text = "CANCELLA TUTTO",
            Font = new Font("Arial", 10, FontStyle.Bold),
            Location = new Point(430, 10),
            Size = new Size(150, 35),
            BackColor = Color.FromArgb(200, 50, 50),
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            Cursor = Cursors.Hand
        };
        clearButton.FlatAppearance.BorderSize = 0;
        clearButton.Click += ClearButton_Click;
        Controls.Add(clearButton);
    }
    
    private void LoadScores()
    {
        var scores = _leaderboardManager.GetTopScores();
        
        // Setup columns
        _gridView.Columns.Clear();
        _gridView.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "Rank",
            HeaderText = "POSIZIONE",
            Width = 90
        });
        _gridView.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "Player",
            HeaderText = "GIOCATORE",
            Width = 140
        });
        _gridView.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "Score",
            HeaderText = "PUNTEGGIO",
            Width = 120
        });
        _gridView.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "Level",
            HeaderText = "LIVELLO",
            Width = 80
        });
        _gridView.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "Date",
            HeaderText = "DATA",
            Width = 150
        });
        
        // Add rows
        _gridView.Rows.Clear();
        int rank = 1;
        foreach (var score in scores)
        {
            string rankText = rank switch
            {
                1 => "🥇 1°",
                2 => "🥈 2°",
                3 => "🥉 3°",
                _ => $"   {rank}°"
            };
            
            _gridView.Rows.Add(
                rankText,
                score.PlayerName,
                score.Score.ToString("N0"),
                score.Level,
                score.Date.ToLocalTime().ToString("yyyy-MM-dd HH:mm")
            );
            
            rank++;
        }
        
        // Highlight top 3 with colors
        if (_gridView.Rows.Count > 0)
            _gridView.Rows[0].DefaultCellStyle.BackColor = Color.FromArgb(60, 50, 30); // Gold tint
        if (_gridView.Rows.Count > 1)
            _gridView.Rows[1].DefaultCellStyle.BackColor = Color.FromArgb(50, 50, 50); // Silver tint
        if (_gridView.Rows.Count > 2)
            _gridView.Rows[2].DefaultCellStyle.BackColor = Color.FromArgb(50, 40, 30); // Bronze tint
    }
    
    private void ClearButton_Click(object? sender, EventArgs e)
    {
        var result = MessageBox.Show(
            "Sei sicuro di voler cancellare tutti i punteggi alti?",
            "Cancella Punteggi Alti",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning
        );
        
        if (result == DialogResult.Yes)
        {
            _leaderboardManager.Clear();
            LoadScores();
            MessageBox.Show(
                "Tutti i punteggi alti sono stati cancellati!",
                "Cancellati",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information
            );
        }
    }
}
