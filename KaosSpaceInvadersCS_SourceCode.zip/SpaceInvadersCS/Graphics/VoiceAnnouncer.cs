using System;

namespace SpaceInvaders.GraphicsMode;

// Voice announcement system with subtitle support
// NOTE: Full TTS will be implemented with proper speech library
public class VoiceAnnouncer : IDisposable
{
    private readonly Queue<string> _messageQueue;
    private bool _isProcessing;
    
    public event Action<string>? OnSubtitleShow;
    
    public VoiceAnnouncer()
    {
        _messageQueue = new Queue<string>();
        _isProcessing = false;
    }
    
    public void Announce(string message)
    {
        _messageQueue.Enqueue(message);
        if (!_isProcessing)
        {
            ProcessQueue();
        }
    }
    
    private async void ProcessQueue()
    {
        if (_messageQueue.Count == 0)
        {
            _isProcessing = false;
            return;
        }
        
        _isProcessing = true;
        string message = _messageQueue.Dequeue();
        
        // Show subtitle
        OnSubtitleShow?.Invoke(message);
        
        // Simulate voice with notification sound
        await Task.Run(() =>
        {
            try
            {
                // Play alert tone
                Console.Beep(800, 150);
                Thread.Sleep(50);
                Console.Beep(1000, 150);
            }
            catch
            {
                // Ignore if beep is not supported
            }
        });
        
        // Wait for subtitle duration
        await Task.Delay(3000);
        ProcessQueue();
    }
    
    public void AnnounceGameStart()
    {
        Announce("Prepararsi al combattimento. Invasione aliena rilevata!");
    }
    
    public void AnnounceUFOArrival()
    {
        Announce("Attenzione! Astronave nemica in arrivo.");
    }
    
    public void AnnounceWaveIncoming(int wave)
    {
        Announce($"Onda numero {wave} in arrivo. Preparare le difese!");
    }
    
    public void AnnouncePlayerHit()
    {
        Announce("Scudi danneggiati! Attenzione!");
    }
    
    public void AnnounceLowAliens()
    {
        Announce("Ultimi nemici rimanenti. Completare la missione!");
    }
    
    public void AnnounceVictory()
    {
        Announce("Missione completata! Invasione respinta con successo!");
    }
    
    public void AnnounceGameOver()
    {
        Announce("Scudi distrutti. Missione fallita.");
    }
    
    public void AnnounceCombo(int count)
    {
        Announce($"Combo di {count} colpi! Eccellente mira!");
    }
    
    public void AnnounceHighScore()
    {
        Announce("Nuovo record personale! Straordinario!");
    }
    
    public void AnnouncePowerUp(string powerUpName)
    {
        Announce($"Potenziamento {powerUpName} attivato!");
    }
    
    public void AnnounceShieldCritical()
    {
        Announce("Allarme! Scudi a livelli critici!");
    }
    
    public void AnnounceBossWave()
    {
        Announce("Attenzione! Comandante nemico rilevato!");
    }
    
    public void Stop()
    {
        _messageQueue.Clear();
        _isProcessing = false;
    }
    
    public void Dispose()
    {
        Stop();
    }
}
