using System.Drawing;
using System.Windows.Forms;
using SpaceInvaders.GraphicsMode;

namespace SpaceInvaders.GraphicsMode;

public partial class GameForm : Form
{
    private GameEngine? _engine;
    private readonly GamePanel _gamePanel;
    private readonly GraphicsRenderer _renderer;
    private readonly System.Windows.Forms.Timer _gameTimer;
    private bool _isRunning;

    private ParticleSystem? _particleSystem;
    private SoundManager? _soundManager;
    private LeaderboardManager? _leaderboardManager;
    private LeaderboardDisplay? _leaderboardDisplay;
    private VoiceAnnouncer? _voiceAnnouncer;
    private AIBotCompanion? _aiBotCompanion;
    private CortanaHelper? _cortanaHelper;
    private CortanaChatUI? _cortanaChatUI;
    private MessageBar? _messageBar;
    private bool _highScoreChecked;
    private int _frameCounter;

    private readonly Label _welcomeLabel;
    private readonly Button _startButton;
    private readonly Label _copyrightLabel;
    private PictureBox? _logoPictureBox;
    private PictureBox? _originalLogoPictureBox; // Logo originale in basso a sinistra

    // Key state tracking for smooth input
    private bool _leftPressed;
    private bool _rightPressed;
    private bool _spacePressed;
    private bool _rPressed;
    private bool _cPressed;

    public GameForm()
    {
        InitializeComponents();

        _gamePanel = new GamePanel
        {
            Location = new Point(0, 40),
            Size = new Size(800, 560),
            TabStop = false
        };

        // Logo in alto
        _logoPictureBox = new PictureBox
        {
            Location = new Point(250, 30),
            Size = new Size(300, 150),
            SizeMode = PictureBoxSizeMode.Zoom,
            BackColor = Color.Black
        };

        try
        {
            string logoPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "space8225.png");
            if (File.Exists(logoPath))
            {
                _logoPictureBox.Image = Image.FromFile(logoPath);
            }
        }
        catch
        {
            // Se il logo non viene caricato, continua senza errori
        }

        // Logo originale in basso a sinistra
        _originalLogoPictureBox = new PictureBox
        {
            Location = new Point(10, 470),  // Basso a sinistra (sopra copyright)
            Size = new Size(180, 80),        // Più grande per visibilità
            SizeMode = PictureBoxSizeMode.Zoom,
            BackColor = Color.Transparent,
            Visible = true  // Esplicitamente visibile
        };

        try
        {
            string origLogoPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "spaceinvorig.png");
            if (File.Exists(origLogoPath))
            {
                _originalLogoPictureBox.Image = Image.FromFile(origLogoPath);
                Console.WriteLine($"Logo originale caricato da: {origLogoPath}");
            }
            else
            {
                Console.WriteLine($"Logo originale NON trovato: {origLogoPath}");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Errore caricamento logo: {ex.Message}");
        }

        _welcomeLabel = new Label
        {
            Text = "* KAOS SPACE INVADERS AI 2025 *\n\nPremi START o CLICK per iniziare!\n\nComandi:\n← → o A D: Muovi (Mouse)\nSPAZIO: Spara (sx Mouse)\nY: Chiama Cortana (dx Mouse)\nESC: Esci\n\nbasato su Space Invaders (TM) - Taito, 1978",
            Font = new Font("Consolas", 14, FontStyle.Bold),
            ForeColor = Color.Cyan,
            BackColor = Color.Transparent, // Trasparente per vedere il logo sotto
            Location = new Point(150, 190),
            Size = new Size(500, 280),
            TextAlign = ContentAlignment.MiddleCenter
        };

        _startButton = new Button
        {
            Text = " ** START GAME **",
            Font = new Font("Arial", 12, FontStyle.Bold),
            Location = new Point(300, 430),
            Size = new Size(200, 60),
            BackColor = Color.Lime,
            ForeColor = Color.Black,
            Visible = false // Nascosto, basta il click o START
        };
        _startButton.Click += StartButton_Click;

        // Label copyright in fondo a pagina
        _copyrightLabel = new Label
        {
            Text = "TM@ RS 2025 v1.0",
            Font = new Font("Consolas", 10, FontStyle.Bold),
            ForeColor = Color.Gray,
            BackColor = Color.Black,
            Location = new Point(350, 520),
            Size = new Size(100, 20),
            TextAlign = ContentAlignment.MiddleCenter
        };

        if (_logoPictureBox != null)
        {
            _gamePanel.Controls.Add(_logoPictureBox);
        }
        _gamePanel.Controls.Add(_welcomeLabel);
        _gamePanel.Controls.Add(_startButton);
        _gamePanel.Controls.Add(_copyrightLabel);

        // Aggiungi il logo originale DOPO per renderlo visibile sopra gli altri controlli
        if (_originalLogoPictureBox != null)
        {
            _gamePanel.Controls.Add(_originalLogoPictureBox);
            _originalLogoPictureBox.BringToFront(); // Porta in primo piano
        }

        Controls.Add(_gamePanel);

        _renderer = new GraphicsRenderer(_gamePanel);

        _gameTimer = new System.Windows.Forms.Timer
        {
            Interval = 30   // ~30 FPS, 30 frame al secondo
        };
        _gameTimer.Tick += GameTimer_Tick;

        KeyPreview = true;
        KeyDown += GameForm_KeyDown;
        KeyUp += GameForm_KeyUp;

        // Mouse controls
        _gamePanel.MouseMove += GamePanel_MouseMove;
        _gamePanel.MouseDown += GamePanel_MouseDown;
        _gamePanel.Cursor = Cursors.Cross; // Crosshair cursor

        // KeyPress for text input in Cortana Chat
        this.KeyPress += GameForm_KeyPress;
    }

    private void InitializeComponents()
    {
        Text = "Kaos Space Invaders AI 2025";
        Size = new Size(816, 639);
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        BackColor = Color.Black;

        // Menu bar
        var menuStrip = new MenuStrip();
        var gameMenu = new ToolStripMenuItem("Gioco");

        var newGameItem = new ToolStripMenuItem("Nuova Partita", null, (s, e) => StartNewGame());
        newGameItem.ShortcutKeys = Keys.F2;

        var volumeMenu = new ToolStripMenuItem("Volume Audio");
        var volume100 = new ToolStripMenuItem("100%", null, (s, e) => SetVolume(1.0f));
        var volume75 = new ToolStripMenuItem("75%", null, (s, e) => SetVolume(0.75f));
        var volume50 = new ToolStripMenuItem("50% ✓", null, (s, e) => SetVolume(0.5f));
        var volume25 = new ToolStripMenuItem("25%", null, (s, e) => SetVolume(0.25f));
        var volumeMute = new ToolStripMenuItem("Muto", null, (s, e) => SetVolume(0f));
        volumeMenu.DropDownItems.AddRange(new[] { volume100, volume75, volume50, volume25, volumeMute });

        var exitItem = new ToolStripMenuItem("Esci", null, (s, e) => Close());
        exitItem.ShortcutKeys = Keys.Alt | Keys.F4;

        gameMenu.DropDownItems.Add(newGameItem);
        gameMenu.DropDownItems.Add(volumeMenu);
        gameMenu.DropDownItems.Add(new ToolStripSeparator());
        gameMenu.DropDownItems.Add(exitItem);

        var helpMenu = new ToolStripMenuItem("Aiuto");
        var aboutItem = new ToolStripMenuItem("Informazioni", null, (s, e) => ShowAbout());
        helpMenu.DropDownItems.Add(aboutItem);

        menuStrip.Items.Add(gameMenu);
        menuStrip.Items.Add(helpMenu);

        Controls.Add(menuStrip);
    }

    private void StartButton_Click(object? sender, EventArgs e)
    {
        StartNewGame();
    }

    private void StartNewGame()
    {
        _welcomeLabel.Visible = false;
        _startButton.Visible = false;
        _copyrightLabel.Visible = false;

        // Nascondi i loghi quando il gioco inizia
        if (_logoPictureBox != null)
        {
            _logoPictureBox.Visible = false;
        }
        if (_originalLogoPictureBox != null)
        {
            _originalLogoPictureBox.Visible = false;
        }

        // Initialize systems
        _particleSystem = new ParticleSystem();
        _soundManager = new SoundManager();
        _leaderboardManager = new LeaderboardManager();
        _leaderboardDisplay = new LeaderboardDisplay(_leaderboardManager);
        _voiceAnnouncer = new VoiceAnnouncer();
        _aiBotCompanion = new AIBotCompanion();
        _cortanaHelper = new CortanaHelper();
        _cortanaChatUI = new CortanaChatUI();
        _messageBar = new MessageBar();
        _highScoreChecked = false;

        // BOB greets the player
        _aiBotCompanion.GreetPlayer();

        // Connect BOB messages to MessageBar
        _aiBotCompanion.OnBobMessage += (message, color) =>
        {
            _messageBar?.AddMessage($"BOB: {message}", color);
        };

        // Connect subtitle system to voice announcer - DISABILITATO, usiamo MessageBar
        // _voiceAnnouncer.OnSubtitleShow += (text) => _subtitleSystem?.ShowSubtitle(text);

        // Invece mandiamo i messaggi della voce alla MessageBar
        _voiceAnnouncer.OnSubtitleShow += (text) =>
        {
            _messageBar?.AddMessage(text, Color.Cyan);
        };

        _engine = new GameEngine();

        // Subscribe to game events
        _engine.OnShoot += (x, y, isPlayer) =>
        {
            _soundManager?.PlayShoot();
            if (_particleSystem != null)
            {
                // Convert console coordinates to screen coordinates (x * 8, y * 15)
                _particleSystem.AddBulletTrail(x * 8, y * 15, isPlayer);
            }

            // AI bot reaction
            if (isPlayer)
            {
                _aiBotCompanion?.OnShoot();
            }
        };

        _engine.OnExplosion += (x, y, color) =>
        {
            _soundManager?.PlayExplosion();
            if (_particleSystem != null)
            {
                _particleSystem.AddExplosion(x * 8, y * 15, color, 30);
            }
        };

        _engine.OnAlienHit += (x, y) =>
        {
            // Check for combo and low alien count
            int alienCount = CountActiveAliens();
            if (alienCount <= 5)
            {
                _voiceAnnouncer?.AnnounceLowAliens();
            }
        };

        _engine.OnPlayerHit += () =>
        {
            _soundManager?.PlayHit();
            _voiceAnnouncer?.AnnouncePlayerHit();
            _aiBotCompanion?.OnHit();

            // Check if shields are critical
            if (_engine != null && _engine.Player.Lives <= 1)
            {
                _voiceAnnouncer?.AnnounceShieldCritical();
            }
        };

        _engine.OnGameOver += () =>
        {
            _soundManager?.PlayGameOver();
            _voiceAnnouncer?.AnnounceGameOver();
        };

        _engine.OnVictory += () =>
        {
            _soundManager?.PlayVictory();
            _soundManager?.StopHeartbeat();
            _voiceAnnouncer?.AnnounceVictory();
            _aiBotCompanion?.OnVictory();

            // Check for high score
            if (_leaderboardManager != null && _leaderboardManager.IsHighScore(_engine?.Player.Score ?? 0))
            {
                _voiceAnnouncer?.AnnounceHighScore();
            }
        };

        _engine.OnUFODestroyed += (bonusScore) =>
        {
            _soundManager?.PlayUFO();
            // Show bonus score notification
            ShowBonusNotification(bonusScore);
        };

        _engine.OnUFOSpawned += () =>
        {
            _voiceAnnouncer?.AnnounceUFOArrival();
        };

        _engine.OnGandalfAppears += () =>
        {
            // Gandalf appare - solo messaggio nella barra
        };

        _engine.OnCortanaActivated += () =>
        {
            // Effetto sonoro speciale per Cortana (usa suono UFO come speciale)
            _soundManager?.PlayUFO();
        };

        _engine.OnSnakeSpawned += () =>
        {
            // Snake appare! Mostra messaggio nella MessageBar
            _messageBar?.AddMessage("🐍 SNAKE APPARE! 1000 punti!", Color.Green);
        };

        // Cortana spawna snake casuali
        _cortanaHelper.OnRandomSnakeSpawn += (randomX) =>
        {
            _engine?.SpawnRandomSnake(randomX);
            _messageBar?.AddMessage("⚡ Cortana lancia uno SNAKE! ⚡", Color.Cyan);
        };

        // Pac-Man ringrazia quando salvi il fantasmino
        _engine.OnPacManMessage += (message) =>
        {
            _messageBar?.AddMessage(message, Color.Yellow);
            _soundManager?.PlayVictory(); // Suono di gioia
        };

        // Eventi meteo
        _engine.OnLightningStrike += (positions) =>
        {
            _messageBar?.AddMessage("⚡ FULMINE! Alieni colpiti!", Color.Yellow);
            _soundManager?.PlayExplosion();
        };

        _engine.OnWeatherChange += (weatherName) =>
        {
            _messageBar?.AddMessage($"🌤️ CLIMA ALERT! Nuovo clima: {weatherName}", Color.Cyan);
        };

        _engine.OnAsteroidImpact += (x, y, size) =>
        {
            // Crea esplosione marrone/arancione al suolo
            _particleSystem?.AddExplosion(x * 8, y * 15, Color.Orange, 20 + size * 5);
            _soundManager?.PlayExplosion();
            _messageBar?.AddMessage($"☄️ IMPATTO ASTEROIDE! Cratere creato!", Color.Orange);
        };

        // Eventi Cortana Chat UI
        _cortanaChatUI.SetGameEngine(_engine);

        _cortanaChatUI.OnUserMessage += (message) =>
        {
            _messageBar?.AddMessage($"Tu: {message}", Color.LightGreen);
        };

        _cortanaChatUI.OnCortanaResponse += (message) =>
        {
            _messageBar?.AddMessage($"Cortana: {message}", Color.Cyan);
        };

        _isRunning = true;
        _leftPressed = false;
        _rightPressed = false;
        _spacePressed = false;
        _rPressed = false;
        _cPressed = false;

        // Start heartbeat music
        _soundManager?.StartHeartbeat(55);

        // Announce game start
        _voiceAnnouncer?.AnnounceGameStart();

        _gameTimer.Start();
    }

    private void GameTimer_Tick(object? sender, EventArgs e)
    {
        if (!_isRunning || _engine == null) return;

        // Process held keys
        if (_leftPressed)
        {
            _engine.PlayerMoveLeft();
        }
        if (_rightPressed)
        {
            _engine.PlayerMoveRight();
        }
        if (_spacePressed)
        {
            _engine.PlayerShoot();
        }
        if (_rPressed && (_engine.IsGameOver || _engine.IsVictory))
        {
            StartNewGame();
            return;
        }

        _engine.Update();
        _engine.UpdatePlayerShootState();

        // Update particle system
        _particleSystem?.Update();

        // Update AI bot companion
        _aiBotCompanion?.Update();

        // Update Cortana helper
        _cortanaHelper?.Update();

        // Update Cortana Chat UI
        _cortanaChatUI?.Update();

        // Update Leaderboard Display
        _leaderboardDisplay?.Update();

        // Update message bar
        _messageBar?.Update();

        // Update heartbeat speed based on alien count (every 30 frames to avoid too many restarts)
        if (_frameCounter++ % 30 == 0 && _soundManager != null && _engine != null)
        {
            int alienCount = CountActiveAliens();
            if (alienCount > 0)
            {
                _soundManager.StartHeartbeat(alienCount);
            }
        }

        // Check for high score at game end
        if ((_engine.IsGameOver || _engine.IsVictory) && !_highScoreChecked)
        {
            CheckHighScore();
            _highScoreChecked = true;
        }

        _renderer.Render(_engine, _particleSystem, _aiBotCompanion, _cortanaHelper, _cortanaChatUI, _leaderboardDisplay, _messageBar);
    }

    private void GameForm_KeyDown(object? sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Escape)
        {
            if (_isRunning)
            {
                _gameTimer.Stop();
                var result = MessageBox.Show("Uscire dal gioco?", "Space Invaders",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    Close();
                }
                else
                {
                    _gameTimer.Start();
                }
            }
            else
            {
                Close();
            }
            return;
        }

        // Set key state to true when pressed
        switch (e.KeyCode)
        {
            case Keys.Left:
            case Keys.A:
                _leftPressed = true;
                break;
            case Keys.Right:
            case Keys.D:
                _rightPressed = true;
                break;
            case Keys.Space:
                _spacePressed = true;
                break;
            case Keys.R:
                _rPressed = true;
                break;
            case Keys.C:
                _cPressed = true;
                // Toggle Cortana Chat UI
                _cortanaChatUI?.Toggle();
                break;
            case Keys.Y:
                // Attiva Cortana
                ActivateCortana();
                break;
        }

        // Prevent key repeat
        e.Handled = true;
        e.SuppressKeyPress = true;
    }

    private void GameForm_KeyUp(object? sender, KeyEventArgs e)
    {
        // Set key state to false when released
        switch (e.KeyCode)
        {
            case Keys.Left:
            case Keys.A:
                _leftPressed = false;
                break;
            case Keys.Right:
            case Keys.D:
                _rightPressed = false;
                break;
            case Keys.Space:
                _spacePressed = false;
                break;
            case Keys.R:
                _rPressed = false;
                break;
            case Keys.C:
                _cPressed = false;
                break;
        }
    }

    private void GameForm_KeyPress(object? sender, KeyPressEventArgs e)
    {
        // Handle text input for Cortana Chat UI
        if (_cortanaChatUI != null && _cortanaChatUI.IsVisible)
        {
            _cortanaChatUI.HandleKeyPress(e.KeyChar);
            e.Handled = true;
        }
    }

    private void GamePanel_MouseMove(object? sender, MouseEventArgs e)
    {
        if (_isRunning && _engine != null)
        {
            // Convert mouse X position to game coordinates (0-99)
            int gameX = (int)((e.X / (float)_gamePanel.Width) * 100);
            gameX = Math.Clamp(gameX, 0, 99);

            // Update player position directly
            _engine.SetPlayerPosition(gameX);
        }
    }

    private void GamePanel_MouseDown(object? sender, MouseEventArgs e)
    {
        // Se il gioco non è ancora partito, avvia con click sinistro
        if (!_isRunning && e.Button == MouseButtons.Left)
        {
            StartNewGame();
            return;
        }

        if (_isRunning && _engine != null)
        {
            if (e.Button == MouseButtons.Left)
            {
                _engine.PlayerShoot();
            }
            else if (e.Button == MouseButtons.Right)
            {
                // Attiva Cortana con tasto destro
                ActivateCortana();
            }
        }
    }

    private void ActivateCortana()
    {
        if (_engine != null && _cortanaHelper != null && _isRunning)
        {
            if (_cortanaHelper.TryActivate())
            {
                // Cortana disponibile - ripristina barriere
                _engine.ActivateCortana();
            }
            // Il messaggio viene mostrato automaticamente da CortanaHelper
        }
    }

    private void SetVolume(float volume)
    {
        if (_soundManager != null)
        {
            _soundManager.Volume = volume;
        }
    }

    //About info
    private void ShowAbout()
    {
        // Show about dialog
        MessageBox.Show(
            "Kaos Space Invaders AI 2025\n\n" +
            "Versione 1.0\n" +
            "Creato da RS\n\n" +
            "Versione Kaos di Space Invaders\n\n" +
            "Comandi:\n" +
            "← → o A D: Muovi astronave (Mouse)\n" +
            "SPAZIO: Spara\n" +
            "Y: Chiama Cortana in aiuto\n" +
            "ESC: Esci\n\n" +
            "Distruggi tutti i 55 alieni per vincere!\n" +
            "UFO: Colpisci l'UFO per punti bonus!",
            "basato su Space Invaders (Tm) Arcade - Taito, 1978\n" +
            "Informazioni Space Invaders",
            MessageBoxButtons.OK,
            MessageBoxIcon.Information
        );
    }

    private void ShowLeaderboard()
    {
        var leaderboardForm = new LeaderboardForm();
        leaderboardForm.ShowDialog(this);
    }

    private void CheckHighScore()
    {
        if (_engine == null || _leaderboardManager == null || _leaderboardDisplay == null) return;

        int currentScore = _engine.Player.Score;
        int currentLevel = _engine.CurrentLevel;

        // Controlla se il punteggio entra in classifica
        if (_leaderboardManager.IsHighScore(currentScore))
        {
            // Ferma il gioco
            _gameTimer.Stop();

            // Chiedi il nome al giocatore
            var nameDialog = new HighScoreNameDialog(currentScore, 1); // rank temporaneo
            nameDialog.ShowDialog(this);

            string playerName = nameDialog.PlayerName;

            // Aggiungi il punteggio alla classifica
            int rank = _leaderboardManager.AddScore(playerName, currentScore, currentLevel);

            // Mostra animazione record con classifica
            _leaderboardDisplay.ShowWithRecordAnimation(rank);

            // Messaggio di congratulazioni
            _aiBotCompanion?.OnNewRecord();
            _messageBar?.AddMessage($"🏆 #{rank} IN CLASSIFICA! {currentScore:N0} punti! 🏆", Color.Gold);
            _soundManager?.PlayVictory();

            // Riprendi il gioco dopo 1 secondo
            System.Threading.Tasks.Task.Delay(1000).ContinueWith(_ =>
            {
                this.Invoke((MethodInvoker)delegate
                {
                    if (!_isRunning)
                    {
                        _gameTimer.Start();
                    }
                });
            });
        }
    }

    private string PromptForPlayerName()
    {
        var inputForm = new Form
        {
            Text = "Inserisci il Tuo Nome",
            Size = new Size(400, 180),
            StartPosition = FormStartPosition.CenterParent,
            FormBorderStyle = FormBorderStyle.FixedDialog,
            MaximizeBox = false,
            MinimizeBox = false,
            BackColor = Color.FromArgb(30, 30, 40)
        };

        var label = new Label
        {
            Text = "🌟 Hai ottenuto un PUNTEGGIO ALTO! 🌟\nInserisci il tuo nome:",
            Location = new Point(20, 20),
            Size = new Size(350, 40),
            ForeColor = Color.Yellow,
            Font = new Font("Consolas", 11, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleCenter
        };

        var textBox = new TextBox
        {
            Location = new Point(50, 70),
            Size = new Size(300, 25),
            Font = new Font("Consolas", 12),
            MaxLength = 20,
            Text = "GIOCATORE"
        };
        textBox.SelectAll();

        var okButton = new Button
        {
            Text = "OK",
            Location = new Point(100, 105),
            Size = new Size(90, 30),
            DialogResult = DialogResult.OK,
            BackColor = Color.FromArgb(100, 200, 100),
            ForeColor = Color.White,
            Font = new Font("Arial", 10, FontStyle.Bold)
        };

        var cancelButton = new Button
        {
            Text = "Annulla",
            Location = new Point(210, 105),
            Size = new Size(90, 30),
            DialogResult = DialogResult.Cancel,
            BackColor = Color.FromArgb(150, 150, 150),
            ForeColor = Color.White,
            Font = new Font("Arial", 10, FontStyle.Bold)
        };

        inputForm.Controls.Add(label);
        inputForm.Controls.Add(textBox);
        inputForm.Controls.Add(okButton);
        inputForm.Controls.Add(cancelButton);
        inputForm.AcceptButton = okButton;
        inputForm.CancelButton = cancelButton;

        return inputForm.ShowDialog(this) == DialogResult.OK ? textBox.Text.Trim() : "GIOCATORE";
    }

    private int CountActiveAliens()
    {
        if (_engine == null) return 0;

        return _engine.GetAllEntities()
            .Count(e => e.Type == EntityType.AlienType1 ||
                       e.Type == EntityType.AlienType2 ||
                       e.Type == EntityType.AlienType3);
    }

    private void ShowBonusNotification(int bonusScore)
    {
        // Create a temporary label to show bonus score
        var bonusLabel = new Label
        {
            Text = $"+{bonusScore} BONUS!",
            Font = new Font("Consolas", 20, FontStyle.Bold),
            ForeColor = Color.Cyan,
            BackColor = Color.Transparent,
            Location = new Point(300, 150),
            Size = new Size(250, 40),
            TextAlign = ContentAlignment.MiddleCenter
        };

        _gamePanel.Controls.Add(bonusLabel);
        bonusLabel.BringToFront();

        // Remove after 2 seconds
        var timer = new System.Windows.Forms.Timer { Interval = 2000 };
        timer.Tick += (s, e) =>
        {
            _gamePanel.Controls.Remove(bonusLabel);
            bonusLabel.Dispose();
            timer.Stop();
            timer.Dispose();
        };
        timer.Start();
    }

    private void InitializeComponent()
    {

    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        _soundManager?.StopHeartbeat();
        _soundManager?.Dispose();
        _gameTimer.Stop();
        _isRunning = false;
        base.OnFormClosing(e);
    }
}
