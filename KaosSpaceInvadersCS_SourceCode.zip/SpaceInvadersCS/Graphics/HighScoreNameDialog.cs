using System;
using System.Drawing;
using System.Windows.Forms;

namespace SpaceInvaders.GraphicsMode
{
    /// <summary>
    /// Dialog per inserire il nome quando si raggiunge un punteggio alto
    /// </summary>
    public class HighScoreNameDialog : Form
    {
        private TextBox _nameTextBox;
        private Label _messageLabel;
        private Label _scoreLabel;
        private Button _okButton;
        private Button _cancelButton;

        public string PlayerName { get; private set; } = "Anonymous";
        public int Score { get; set; }
        public int Rank { get; set; }

        public HighScoreNameDialog(int score, int rank)
        {
            Score = score;
            Rank = rank;
            
            InitializeComponents();
        }

        private void InitializeComponents()
        {
            // Form properties
            this.Text = "🏆 NUOVO RECORD!";
            this.Size = new Size(450, 280);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = Color.FromArgb(20, 30, 60);

            // Trophy label (icon)
            var trophyLabel = new Label
            {
                Text = "🏆",
                Font = new Font("Segoe UI Emoji", 48, FontStyle.Bold),
                ForeColor = Color.Gold,
                AutoSize = true,
                Location = new Point(180, 15)
            };
            this.Controls.Add(trophyLabel);

            // Message label
            _messageLabel = new Label
            {
                Text = $"Complimenti! Sei entrato in classifica al #{Rank} posto!",
                Font = new Font("Arial", 12, FontStyle.Bold),
                ForeColor = Color.Yellow,
                AutoSize = false,
                TextAlign = ContentAlignment.MiddleCenter,
                Size = new Size(400, 30),
                Location = new Point(25, 80)
            };
            this.Controls.Add(_messageLabel);

            // Score label
            _scoreLabel = new Label
            {
                Text = $"Punteggio: {Score:N0}",
                Font = new Font("Consolas", 14, FontStyle.Bold),
                ForeColor = Color.LightGreen,
                AutoSize = false,
                TextAlign = ContentAlignment.MiddleCenter,
                Size = new Size(400, 25),
                Location = new Point(25, 115)
            };
            this.Controls.Add(_scoreLabel);

            // Instruction label
            var instructionLabel = new Label
            {
                Text = "Inserisci il tuo nome:",
                Font = new Font("Arial", 11, FontStyle.Regular),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point(50, 150)
            };
            this.Controls.Add(instructionLabel);

            // Name text box
            _nameTextBox = new TextBox
            {
                Font = new Font("Arial", 12, FontStyle.Regular),
                MaxLength = 20,
                Size = new Size(340, 25),
                Location = new Point(50, 175),
                Text = "Player1"
            };
            _nameTextBox.KeyPress += NameTextBox_KeyPress;
            this.Controls.Add(_nameTextBox);

            // OK button
            _okButton = new Button
            {
                Text = "OK",
                Font = new Font("Arial", 11, FontStyle.Bold),
                Size = new Size(100, 35),
                Location = new Point(120, 210),
                BackColor = Color.Green,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                DialogResult = DialogResult.OK
            };
            _okButton.FlatAppearance.BorderColor = Color.LimeGreen;
            _okButton.FlatAppearance.BorderSize = 2;
            _okButton.Click += OkButton_Click;
            this.Controls.Add(_okButton);

            // Cancel button
            _cancelButton = new Button
            {
                Text = "Salta",
                Font = new Font("Arial", 11, FontStyle.Regular),
                Size = new Size(100, 35),
                Location = new Point(230, 210),
                BackColor = Color.Gray,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                DialogResult = DialogResult.Cancel
            };
            _cancelButton.FlatAppearance.BorderColor = Color.DarkGray;
            _cancelButton.FlatAppearance.BorderSize = 2;
            _cancelButton.Click += CancelButton_Click;
            this.Controls.Add(_cancelButton);

            // Set default buttons
            this.AcceptButton = _okButton;
            this.CancelButton = _cancelButton;

            // Focus on text box
            _nameTextBox.Focus();
            _nameTextBox.SelectAll();
        }

        private void NameTextBox_KeyPress(object? sender, KeyPressEventArgs e)
        {
            // Allow only letters, numbers, spaces, and basic punctuation
            if (!char.IsLetterOrDigit(e.KeyChar) && 
                e.KeyChar != ' ' && 
                e.KeyChar != '_' && 
                e.KeyChar != '-' &&
                e.KeyChar != '\b') // Allow backspace
            {
                e.Handled = true;
            }
        }

        private void OkButton_Click(object? sender, EventArgs e)
        {
            PlayerName = _nameTextBox.Text.Trim();
            
            if (string.IsNullOrWhiteSpace(PlayerName))
            {
                PlayerName = "Anonymous";
            }

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void CancelButton_Click(object? sender, EventArgs e)
        {
            PlayerName = "Anonymous";
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            // Draw golden border around form
            using (var pen = new Pen(Color.Gold, 3))
            {
                e.Graphics.DrawRectangle(pen, 2, 2, this.ClientSize.Width - 4, this.ClientSize.Height - 4);
            }
        }
    }
}
