using System.Drawing;
using System.Drawing.Drawing2D;

namespace SpaceInvaders;

public class ObiWanHelper
{
    private bool _isActive;
    private int _timer;
    private int _animationFrame;
    private const int AppearanceDuration = 180; // 6 secondi a 30 FPS
    private const int MessageDuration = 90; // 3 secondi
    private float _messageAlpha;
    private string _message = "Che la forza sia con voi!";
    private static Image? _obiWanImage;
    private static bool _obiWanImageLoaded = false;
    private List<Point> _laserEffects = new List<Point>();
    private int _laserEffectTimer = 0;
    
    public bool IsActive => _isActive;
    public bool HasAppeared { get; private set; }
    
    public void Activate()
    {
        _isActive = true;
        _timer = AppearanceDuration;
        _animationFrame = 0;
        _messageAlpha = 0;
        HasAppeared = true;
        _laserEffects.Clear();
        _laserEffectTimer = 0;
    }
    
    public void Update()
    {
        if (!_isActive) return;
        
        _timer--;
        _animationFrame++;
        
        // Gestione laser effect
        if (_laserEffectTimer > 0)
        {
            _laserEffectTimer--;
        }
        
        // Fade in del messaggio
        if (_timer > AppearanceDuration - 30)
        {
            _messageAlpha = (AppearanceDuration - _timer) / 30f;
        }
        // Mantieni messaggio visibile
        else if (_timer > 30)
        {
            _messageAlpha = 1.0f;
        }
        // Fade out
        else if (_timer > 0)
        {
            _messageAlpha = _timer / 30f;
        }
        
        if (_timer <= 0)
        {
            _isActive = false;
        }
    }
    
    public void AddLaserEffect(int x, int y)
    {
        _laserEffects.Add(new Point(x, y));
        _laserEffectTimer = 30; // Effetto dura 1 secondo
    }
    
    public void Draw(Graphics g, int screenWidth, int screenHeight, int frame)
    {
        if (!_isActive) return;
        
        // Carica immagine se necessario
        if (!_obiWanImageLoaded)
        {
            try
            {
                string imagePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "YodaAttack.png");
                if (File.Exists(imagePath))
                {
                    _obiWanImage = Image.FromFile(imagePath);
                }
            }
            catch
            {
                _obiWanImage = null;
            }
            _obiWanImageLoaded = true;
        }
        
        // Posizione centrale
        int centerX = screenWidth / 2;
        int centerY = screenHeight / 2;
        
        // Effetto di entrata (fade in con scala)
        float fadeIn = 1.0f;
        if (_timer > AppearanceDuration - 20)
        {
            fadeIn = (AppearanceDuration - _timer) / 20f;
        }
        
        // Disegna aura di forza (blu)
        DrawForceAura(g, centerX, centerY, frame, fadeIn);
        
        // Disegna Obi-Wan
        if (_obiWanImage != null)
        {
            int imageWidth = 150;
            int imageHeight = 200;
            int x = centerX - imageWidth / 2;
            int y = centerY - imageHeight / 2;
            
            // Bordo blu luminescente (come Jedi)
            using (var blueGlowPen = new Pen(Color.FromArgb((int)(200 * fadeIn), 0, 100, 255), 4))
            {
                g.DrawRectangle(blueGlowPen, x - 4, y - 4, imageWidth + 8, imageHeight + 8);
            }
            
            // Glow blu esterno
            using (var blueGlowBrush = new SolidBrush(Color.FromArgb((int)(40 * fadeIn), 0, 100, 255)))
            {
                g.FillRectangle(blueGlowBrush, x - 8, y - 8, imageWidth + 16, imageHeight + 16);
            }
            
            // Disegna immagine con trasparenza
            var colorMatrix = new System.Drawing.Imaging.ColorMatrix
            {
                Matrix33 = fadeIn
            };
            var imageAttributes = new System.Drawing.Imaging.ImageAttributes();
            imageAttributes.SetColorMatrix(colorMatrix);
            
            g.DrawImage(_obiWanImage, 
                new Rectangle(x, y, imageWidth, imageHeight),
                0, 0, _obiWanImage.Width, _obiWanImage.Height,
                GraphicsUnit.Pixel, imageAttributes);
        }
        else
        {
            // Fallback: disegno semplificato
            DrawObiWanFallback(g, centerX, centerY, fadeIn);
        }
        
        // Disegna effetti laser sugli alieni colpiti
        if (_laserEffectTimer > 0 && _laserEffects.Count > 0)
        {
            foreach (var point in _laserEffects)
            {
                DrawLightsaberStrike(g, point.X, point.Y, frame);
            }
        }
        
        // Disegna messaggio centrato
        if (_messageAlpha > 0)
        {
            DrawMessage(g, centerX, centerY + 150, _message, _messageAlpha);
        }
    }
    
    private void DrawForceAura(Graphics g, int centerX, int centerY, int frame, float alpha)
    {
        float pulse = (float)Math.Sin(frame * 0.15) * 0.3f + 0.7f;
        int radius = (int)(200 * pulse);
        
        // Aura blu della Forza
        using (var auraBrush = new SolidBrush(Color.FromArgb((int)(30 * alpha * pulse), 0, 150, 255)))
        {
            g.FillEllipse(auraBrush, centerX - radius, centerY - radius, radius * 2, radius * 2);
        }
        
        // Cerchi concentrici
        for (int i = 1; i <= 3; i++)
        {
            int r = (int)(radius * i / 3f);
            using (var circlePen = new Pen(Color.FromArgb((int)(50 * alpha * pulse), 100, 200, 255), 2))
            {
                g.DrawEllipse(circlePen, centerX - r, centerY - r, r * 2, r * 2);
            }
        }
    }
    
    private void DrawObiWanFallback(Graphics g, int centerX, int centerY, float alpha)
    {
        g.SmoothingMode = SmoothingMode.AntiAlias;
        
        // Mantello marrone chiaro (Jedi)
        using (var cloakBrush = new SolidBrush(Color.FromArgb((int)(255 * alpha), 160, 130, 100)))
        {
            g.FillRectangle(cloakBrush, centerX - 40, centerY - 50, 80, 120);
        }
        
        // Testa
        using (var faceBrush = new SolidBrush(Color.FromArgb((int)(255 * alpha), 240, 220, 200)))
        {
            g.FillEllipse(faceBrush, centerX - 25, centerY - 80, 50, 60);
        }
        
        // Barba (grigio-bianco come Obi-Wan)
        using (var beardBrush = new SolidBrush(Color.FromArgb((int)(255 * alpha), 200, 200, 200)))
        {
            Point[] beard = {
                new Point(centerX - 15, centerY - 40),
                new Point(centerX, centerY - 10),
                new Point(centerX + 15, centerY - 40)
            };
            g.FillPolygon(beardBrush, beard);
        }
        
        // Spada laser blu
        DrawLightsaber(g, centerX + 30, centerY - 20, _animationFrame, alpha);
    }
    
    private void DrawLightsaber(Graphics g, int x, int y, int frame, float alpha)
    {
        float pulse = (float)Math.Sin(frame * 0.2) * 0.2f + 0.8f;
        
        // Lama blu brillante
        using (var bladeBrush = new SolidBrush(Color.FromArgb((int)(200 * alpha * pulse), 100, 200, 255)))
        {
            g.FillRectangle(bladeBrush, x, y, 8, 80);
        }
        
        // Glow esterno
        using (var glowBrush = new SolidBrush(Color.FromArgb((int)(100 * alpha * pulse), 150, 220, 255)))
        {
            g.FillRectangle(glowBrush, x - 3, y, 14, 80);
        }
        
        // Impugnatura
        using (var handleBrush = new SolidBrush(Color.FromArgb((int)(255 * alpha), 100, 100, 100)))
        {
            g.FillRectangle(handleBrush, x + 2, y + 80, 4, 20);
        }
    }
    
    private void DrawLightsaberStrike(Graphics g, int x, int y, int frame)
    {
        // Effetto di taglio con spada laser
        float pulse = (float)Math.Sin(frame * 0.3) * 0.5f + 0.5f;
        
        // Croce luminosa
        using (var strikePen = new Pen(Color.FromArgb((int)(200 * pulse), 100, 200, 255), 4))
        {
            g.DrawLine(strikePen, x - 20, y - 20, x + 20, y + 20);
            g.DrawLine(strikePen, x - 20, y + 20, x + 20, y - 20);
        }
        
        // Particelle blu
        Random rand = new Random(frame + x + y);
        for (int i = 0; i < 8; i++)
        {
            int px = x + rand.Next(-30, 30);
            int py = y + rand.Next(-30, 30);
            int size = rand.Next(2, 6);
            using (var particleBrush = new SolidBrush(Color.FromArgb((int)(150 * pulse), 150, 220, 255)))
            {
                g.FillEllipse(particleBrush, px, py, size, size);
            }
        }
    }
    
    private void DrawMessage(Graphics g, int centerX, int centerY, string message, float alpha)
    {
        using var font = new Font("Arial", 14, FontStyle.Bold);
        SizeF textSize = g.MeasureString(message, font);
        
        int x = (int)(centerX - textSize.Width / 2);
        int y = centerY;
        int padding = 15;
        int bubbleAlpha = (int)(255 * alpha);
        
        // Background con bordo
        Rectangle bgRect = new Rectangle(x - padding, y - padding, 
            (int)textSize.Width + padding * 2, (int)textSize.Height + padding * 2);
        
        // Glow esterno giallo (colore Star Wars)
        for (int i = 2; i >= 0; i--)
        {
            using (var glowPen = new Pen(Color.FromArgb(bubbleAlpha / (i + 2), 255, 220, 0), 2))
            {
                Rectangle glowRect = bgRect;
                glowRect.Inflate(i * 2, i * 2);
                g.DrawRectangle(glowPen, glowRect);
            }
        }
        
        // Background semi-trasparente
        using (var bgBrush = new SolidBrush(Color.FromArgb(bubbleAlpha * 2 / 3, 0, 0, 0)))
        {
            g.FillRectangle(bgBrush, bgRect);
        }
        
        // Bordo giallo
        using (var borderPen = new Pen(Color.FromArgb(bubbleAlpha, 255, 220, 0), 2))
        {
            g.DrawRectangle(borderPen, bgRect);
        }
        
        // Testo con ombra
        using (var shadowBrush = new SolidBrush(Color.FromArgb(bubbleAlpha, 0, 0, 0)))
        {
            g.DrawString(message, font, shadowBrush, x + 1, y + 1);
        }
        
        // Testo bianco brillante
        using (var textBrush = new SolidBrush(Color.FromArgb(bubbleAlpha, 255, 255, 255)))
        {
            g.DrawString(message, font, textBrush, x, y);
        }
    }
}
