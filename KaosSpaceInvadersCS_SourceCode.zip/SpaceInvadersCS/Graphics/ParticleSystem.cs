namespace SpaceInvaders.GraphicsMode;

public class Explosion
{
    public int X { get; set; }
    public int Y { get; set; }
    public int Frame { get; set; }
    public int MaxFrames { get; set; }
    public bool IsActive { get; set; }
    public Color Color { get; set; }
    
    public Explosion(int x, int y, Color color)
    {
        X = x;
        Y = y;
        Frame = 0;
        MaxFrames = 15; // 15 frames of animation
        IsActive = true;
        Color = color;
    }
    
    public void Update()
    {
        Frame++;
        if (Frame >= MaxFrames)
        {
            IsActive = false;
        }
    }
}

public class Particle
{
    public float X { get; set; }
    public float Y { get; set; }
    public float VelocityX { get; set; }
    public float VelocityY { get; set; }
    public Color Color { get; set; }
    public int Life { get; set; }
    public int MaxLife { get; set; }
    public int Size { get; set; }
    
    public bool IsActive => Life > 0;
    
    public Particle(float x, float y, float vx, float vy, Color color, int life, int size)
    {
        X = x;
        Y = y;
        VelocityX = vx;
        VelocityY = vy;
        Color = color;
        Life = life;
        MaxLife = life;
        Size = size;
    }
    
    public void Update()
    {
        X += VelocityX;
        Y += VelocityY;
        VelocityY += 0.2f; // Gravity
        Life--;
    }
}

public class ParticleSystem
{
    private readonly List<Particle> _particles;
    private readonly Random _random;
    
    public ParticleSystem()
    {
        _particles = new List<Particle>();
        _random = new Random();
    }
    
    public void AddExplosion(int x, int y, Color color, int particleCount = 20)
    {
        for (int i = 0; i < particleCount; i++)
        {
            float angle = (float)(_random.NextDouble() * Math.PI * 2);
            float speed = (float)(_random.NextDouble() * 3 + 2);
            float vx = (float)Math.Cos(angle) * speed;
            float vy = (float)Math.Sin(angle) * speed;
            
            int life = _random.Next(15, 30);
            int size = _random.Next(2, 6);
            
            _particles.Add(new Particle(x, y, vx, vy, color, life, size));
        }
    }
    
    public void AddBulletTrail(int x, int y, bool isPlayer)
    {
        Color color = isPlayer ? Color.FromArgb(150, Color.Cyan) : Color.FromArgb(150, Color.OrangeRed);
        int life = _random.Next(3, 8);
        _particles.Add(new Particle(x, y, 0, 0, color, life, 3));
    }
    
    public void Update()
    {
        foreach (var particle in _particles)
        {
            particle.Update();
        }
        _particles.RemoveAll(p => !p.IsActive);
    }
    
    public void Draw(Graphics g)
    {
        foreach (var particle in _particles)
        {
            int alpha = (int)(255 * ((float)particle.Life / particle.MaxLife));
            Color color = Color.FromArgb(Math.Max(0, alpha), particle.Color);
            
            using var brush = new SolidBrush(color);
            g.FillEllipse(brush, particle.X - particle.Size / 2, particle.Y - particle.Size / 2, 
                         particle.Size, particle.Size);
        }
    }
    
    public void Clear()
    {
        _particles.Clear();
    }
}
