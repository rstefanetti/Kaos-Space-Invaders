using System.Drawing;

namespace SpaceInvaders;

public interface IGraphicsSprite
{
    void Draw(Graphics g, int x, int y, int frame);
    int Width { get; }
    int Height { get; }
}
