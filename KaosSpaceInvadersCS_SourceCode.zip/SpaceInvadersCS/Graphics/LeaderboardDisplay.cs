using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;

namespace SpaceInvaders.GraphicsMode
{
    /// <summary>
    /// Visualizza la classifica punteggi con effetto coppa per record
    /// Mostra top 10 con nome, punteggio, livello e data
    /// </summary>
    public class LeaderboardDisplay
    {
        private readonly LeaderboardManager _manager;
        private bool _isVisible;
        private int _recordRank; // Posizione del nuovo record (1-10)
        private int _highlightFrame;
        private bool _showRecordAnimation;

        public bool IsVisible => _isVisible;
        public bool ShowRecordAnimation => _showRecordAnimation;
        public int RecordRank => _recordRank;

        public LeaderboardDisplay(LeaderboardManager manager)
        {
            _manager = manager;
            _isVisible = false;
            _recordRank = 0;
            _highlightFrame = 0;
            _showRecordAnimation = false;
        }

        public void Show()
        {
            _isVisible = true;
        }

        public void Hide()
        {
            _isVisible = false;
        }

        public void ShowWithRecordAnimation(int rank)
        {
            _isVisible = true;
            _showRecordAnimation = true;
            _recordRank = rank;
            _highlightFrame = 0;
        }

        public void Update()
        {
            if (_showRecordAnimation)
            {
                _highlightFrame++;
                
                // Animazione dura 5 secondi
                if (_highlightFrame > 150)
                {
                    _showRecordAnimation = false;
                    _highlightFrame = 0;
                }
            }
        }

        public void Draw(Graphics g, int screenWidth, int screenHeight)
        {
            if (!_isVisible) return;

            g.SmoothingMode = SmoothingMode.AntiAlias;

            // Semi-transparent background overlay
            using (var overlayBrush = new SolidBrush(Color.FromArgb(220, 0, 0, 0)))
            {
                g.FillRectangle(overlayBrush, 0, 0, screenWidth, screenHeight);
            }

            // Main leaderboard panel
            int panelWidth = 600;
            int panelHeight = 500;
            int panelX = (screenWidth - panelWidth) / 2;
            int panelY = (screenHeight - panelHeight) / 2;

            Rectangle panelRect = new Rectangle(panelX, panelY, panelWidth, panelHeight);

            // Draw panel background with gradient
            using (var gradientBrush = new LinearGradientBrush(
                panelRect,
                Color.FromArgb(240, 20, 30, 60),
                Color.FromArgb(240, 10, 15, 40),
                LinearGradientMode.Vertical))
            {
                using (var path = CreateRoundedRectangle(panelRect, 20))
                {
                    g.FillPath(gradientBrush, path);

                    // Golden border
                    using (var pen = new Pen(Color.Gold, 4))
                    {
                        g.DrawPath(pen, path);
                    }
                }
            }

            // Title
            DrawTitle(g, panelX, panelY, panelWidth);

            // Trophy for record (if showing record animation)
            if (_showRecordAnimation && _recordRank > 0)
            {
                DrawRecordTrophy(g, panelX + panelWidth / 2, panelY + 80);
            }

            // Draw leaderboard entries
            DrawLeaderboardEntries(g, panelX + 30, panelY + 120, panelWidth - 60);

            // Instructions at bottom
            DrawInstructions(g, panelX, panelY + panelHeight - 40, panelWidth);
        }

        private void DrawTitle(Graphics g, int x, int y, int width)
        {
            string title = "* CLASSIFICA MIGLIORI PUNTEGGI *";

            using (var font = new Font("Arial", 22, FontStyle.Bold))
            using (var brush = new SolidBrush(Color.Gold))
            using (var shadowBrush = new SolidBrush(Color.Black))
            {
                SizeF titleSize = g.MeasureString(title, font);
                float titleX = x + (width - titleSize.Width) / 2;
                float titleY = y + 20;

                // Shadow
                g.DrawString(title, font, shadowBrush, titleX + 3, titleY + 3);
                // Main text
                g.DrawString(title, font, brush, titleX, titleY);
            }
        }

        private void DrawRecordTrophy(Graphics g, int centerX, int centerY)
        {
            // Animated pulsating trophy
            float scale = 1.0f + (float)Math.Sin(_highlightFrame * 0.1) * 0.15f;
            int size = (int)(80 * scale);

            // Draw trophy emoji/symbol
            using (var font = new Font("Segoe UI Emoji", size, FontStyle.Bold))
            using (var brush = new SolidBrush(Color.Gold))
            using (var shadowBrush = new SolidBrush(Color.FromArgb(150, 0, 0, 0)))
            {
                string trophy = "🏆";
                SizeF trophySize = g.MeasureString(trophy, font);
                
                float trophyX = centerX - trophySize.Width / 2;
                float trophyY = centerY - trophySize.Height / 2;

                // Shadow
                g.DrawString(trophy, font, shadowBrush, trophyX + 4, trophyY + 4);
                // Trophy
                g.DrawString(trophy, font, brush, trophyX, trophyY);
            }

            // "NUOVO RECORD!" text
            using (var font = new Font("Arial", 18, FontStyle.Bold))
            using (var brush = new SolidBrush(Color.Yellow))
            {
                string recordText = $"NUOVO RECORD #{_recordRank}!";
                SizeF textSize = g.MeasureString(recordText, font);
                float textX = centerX - textSize.Width / 2;
                float textY = centerY + 60;

                // Pulsating text
                if (_highlightFrame % 20 < 10)
                {
                    g.DrawString(recordText, font, brush, textX, textY);
                }
            }
        }

        private void DrawLeaderboardEntries(Graphics g, int x, int y, int width)
        {
            var entries = _manager.GetTopScores(10);
            int entryHeight = 32;

            using (var rankFont = new Font("Arial", 14, FontStyle.Bold))
            using (var nameFont = new Font("Arial", 12, FontStyle.Regular))
            using (var scoreFont = new Font("Consolas", 12, FontStyle.Bold))
            using (var dateFont = new Font("Arial", 9, FontStyle.Italic))
            {
                for (int i = 0; i < entries.Count; i++)
                {
                    var entry = entries[i];
                    int entryY = y + i * entryHeight;
                    bool isNewRecord = _showRecordAnimation && (i + 1) == _recordRank;

                    // Highlight background for new record
                    if (isNewRecord)
                    {
                        int alpha = 100 + (int)(Math.Sin(_highlightFrame * 0.2) * 50);
                        using (var highlightBrush = new SolidBrush(Color.FromArgb(alpha, 255, 215, 0)))
                        {
                            g.FillRectangle(highlightBrush, x - 10, entryY - 2, width + 20, entryHeight - 2);
                        }
                    }

                    // Rank color based on position
                    Color rankColor = GetRankColor(i + 1);
                    using (var rankBrush = new SolidBrush(rankColor))
                    using (var nameBrush = new SolidBrush(Color.White))
                    using (var scoreBrush = new SolidBrush(Color.LightGreen))
                    using (var dateBrush = new SolidBrush(Color.Gray))
                    {
                        // Rank
                        string rankText = $"{i + 1}.";
                        g.DrawString(rankText, rankFont, rankBrush, x, entryY);

                        // Medal for top 3
                        if (i < 3)
                        {
                            string medal = GetMedalEmoji(i + 1);
                            g.DrawString(medal, rankFont, rankBrush, x + 30, entryY);
                        }

                        // Player name
                        string playerName = entry.PlayerName.Length > 15 
                            ? entry.PlayerName.Substring(0, 15) 
                            : entry.PlayerName;
                        g.DrawString(playerName, nameFont, nameBrush, x + 70, entryY + 2);

                        // Score
                        string scoreText = $"{entry.Score:N0}";
                        SizeF scoreSize = g.MeasureString(scoreText, scoreFont);
                        g.DrawString(scoreText, scoreFont, scoreBrush, x + width - scoreSize.Width - 120, entryY + 2);

                        // Level
                        string levelText = $"Lv.{entry.Level}";
                        g.DrawString(levelText, dateFont, dateBrush, x + width - 80, entryY + 2);

                        // Date
                        string dateText = entry.Date.ToString("dd/MM/yy");
                        g.DrawString(dateText, dateFont, dateBrush, x + width - 120, entryY + 16);
                    }
                }
            }

            // Empty slots message
            if (entries.Count < 10)
            {
                using (var font = new Font("Arial", 11, FontStyle.Italic))
                using (var brush = new SolidBrush(Color.Gray))
                {
                    string message = $"({10 - entries.Count} posizioni disponibili)";
                    SizeF messageSize = g.MeasureString(message, font);
                    g.DrawString(message, font, brush, 
                        x + (width - messageSize.Width) / 2, 
                        y + entries.Count * entryHeight + 10);
                }
            }
        }

        private void DrawInstructions(Graphics g, int x, int y, int width)
        {
            string instructions = "Premi ESC per chiudere";

            using (var font = new Font("Arial", 12, FontStyle.Italic))
            using (var brush = new SolidBrush(Color.LightGray))
            {
                SizeF textSize = g.MeasureString(instructions, font);
                float textX = x + (width - textSize.Width) / 2;
                g.DrawString(instructions, font, brush, textX, y);
            }
        }

        private Color GetRankColor(int rank)
        {
            return rank switch
            {
                1 => Color.Gold,        // 🥇
                2 => Color.Silver,      // 🥈
                3 => Color.Orange,      // 🥉
                _ => Color.LightBlue
            };
        }

        private string GetMedalEmoji(int rank)
        {
            return rank switch
            {
                1 => "🥇",
                2 => "🥈",
                3 => "🥉",
                _ => ""
            };
        }

        private GraphicsPath CreateRoundedRectangle(Rectangle bounds, int radius)
        {
            GraphicsPath path = new GraphicsPath();
            int diameter = radius * 2;

            path.AddArc(bounds.X, bounds.Y, diameter, diameter, 180, 90);
            path.AddArc(bounds.Right - diameter, bounds.Y, diameter, diameter, 270, 90);
            path.AddArc(bounds.Right - diameter, bounds.Bottom - diameter, diameter, diameter, 0, 90);
            path.AddArc(bounds.X, bounds.Bottom - diameter, diameter, diameter, 90, 90);
            path.CloseFigure();

            return path;
        }
    }
}
