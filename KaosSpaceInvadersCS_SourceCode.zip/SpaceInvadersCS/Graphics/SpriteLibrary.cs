using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;

namespace SpaceInvaders.GraphicsMode;

public class SpriteLibrary
{
    private static Image? _gandalfImage;
    private static bool _gandalfImageLoaded = false;
    private static Image? _playerShipImage;
    private static bool _playerShipImageLoaded = false;
    
    public static void DrawProtectiveShield(Graphics g, int centerX, int centerY, int size, int frame)
    {
        // Scudo esagonale rotante attorno alla nave
        g.SmoothingMode = SmoothingMode.AntiAlias;
        
        float rotation = (frame * 2) % 360;
        float pulseIntensity = (float)Math.Sin(frame * 0.1) * 0.2f + 0.8f;
        
        // Salva stato
        var state = g.Save();
        g.TranslateTransform(centerX, centerY);
        g.RotateTransform(rotation);
        
        // Disegna esagono (scudo energetico)
        int shieldRadius = (int)(size * 1.5f);
        Point[] hexagon = new Point[6];
        for (int i = 0; i < 6; i++)
        {
            double angle = Math.PI / 3 * i;
            hexagon[i] = new Point(
                (int)(shieldRadius * Math.Cos(angle)),
                (int)(shieldRadius * Math.Sin(angle))
            );
        }
        
        // Glow esterno cyan
        using (var glowPen = new Pen(Color.FromArgb((int)(80 * pulseIntensity), 0, 255, 255), 8))
        {
            g.DrawPolygon(glowPen, hexagon);
        }
        
        // Bordo principale cyan brillante
        using (var shieldPen = new Pen(Color.FromArgb((int)(200 * pulseIntensity), 100, 255, 255), 3))
        {
            g.DrawPolygon(shieldPen, hexagon);
        }
        
        // Linee interne incrociate
        using (var innerPen = new Pen(Color.FromArgb((int)(100 * pulseIntensity), 150, 255, 255), 1))
        {
            g.DrawLine(innerPen, hexagon[0], hexagon[3]);
            g.DrawLine(innerPen, hexagon[1], hexagon[4]);
            g.DrawLine(innerPen, hexagon[2], hexagon[5]);
        }
        
        g.Restore(state);
    }
    
    public static void DrawPlayer(Graphics g, int x, int y, int size)
    {
        // Disegna nave custom 3D a forma di freccia/navetta spaziale
        g.SmoothingMode = SmoothingMode.AntiAlias;
        
        int shipWidth = (int)(size * 1.8f);
        int shipHeight = (int)(size * 1.6f);
        
        // Centra
        int drawX = x - shipWidth / 2;
        int drawY = y - shipHeight / 2;
        
        // CORPO PRINCIPALE - forma a freccia/navetta
        Point[] shipShape = new Point[]
        {
            new Point(drawX + shipWidth / 2, drawY), // Punta superiore
            new Point(drawX + shipWidth, drawY + shipHeight - 8), // Ala destra estesa
            new Point(drawX + (int)(shipWidth * 0.8f), drawY + shipHeight), // Base destra
            new Point(drawX + shipWidth / 2, drawY + (int)(shipHeight * 0.85f)), // Centro basso (cockpit)
            new Point(drawX + (int)(shipWidth * 0.2f), drawY + shipHeight), // Base sinistra
            new Point(drawX, drawY + shipHeight - 8) // Ala sinistra estesa
        };
        
        using (var shipPath = new GraphicsPath())
        {
            shipPath.AddPolygon(shipShape);
            
            // Gradiente metallico blu-ciano per il corpo
            using (var bodyBrush = new LinearGradientBrush(
                new Rectangle(drawX, drawY, shipWidth, shipHeight),
                Color.FromArgb(255, 30, 144, 255), // Blu brillante (DodgerBlue)
                Color.FromArgb(255, 0, 50, 120), // Blu scuro
                90f))
            {
                g.FillPath(bodyBrush, shipPath);
            }
            
            // Bordo luminoso
            using (var borderPen = new Pen(Color.FromArgb(200, 100, 200, 255), 2))
            {
                g.DrawPath(borderPen, shipPath);
            }
        }
        
        // COCKPIT centrale (parte superiore luminosa)
        Point[] cockpitShape = new Point[]
        {
            new Point(drawX + shipWidth / 2, drawY + 4),
            new Point(drawX + (int)(shipWidth * 0.65f), drawY + shipHeight / 2),
            new Point(drawX + shipWidth / 2, drawY + (int)(shipHeight * 0.7f)),
            new Point(drawX + (int)(shipWidth * 0.35f), drawY + shipHeight / 2)
        };
        
        using (var cockpitPath = new GraphicsPath())
        {
            cockpitPath.AddPolygon(cockpitShape);
            using (var cockpitBrush = new LinearGradientBrush(
                new Rectangle(drawX + shipWidth / 4, drawY, shipWidth / 2, shipHeight * 3 / 4),
                Color.FromArgb(180, 150, 220, 255), // Ciano chiaro
                Color.FromArgb(100, 50, 150, 220),
                90f))
            {
                g.FillPath(cockpitBrush, cockpitPath);
            }
        }
        
        // MOTORI (due rettangoli luminosi alla base)
        // Motore sinistro
        using (var engineBrush = new LinearGradientBrush(
            new Rectangle(drawX + (int)(shipWidth * 0.25f), drawY + shipHeight - 12, 8, 10),
            Color.FromArgb(255, 255, 100, 0), // Arancione brillante
            Color.FromArgb(255, 255, 50, 50), // Rosso
            90f))
        {
            g.FillRectangle(engineBrush, drawX + (int)(shipWidth * 0.25f), drawY + shipHeight - 12, 8, 10);
        }
        
        // Motore destro
        using (var engineBrush = new LinearGradientBrush(
            new Rectangle(drawX + (int)(shipWidth * 0.67f), drawY + shipHeight - 12, 8, 10),
            Color.FromArgb(255, 255, 100, 0),
            Color.FromArgb(255, 255, 50, 50),
            90f))
        {
            g.FillRectangle(engineBrush, drawX + (int)(shipWidth * 0.67f), drawY + shipHeight - 12, 8, 10);
        }
        
        // Glow dei motori
        using (var glowBrush = new SolidBrush(Color.FromArgb(100, 255, 150, 0)))
        {
            g.FillEllipse(glowBrush, drawX + (int)(shipWidth * 0.23f), drawY + shipHeight - 8, 12, 8);
            g.FillEllipse(glowBrush, drawX + (int)(shipWidth * 0.65f), drawY + shipHeight - 8, 12, 8);
        }
        
        // HIGHLIGHT 3D sulla parte superiore
        using (var highlightBrush = new LinearGradientBrush(
            new Rectangle(drawX + shipWidth / 3, drawY + 2, shipWidth / 3, shipHeight / 4),
            Color.FromArgb(120, 255, 255, 255),
            Color.FromArgb(0, 255, 255, 255),
            90f))
        {
            g.FillEllipse(highlightBrush, drawX + (int)(shipWidth * 0.38f), drawY + 6, shipWidth / 4, shipHeight / 6);
        }
    }
    
    public static void DrawAlien(Graphics g, int x, int y, int type, int frame, int size)
    {
        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        
        Color baseColor = type switch
        {
            1 => Color.FromArgb(200, 0, 0),      // Type 1: Dark Red
            2 => Color.FromArgb(200, 180, 0),    // Type 2: Dark Yellow
            _ => Color.FromArgb(180, 0, 180)     // Type 3: Dark Magenta
        };
        
        Color highlightColor = type switch
        {
            1 => Color.FromArgb(255, 80, 80),    // Red highlight
            2 => Color.FromArgb(255, 240, 100),  // Yellow highlight
            _ => Color.FromArgb(255, 100, 255)   // Magenta highlight
        };
        
        // Animated alien body
        int offset = frame % 2 == 0 ? 0 : 3;
        
        // Shadow below alien (more pronounced for 3D depth)
        using var shadowBrush = new SolidBrush(Color.FromArgb(80, 0, 0, 0));
        g.FillEllipse(shadowBrush, x + 4, y + size - 3, size - 8, 8);
        
        // Secondary shadow layer for more depth
        using var shadowBrush2 = new SolidBrush(Color.FromArgb(40, 0, 0, 0));
        g.FillEllipse(shadowBrush2, x + 2, y + size - 2, size - 4, 10);
        
        // Main body with enhanced 3D gradient (radial for spherical look)
        Rectangle body = new Rectangle(x + offset, y + 5, size - offset * 2, size - 10);
        
        // Use PathGradientBrush for better 3D spherical effect
        using var bodyPath = new System.Drawing.Drawing2D.GraphicsPath();
        bodyPath.AddRectangle(body);
        using var bodyGradient = new System.Drawing.Drawing2D.PathGradientBrush(bodyPath);
        bodyGradient.CenterPoint = new PointF(body.X + body.Width * 0.3f, body.Y + body.Height * 0.3f);
        bodyGradient.CenterColor = highlightColor;  // Bright center (light source)
        bodyGradient.SurroundColors = new[] { baseColor }; // Dark edges
        g.FillPath(bodyGradient, bodyPath);
        
        // Add rim lighting effect (bright edge on one side)
        using var rimLightPen = new Pen(Color.FromArgb(150, 255, 255, 255), 3);
        g.DrawLine(rimLightPen, body.Left + 1, body.Top + 2, body.Left + 1, body.Bottom - 2);
        
        // Dark edge on opposite side for contrast
        using var darkEdgePen = new Pen(Color.FromArgb(100, 0, 0, 0), 2);
        g.DrawLine(darkEdgePen, body.Right - 2, body.Top + 2, body.Right - 2, body.Bottom - 2);
        
        // Body outline for definition
        using var outlinePen = new Pen(Color.FromArgb(120, 0, 0, 0), 2);
        g.DrawRectangle(outlinePen, body);
        
        // Specular highlight (shiny spot) for metallic/wet look
        using var specularBrush = new SolidBrush(Color.FromArgb(180, 255, 255, 255));
        g.FillEllipse(specularBrush, body.X + body.Width/4, body.Y + body.Height/4, 6, 4);
        
        // Eyes with glow effect
        using var eyeGlowPath1 = new System.Drawing.Drawing2D.GraphicsPath();
        eyeGlowPath1.AddEllipse(x + 3 + offset, y + 6, 8, 8);
        using var eyeGlow1 = new System.Drawing.Drawing2D.PathGradientBrush(eyeGlowPath1);
        eyeGlow1.CenterColor = Color.FromArgb(220, 255, 255, 100);  // Bright yellow center
        eyeGlow1.SurroundColors = new[] { Color.FromArgb(150, 200, 100, 0) };
        g.FillPath(eyeGlow1, eyeGlowPath1);
        
        using var eyeGlowPath2 = new System.Drawing.Drawing2D.GraphicsPath();
        eyeGlowPath2.AddEllipse(x + size - 11 + offset, y + 6, 8, 8);
        using var eyeGlow2 = new System.Drawing.Drawing2D.PathGradientBrush(eyeGlowPath2);
        eyeGlow2.CenterColor = Color.FromArgb(220, 255, 255, 100);
        eyeGlow2.SurroundColors = new[] { Color.FromArgb(150, 200, 100, 0) };
        g.FillPath(eyeGlow2, eyeGlowPath2);
        
        // Pupils (glowing red)
        using var pupilBrush = new SolidBrush(Color.FromArgb(200, 255, 50, 50));
        g.FillEllipse(pupilBrush, x + 6 + offset, y + 9, 3, 3);
        g.FillEllipse(pupilBrush, x + size - 9 + offset, y + 9, 3, 3);
        
        // Antennae with glow at tips
        using var antennaPen = new Pen(Color.FromArgb(200, 255, 255, 255), 2);
        g.DrawLine(antennaPen, x + size/3, y + 5, x + size/3, y);
        g.DrawLine(antennaPen, x + 2*size/3, y + 5, x + 2*size/3, y);
        
        // Antenna tips with radial glow
        using var antennaGlow = new SolidBrush(highlightColor);
        g.FillEllipse(antennaGlow, x + size/3 - 3, y - 3, 6, 6);
        g.FillEllipse(antennaGlow, x + 2*size/3 - 3, y - 3, 6, 6);
        
        // Brighter core
        using var antennaCoreGlow = new SolidBrush(Color.FromArgb(255, 255, 255));
        g.FillEllipse(antennaCoreGlow, x + size/3 - 1, y - 1, 2, 2);
        g.FillEllipse(antennaCoreGlow, x + 2*size/3 - 1, y - 1, 2, 2);
        
        // Legs (animated) with shading
        using var legPen = new Pen(Color.FromArgb(180, 255, 255, 255), 2);
        for (int i = 0; i < 4; i++)
        {
            int legX = x + 5 + i * (size - 10) / 3;
            int legY = y + size - 5;
            g.DrawLine(legPen, legX, legY, legX + (frame % 2 == 0 ? -2 : 2), legY + 5);
        }
    }
    
    public static void DrawBullet(Graphics g, int x, int y, bool isPlayer, int size)
    {
        Color color = isPlayer ? Color.Cyan : Color.OrangeRed;
        using var brush = new SolidBrush(color);
        using var pen = new Pen(Color.White, 1);
        
        if (isPlayer)
        {
            // Player bullet - LASER beam style
            g.SmoothingMode = SmoothingMode.AntiAlias;
            
            // Outer glow (più spesso)
            using var outerGlowPen = new Pen(Color.FromArgb(60, 0, 255, 255), 6);
            g.DrawLine(outerGlowPen, x, y, x, y + size);
            
            // Middle glow
            using var middleGlowPen = new Pen(Color.FromArgb(120, 100, 255, 255), 4);
            g.DrawLine(middleGlowPen, x, y, x, y + size);
            
            // Inner bright core
            using var corePen = new Pen(Color.FromArgb(255, 200, 255, 255), 2);
            g.DrawLine(corePen, x, y, x, y + size);
            
            // Very bright center line
            using var centerPen = new Pen(Color.White, 1);
            g.DrawLine(centerPen, x, y, x, y + size);
        }
        else
        {
            // Alien bullet - zigzag pattern
            Point[] points = {
                new Point(x - 2, y),
                new Point(x + 2, y + size/3),
                new Point(x - 2, y + 2*size/3),
                new Point(x + 2, y + size)
            };
            using var bulletPen = new Pen(color, 2);
            g.DrawLines(bulletPen, points);
        }
    }
    
    public static void DrawShield(Graphics g, int x, int y, int health, int size)
    {
        Color color = health switch
        {
            3 => Color.Green,
            2 => Color.Yellow,
            1 => Color.Orange,
            _ => Color.Transparent
        };
        
        if (health <= 0) return;
        
        using var brush = new SolidBrush(color);
        using var pen = new Pen(Color.DarkGreen, 1);
        
        // Shield dome shape
        Rectangle rect = new Rectangle(x, y, size, size);
        g.FillPie(brush, rect, 0, -180);
        g.DrawPie(pen, rect, 0, -180);
        
        // Damage cracks based on health
        if (health < 3)
        {
            using var crackPen = new Pen(Color.Black, 2);
            Random rnd = new Random(x + y); // Consistent cracks
            for (int i = 0; i < (3 - health) * 2; i++)
            {
                int x1 = x + rnd.Next(size);
                int y1 = y + rnd.Next(size/2);
                int x2 = x1 + rnd.Next(-5, 5);
                int y2 = y1 + rnd.Next(-5, 5);
                g.DrawLine(crackPen, x1, y1, x2, y2);
            }
        }
    }
    
    public static void DrawUFO(Graphics g, int x, int y, int size)
    {
        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        
        int width = size * 3;
        int height = size;
        
        // Glow esterno fluorescente MOLTO più marcato
        using (var glowPath = new System.Drawing.Drawing2D.GraphicsPath())
        {
            glowPath.AddEllipse(x - 15, y + height / 3 - 15, width + 30, height / 2 + 30);
            using (var glowBrush = new System.Drawing.Drawing2D.PathGradientBrush(glowPath))
            {
                glowBrush.CenterColor = Color.FromArgb(120, 0, 255, 255);
                glowBrush.SurroundColors = new[] { Color.FromArgb(0, 0, 255, 255) };
                g.FillPath(glowBrush, glowPath);
            }
        }
        
        // Secondo alone fluorescente (più stretto e intenso)
        using (var glowPath2 = new System.Drawing.Drawing2D.GraphicsPath())
        {
            glowPath2.AddEllipse(x - 8, y + height / 3 - 8, width + 16, height / 2 + 16);
            using (var glowBrush2 = new System.Drawing.Drawing2D.PathGradientBrush(glowPath2))
            {
                glowBrush2.CenterColor = Color.FromArgb(150, 100, 255, 255);
                glowBrush2.SurroundColors = new[] { Color.FromArgb(0, 0, 255, 255) };
                g.FillPath(glowBrush2, glowPath2);
            }
        }
        
        // Ombra sotto il disco
        using (var shadowBrush = new SolidBrush(Color.FromArgb(60, 0, 0, 0)))
        {
            g.FillEllipse(shadowBrush, x + 5, y + height / 3 + 5, width, height / 2);
        }
        
        // Corpo principale del disco (parte inferiore)
        using (var bodyPath = new System.Drawing.Drawing2D.GraphicsPath())
        {
            bodyPath.AddEllipse(x, y + height / 3, width, height / 2);
            using (var bodyBrush = new System.Drawing.Drawing2D.LinearGradientBrush(
                new Rectangle(x, y + height / 3, width, height / 2),
                Color.FromArgb(255, 180, 180, 200),
                Color.FromArgb(255, 80, 80, 120),
                System.Drawing.Drawing2D.LinearGradientMode.Vertical))
            {
                g.FillPath(bodyBrush, bodyPath);
            }
        }
        
        // Cupola superiore (cabina)
        using (var domePath = new System.Drawing.Drawing2D.GraphicsPath())
        {
            int domeWidth = width / 2;
            int domeHeight = height / 2;
            int domeX = x + width / 4;
            int domeY = y;
            
            domePath.AddEllipse(domeX, domeY, domeWidth, domeHeight);
            using (var domeBrush = new System.Drawing.Drawing2D.LinearGradientBrush(
                new Rectangle(domeX, domeY, domeWidth, domeHeight),
                Color.FromArgb(200, 0, 255, 255),
                Color.FromArgb(255, 0, 150, 200),
                45f))
            {
                g.FillPath(domeBrush, domePath);
            }
        }
        
        // Riflessione sulla cupola
        using (var reflectionBrush = new SolidBrush(Color.FromArgb(100, 255, 255, 255)))
        {
            int domeWidth = width / 2;
            int domeX = x + width / 4;
            int domeY = y;
            g.FillEllipse(reflectionBrush, domeX + domeWidth / 4, domeY + 3, domeWidth / 3, domeWidth / 5);
        }
        
        // Finestre luminose (oblò)
        using (var windowBrush = new SolidBrush(Color.FromArgb(220, 255, 255, 100)))
        using (var windowGlowBrush = new SolidBrush(Color.FromArgb(100, 255, 255, 0)))
        {
            int numWindows = 5;
            for (int i = 0; i < numWindows; i++)
            {
                int wx = x + (width / (numWindows + 1)) * (i + 1) - 4;
                int wy = y + height / 3 + 8;
                
                // Glow finestra
                g.FillEllipse(windowGlowBrush, wx - 2, wy - 2, 12, 12);
                // Finestra
                g.FillEllipse(windowBrush, wx, wy, 8, 8);
            }
        }
        
        // Bordo luminoso fluorescente corpo principale (PIÙ SPESSO E BRILLANTE)
        using (var borderPen = new Pen(Color.FromArgb(255, 100, 255, 255), 3))
        {
            g.DrawEllipse(borderPen, x, y + height / 3, width, height / 2);
        }
        
        // Secondo bordo esterno fluorescente
        using (var outerBorderPen = new Pen(Color.FromArgb(200, 150, 255, 255), 2))
        {
            g.DrawEllipse(outerBorderPen, x - 2, y + height / 3 - 2, width + 4, height / 2 + 4);
        }
        
        // Bordo cupola
        using (var domeBorderPen = new Pen(Color.FromArgb(200, 150, 255, 255), 2f))
        {
            int domeWidth = width / 2;
            int domeHeight = height / 2;
            int domeX = x + width / 4;
            int domeY = y;
            g.DrawEllipse(domeBorderPen, domeX, domeY, domeWidth, domeHeight);
        }
        
        // Dettagli metallici (pannelli)
        using (var detailPen = new Pen(Color.FromArgb(80, 255, 255, 255), 1))
        {
            g.DrawArc(detailPen, x + width / 6, y + height / 3 + 2, width * 2 / 3, height / 3, 0, 180);
        }
    }
    
    public static void DrawExplosion(Graphics g, int x, int y, int frame, int size)
    {
        Random rnd = new Random(frame);
        Color[] colors = { Color.Red, Color.Orange, Color.Yellow, Color.White };
        
        for (int i = 0; i < 20; i++)
        {
            int px = x + rnd.Next(-size, size);
            int py = y + rnd.Next(-size, size);
            int psize = rnd.Next(2, 8);
            
            Color color = colors[rnd.Next(colors.Length)];
            using var brush = new SolidBrush(Color.FromArgb(200 - frame * 20, color));
            g.FillEllipse(brush, px, py, psize, psize);
        }
    }
    
    public static void DrawStarfield(Graphics g, int width, int height, int frame)
    {
        Random rnd = new Random(42); // Fixed seed for consistent stars
        
        for (int i = 0; i < 100; i++)
        {
            int x = rnd.Next(width);
            int y = (rnd.Next(height) + frame) % height;
            int brightness = rnd.Next(100, 255);
            
            using var brush = new SolidBrush(Color.FromArgb(brightness, brightness, brightness));
            int size = rnd.Next(1, 3);
            g.FillRectangle(brush, x, y, size, size);
        }
    }
    
    public static void DrawAsteroid(Graphics g, int x, int y, int size, float rotation)
    {
        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        
        // Salva stato grafico
        var state = g.Save();
        
        // Ruota attorno al centro
        g.TranslateTransform(x + size/2, y + size/2);
        g.RotateTransform(rotation);
        g.TranslateTransform(-(x + size/2), -(y + size/2));
        
        // Disegna asteroide irregolare (poligono)
        Point[] asteroidShape = {
            new Point(x + size/2, y),
            new Point(x + size, y + size/3),
            new Point(x + size - 2, y + size),
            new Point(x + size/3, y + size - 2),
            new Point(x, y + 2*size/3),
            new Point(x + 2, y + size/4)
        };
        
        using var asteroidBrush = new System.Drawing.Drawing2D.LinearGradientBrush(
            new Rectangle(x, y, size, size),
            Color.FromArgb(140, 140, 120),
            Color.FromArgb(80, 80, 70),
            45f
        );
        g.FillPolygon(asteroidBrush, asteroidShape);
        
        using var outlinePen = new Pen(Color.FromArgb(60, 60, 50), 2);
        g.DrawPolygon(outlinePen, asteroidShape);
        
        // Crateri
        using var craterBrush = new SolidBrush(Color.FromArgb(100, 50, 50, 45));
        g.FillEllipse(craterBrush, x + size/4, y + size/3, size/4, size/4);
        g.FillEllipse(craterBrush, x + size/2, y + size/2, size/5, size/5);
        
        g.Restore(state);
    }
    
    public static void DrawComet(Graphics g, int x, int y, int speedX, int speedY)
    {
        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        
        // Testa della cometa (stella brillante)
        using var cometPath = new System.Drawing.Drawing2D.GraphicsPath();
        cometPath.AddEllipse(x - 8, y - 8, 16, 16);
        using var cometBrush = new System.Drawing.Drawing2D.PathGradientBrush(cometPath);
        cometBrush.CenterColor = Color.FromArgb(255, 255, 255); // Bianco brillante
        cometBrush.SurroundColors = new[] { Color.FromArgb(100, 200, 220, 255) };
        g.FillPath(cometBrush, cometPath);
        
        // Coda della cometa (scia luminosa)
        for (int i = 1; i <= 10; i++)
        {
            int tailX = x - speedX * i * 2;
            int tailY = y - speedY * i * 2;
            int alpha = Math.Max(0, 150 - i * 15);
            int size = Math.Max(2, 12 - i);
            
            using var tailBrush = new SolidBrush(Color.FromArgb(alpha, 150, 200, 255));
            g.FillEllipse(tailBrush, tailX - size/2, tailY - size/2, size, size);
        }
    }
    
    private static void DrawLightBeam(Graphics g, int centerX, int topY, int frame)
    {
        // Raggio luminoso verticale che colpisce Gandalf dall'alto
        g.SmoothingMode = SmoothingMode.AntiAlias;
        
        // Animazione pulsante
        float intensity = (float)Math.Sin(frame * 0.1) * 0.3f + 0.7f;
        
        // Raggio principale (giallo brillante)
        using (var beamBrush = new LinearGradientBrush(
            new Point(centerX, topY),
            new Point(centerX, topY + 220),
            Color.FromArgb((int)(200 * intensity), 255, 255, 200),
            Color.FromArgb((int)(100 * intensity), 255, 255, 150)))
        {
            g.FillRectangle(beamBrush, centerX - 15, topY, 30, 220);
        }
        
        // Alone luminoso esterno
        using (var glowBrush = new LinearGradientBrush(
            new Point(centerX, topY),
            new Point(centerX, topY + 220),
            Color.FromArgb((int)(80 * intensity), 255, 255, 255),
            Color.FromArgb(0, 255, 255, 255)))
        {
            g.FillRectangle(glowBrush, centerX - 30, topY, 60, 220);
        }
        
        // Particelle luminose nel raggio
        Random rand = new Random(frame);
        for (int i = 0; i < 10; i++)
        {
            int particleY = topY + rand.Next(220);
            int particleX = centerX + rand.Next(-20, 20);
            int alpha = rand.Next(100, 200);
            using var particleBrush = new SolidBrush(Color.FromArgb(alpha, 255, 255, 255));
            g.FillEllipse(particleBrush, particleX - 2, particleY - 2, 4, 4);
        }
    }
    
    public static void DrawGandalf(Graphics g, int x, int y, int animationFrame)
    {
        // Raggio luminoso verticale dall'alto
        DrawLightBeam(g, x + 75, y, animationFrame);
        
        // Carica immagine al primo utilizzo
        if (!_gandalfImageLoaded)
        {
            try
            {
                string imagePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "gandalf.png");
                if (File.Exists(imagePath))
                {
                    _gandalfImage = Image.FromFile(imagePath);
                }
            }
            catch
            {
                _gandalfImage = null;
            }
            _gandalfImageLoaded = true;
        }
        
        // Se l'immagine è caricata, disegnala con bordo verde
        if (_gandalfImage != null)
        {
            // Bordo verde luminescente
            using (var greenGlowPen = new Pen(Color.FromArgb(200, 0, 255, 0), 4))
            {
                g.DrawRectangle(greenGlowPen, x - 4, y - 4, 158, 208);
            }
            
            // Glow verde esterno
            using (var greenGlowBrush = new SolidBrush(Color.FromArgb(40, 0, 255, 0)))
            {
                g.FillRectangle(greenGlowBrush, x - 8, y - 8, 166, 216);
            }
            g.DrawImage(_gandalfImage, x, y, 150, 200);
            return;
        }
        
        // Fallback: disegno originale
        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        
        // Cappello a punta
        Point[] hat = {
            new Point(x + 25, y),
            new Point(x + 50, y + 30),
            new Point(x, y + 30)
        };
        using var hatBrush = new SolidBrush(Color.FromArgb(80, 80, 100));
        g.FillPolygon(hatBrush, hat);
        
        // Testa
        using var faceBrush = new SolidBrush(Color.FromArgb(240, 220, 200));
        g.FillEllipse(faceBrush, x + 10, y + 28, 30, 35);
        
        // Barba bianca
        using var beardBrush = new SolidBrush(Color.FromArgb(245, 245, 245));
        Point[] beard = {
            new Point(x + 15, y + 45),
            new Point(x + 25, y + 80),
            new Point(x + 35, y + 45)
        };
        g.FillPolygon(beardBrush, beard);
        
        // Mantello grigio
        using var cloakBrush = new SolidBrush(Color.FromArgb(180, 180, 190));
        g.FillRectangle(cloakBrush, x + 5, y + 60, 40, 60);
        
        // Bastone magico
        using var staffPen = new Pen(Color.FromArgb(139, 90, 43), 4);
        g.DrawLine(staffPen, x + 45, y + 70, x + 55, y + 130);
        
        // Cristallo sul bastone (lampeggiante)
        float glowAlpha = (float)Math.Abs(Math.Sin(animationFrame * 0.2f));
        using var crystalBrush = new SolidBrush(Color.FromArgb((int)(200 * glowAlpha), 100, 200, 255));
        g.FillEllipse(crystalBrush, x + 50, y + 65, 12, 12);
        
        // Glow intorno al cristallo
        using var glowBrush = new SolidBrush(Color.FromArgb((int)(100 * glowAlpha), 150, 220, 255));
        g.FillEllipse(glowBrush, x + 47, y + 62, 18, 18);
    }
    
    public static void DrawHeart(Graphics g, int x, int y, float pulsePhase)
    {
        g.SmoothingMode = SmoothingMode.AntiAlias;
        
        // Pulse effect - più grosso
        float scale = 1.0f + (float)Math.Sin(pulsePhase) * 0.2f;
        int size = (int)(30 * scale); // Aumentato da 20 a 30
        int halfSize = size / 2;
        
        // Create heart shape path
        using var heartPath = new GraphicsPath();
        
        // Left curve
        heartPath.AddArc(x - halfSize, y - halfSize / 2, halfSize, halfSize, 180, 180);
        // Right curve
        heartPath.AddArc(x, y - halfSize / 2, halfSize, halfSize, 180, 180);
        // Bottom point
        PointF[] bottomPoints = {
            new PointF(x - halfSize, y),
            new PointF(x, y + halfSize),
            new PointF(x + halfSize, y)
        };
        heartPath.AddLines(bottomPoints);
        heartPath.CloseFigure();
        
        // Gradient fill - red/pink
        using var heartBrush = new LinearGradientBrush(
            new Rectangle(x - halfSize, y - halfSize, size, size * 2),
            Color.FromArgb(255, 255, 50, 100), // Bright red
            Color.FromArgb(255, 255, 100, 150), // Pink
            45f
        );
        g.FillPath(heartBrush, heartPath);
        
        // Glow effect
        using var glowPath = new GraphicsPath();
        glowPath.AddPath(heartPath, false);
        using var glowBrush = new PathGradientBrush(glowPath);
        glowBrush.CenterColor = Color.FromArgb(100, 255, 255, 255);
        glowBrush.SurroundColors = new[] { Color.FromArgb(0, 255, 50, 100) };
        g.FillPath(glowBrush, glowPath);
        
        // Highlight
        using var highlightBrush = new SolidBrush(Color.FromArgb(150, 255, 255, 255));
        g.FillEllipse(highlightBrush, x - halfSize / 2, y - halfSize / 3, size / 3, size / 4);
    }
    
    public static void DrawDoubleShotPowerup(Graphics g, int x, int y, float glowPhase)
    {
        g.SmoothingMode = SmoothingMode.AntiAlias;
        
        // Glow effect
        float glowIntensity = (float)Math.Sin(glowPhase) * 0.3f + 0.7f;
        int size = 25;
        
        // Outer glow
        using var outerGlowBrush = new PathGradientBrush(
            new Point[] {
                new Point(x - size, y - size/2),
                new Point(x + size, y - size/2),
                new Point(x + size, y + size/2),
                new Point(x - size, y + size/2)
            });
        outerGlowBrush.CenterColor = Color.FromArgb((int)(150 * glowIntensity), 255, 200, 0);
        outerGlowBrush.SurroundColors = new[] { Color.FromArgb(0, 255, 200, 0) };
        g.FillRectangle(outerGlowBrush, x - size, y - size/2, size * 2, size);
        
        // Double arrow icon
        Point[] leftArrow = {
            new Point(x - 12, y),
            new Point(x - 6, y - 8),
            new Point(x - 6, y + 8)
        };
        Point[] rightArrow = {
            new Point(x + 12, y),
            new Point(x + 6, y - 8),
            new Point(x + 6, y + 8)
        };
        
        using var arrowBrush = new LinearGradientBrush(
            new Rectangle(x - 15, y - 10, 30, 20),
            Color.FromArgb(255, 255, 220, 0),
            Color.FromArgb(255, 255, 150, 0),
            90f
        );
        g.FillPolygon(arrowBrush, leftArrow);
        g.FillPolygon(arrowBrush, rightArrow);
        
        // Border
        using var borderPen = new Pen(Color.FromArgb(255, 255, 255, 100), 2);
        g.DrawPolygon(borderPen, leftArrow);
        g.DrawPolygon(borderPen, rightArrow);
    }
}

