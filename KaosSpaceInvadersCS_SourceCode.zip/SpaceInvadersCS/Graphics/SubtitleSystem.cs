using System.Drawing;
using System.Drawing.Drawing2D;

namespace SpaceInvaders.GraphicsMode;

public class SubtitleSystem
{
    private string? _currentSubtitle;
    private int _subtitleTimer;
    private const int SubtitleDuration = 180; // 6 seconds at 30 FPS
    private float _subtitleAlpha;
    private const int FadeInFrames = 10;
    private const int FadeOutFrames = 30;
    
    public void ShowSubtitle(string text)
    {
        _currentSubtitle = text;
        _subtitleTimer = SubtitleDuration;
        _subtitleAlpha = 0;
    }
    
    public void Update()
    {
        if (_currentSubtitle == null || _subtitleTimer <= 0) return;
        
        _subtitleTimer--;
        
        // Fade in
        if (_subtitleTimer > SubtitleDuration - FadeInFrames)
        {
            _subtitleAlpha = (SubtitleDuration - _subtitleTimer) / (float)FadeInFrames;
        }
        // Fade out
        else if (_subtitleTimer < FadeOutFrames)
        {
            _subtitleAlpha = _subtitleTimer / (float)FadeOutFrames;
        }
        // Full visibility
        else
        {
            _subtitleAlpha = 1.0f;
        }
        
        if (_subtitleTimer <= 0)
        {
            _currentSubtitle = null;
        }
    }
    
    public void Draw(Graphics g, int width, int height)
    {
        if (_currentSubtitle == null || _subtitleAlpha <= 0) return;
        
        using var font = new Font("Arial", 18, FontStyle.Bold);
        using var shadowFont = new Font("Arial", 18, FontStyle.Bold);
        
        // Calculate text size
        SizeF textSize = g.MeasureString(_currentSubtitle, font);
        
        // Position at top center (below HUD)
        float x = (width - textSize.Width) / 2;
        float y = 50;
        
        // Calculate alpha
        int alpha = (int)(255 * _subtitleAlpha);
        
        // Draw background box with glow
        using var bgBrush = new SolidBrush(Color.FromArgb(alpha * 3 / 4, 0, 0, 0));
        using var glowBrush = new SolidBrush(Color.FromArgb(alpha / 3, 0, 255, 255));
        
        RectangleF bgRect = new RectangleF(x - 20, y - 10, textSize.Width + 40, textSize.Height + 20);
        RectangleF glowRect = new RectangleF(x - 25, y - 15, textSize.Width + 50, textSize.Height + 30);
        
        // Glow effect
        g.FillRectangle(glowBrush, glowRect);
        
        // Background
        g.FillRectangle(bgBrush, bgRect);
        
        // Border
        using var borderPen = new Pen(Color.FromArgb(alpha, Color.Cyan), 2);
        g.DrawRectangle(borderPen, bgRect.X, bgRect.Y, bgRect.Width, bgRect.Height);
        
        // Shadow
        using var shadowBrush = new SolidBrush(Color.FromArgb(alpha, 0, 0, 0));
        g.DrawString(_currentSubtitle, shadowFont, shadowBrush, x + 2, y + 2);
        
        // Main text with gradient
        using var textBrush = new LinearGradientBrush(
            new PointF(x, y),
            new PointF(x, y + textSize.Height),
            Color.FromArgb(alpha, Color.Cyan),
            Color.FromArgb(alpha, Color.White)
        );
        
        g.DrawString(_currentSubtitle, font, textBrush, x, y);
        
        // Icon indicator (speaker)
        DrawSpeakerIcon(g, (int)(x - 40), (int)(y + 5), alpha);
    }
    
    private void DrawSpeakerIcon(Graphics g, int x, int y, int alpha)
    {
        using var iconBrush = new SolidBrush(Color.FromArgb(alpha, Color.Yellow));
        using var waveBrush = new SolidBrush(Color.FromArgb(alpha / 2, Color.Yellow));
        
        // Speaker cone
        Point[] speaker = {
            new Point(x, y + 5),
            new Point(x + 8, y + 5),
            new Point(x + 12, y),
            new Point(x + 12, y + 20),
            new Point(x + 8, y + 15),
            new Point(x, y + 15)
        };
        g.FillPolygon(iconBrush, speaker);
        
        // Sound waves
        using var wavePen = new Pen(waveBrush, 2);
        g.DrawArc(wavePen, x + 14, y + 2, 8, 16, -90, 180);
        g.DrawArc(wavePen, x + 18, y - 2, 12, 24, -90, 180);
    }
    
    public void Clear()
    {
        _currentSubtitle = null;
        _subtitleTimer = 0;
    }
}
