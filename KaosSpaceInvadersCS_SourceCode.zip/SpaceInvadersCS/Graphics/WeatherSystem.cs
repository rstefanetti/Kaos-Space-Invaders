using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

namespace SpaceInvadersCS.Graphics
{
    /// <summary>
    /// Sistema meteorologico dinamico con fulmini, pioggia, sole, vento e arcobaleno
    /// </summary>
    public class WeatherSystem
    {
        private WeatherState _currentState;
        private int _stateTimer;
        private int _lightningTimer;
        private readonly Random _random;
        private readonly List<Raindrop> _raindrops;
        private readonly List<Lightning> _activeLightnings;
        private int _windDirection; // -1 sinistra, 0 nessuno, 1 destra
        private int _windStrength;
        private bool _wasRaining;
        private int _rainbowTimer;
        
        // Costanti
        private const int StateChangeDuration = 600; // 20 secondi a 30 FPS
        private const int LightningInterval = 600; // 20 secondi
        private const int RainbowDuration = 450; // 15 secondi
        private const int MaxLightningTargets = 5;
        private const int RaindropCount = 80;
        
        // Eventi
        public event Action<List<Point>>? OnLightningStrike; // Posizioni colpite
        public event Action<int>? OnWindPush; // Direzione del vento
        public event Action<string>? OnWeatherChange; // Cambio stato meteo
        
        public WeatherState CurrentState => _currentState;
        public int WindDirection => _windDirection;
        public bool IsRaining => _currentState == WeatherState.Rain || _currentState == WeatherState.Thunderstorm;
        public bool ShowRainbow => _rainbowTimer > 0;
        public List<Lightning> ActiveLightnings => _activeLightnings;
        
        public WeatherSystem()
        {
            _random = new Random();
            _currentState = WeatherState.Clear;
            _stateTimer = 0;
            _lightningTimer = 0;
            _raindrops = new List<Raindrop>();
            _activeLightnings = new List<Lightning>();
            _windDirection = 0;
            _windStrength = 0;
            _wasRaining = false;
            _rainbowTimer = 0;
            
            InitializeRaindrops();
        }
        
        private void InitializeRaindrops()
        {
            for (int i = 0; i < RaindropCount; i++)
            {
                _raindrops.Add(new Raindrop
                {
                    X = _random.Next(0, 100),
                    Y = _random.Next(-40, 0),
                    Speed = _random.Next(2, 4),
                    Length = _random.Next(2, 5)
                });
            }
        }
        
        public void Update()
        {
            _stateTimer++;
            
            // Transizione di stato ogni 20 secondi
            if (_stateTimer >= StateChangeDuration)
            {
                TransitionToNextState();
                _stateTimer = 0;
            }
            
            // Aggiorna arcobaleno
            if (_rainbowTimer > 0)
            {
                _rainbowTimer--;
            }
            
            // Logica specifica per stato
            switch (_currentState)
            {
                case WeatherState.Rain:
                    UpdateRain();
                    break;
                    
                case WeatherState.Thunderstorm:
                    UpdateRain();
                    UpdateThunderstorm();
                    break;
                    
                case WeatherState.Wind:
                    UpdateWind();
                    break;
            }
            
            // Aggiorna fulmini attivi
            UpdateLightnings();
        }
        
        private void TransitionToNextState()
        {
            // Se stava piovendo, mostra arcobaleno
            if (_wasRaining && (_currentState == WeatherState.Clear || _currentState == WeatherState.Sunny))
            {
                _rainbowTimer = RainbowDuration;
            }
            
            _wasRaining = IsRaining;
            
            // Scegli nuovo stato casuale
            var availableStates = Enum.GetValues<WeatherState>()
                .Where(s => s != WeatherState.Rainbow) // Rainbow non è uno stato primario
                .ToList();
                
            WeatherState newState;
            do
            {
                newState = availableStates[_random.Next(availableStates.Count)];
            } while (newState == _currentState && availableStates.Count > 1);
            
            _currentState = newState;
            
            // Notifica cambio meteo
            OnWeatherChange?.Invoke(GetWeatherStateName(_currentState));
            
            // Inizializza lo stato
            switch (_currentState)
            {
                case WeatherState.Wind:
                    _windDirection = _random.Next(2) == 0 ? -1 : 1;
                    _windStrength = _random.Next(1, 3);
                    OnWindPush?.Invoke(_windDirection);
                    break;
                    
                case WeatherState.Thunderstorm:
                    _lightningTimer = 0;
                    break;
            }
        }
        
        private void UpdateRain()
        {
            foreach (var drop in _raindrops)
            {
                drop.Y += drop.Speed;
                
                // Reset quando esce dallo schermo
                if (drop.Y > 40)
                {
                    drop.Y = _random.Next(-10, -1);
                    drop.X = _random.Next(0, 100);
                }
            }
        }
        
        private void UpdateThunderstorm()
        {
            _lightningTimer++;
            
            if (_lightningTimer >= LightningInterval)
            {
                TriggerLightning();
                _lightningTimer = 0;
            }
        }
        
        private void TriggerLightning()
        {
            var strikePositions = new List<Point>();
            int strikeCount = _random.Next(1, MaxLightningTargets + 1);
            
            for (int i = 0; i < strikeCount; i++)
            {
                int x = _random.Next(10, 90);
                int y = _random.Next(5, 25);
                strikePositions.Add(new Point(x, y));
                
                // Crea animazione fulmine
                _activeLightnings.Add(new Lightning
                {
                    X = x,
                    StartY = 0,
                    EndY = y,
                    Frame = 0,
                    MaxFrames = 8 // 8 frame di animazione
                });
            }
            
            // Notifica il GameEngine per eliminare alieni
            OnLightningStrike?.Invoke(strikePositions);
        }
        
        private void UpdateWind()
        {
            // Il vento spinge periodicamente
            if (_stateTimer % 60 == 0) // Ogni 2 secondi
            {
                OnWindPush?.Invoke(_windDirection);
            }
        }
        
        private void UpdateLightnings()
        {
            foreach (var lightning in _activeLightnings)
            {
                lightning.Frame++;
            }
            
            // Rimuovi fulmini completati
            _activeLightnings.RemoveAll(l => l.Frame >= l.MaxFrames);
        }
        
        public void Draw(System.Drawing.Graphics g, int screenWidth, int screenHeight)
        {
            // Disegna effetti meteo
            switch (_currentState)
            {
                case WeatherState.Clear:
                    // Nessun effetto
                    break;
                    
                case WeatherState.Sunny:
                    DrawSun(g, screenWidth, screenHeight);
                    break;
                    
                case WeatherState.Rain:
                case WeatherState.Thunderstorm:
                    DrawRain(g);
                    break;
                    
                case WeatherState.Wind:
                    DrawWindLines(g, screenWidth, screenHeight);
                    break;
            }
            
            // Disegna fulmini
            foreach (var lightning in _activeLightnings)
            {
                DrawLightning(g, lightning);
            }
            
            // Disegna arcobaleno se attivo
            if (ShowRainbow)
            {
                DrawRainbow(g, screenWidth, screenHeight);
            }
        }
        
        private void DrawSun(System.Drawing.Graphics g, int screenWidth, int screenHeight)
        {
            int sunX = screenWidth - 100;
            int sunY = 80;
            int sunRadius = 30;
            
            // Alone giallo
            using (var haloBrush = new SolidBrush(Color.FromArgb(30, 255, 255, 0)))
            {
                g.FillEllipse(haloBrush, sunX - sunRadius - 10, sunY - sunRadius - 10, 
                             (sunRadius + 10) * 2, (sunRadius + 10) * 2);
            }
            
            // Sole
            using (var sunBrush = new SolidBrush(Color.FromArgb(200, 255, 255, 0)))
            {
                g.FillEllipse(sunBrush, sunX - sunRadius, sunY - sunRadius, sunRadius * 2, sunRadius * 2);
            }
            
            // Raggi
            using (var rayPen = new Pen(Color.FromArgb(150, 255, 255, 0), 2))
            {
                for (int i = 0; i < 12; i++)
                {
                    double angle = (i * 30) * Math.PI / 180;
                    int rayLength = 45;
                    int x1 = sunX + (int)((sunRadius + 5) * Math.Cos(angle));
                    int y1 = sunY + (int)((sunRadius + 5) * Math.Sin(angle));
                    int x2 = sunX + (int)((sunRadius + rayLength) * Math.Cos(angle));
                    int y2 = sunY + (int)((sunRadius + rayLength) * Math.Sin(angle));
                    g.DrawLine(rayPen, x1, y1, x2, y2);
                }
            }
        }
        
        private void DrawRain(System.Drawing.Graphics g)
        {
            using (var rainPen = new Pen(Color.FromArgb(150, 100, 150, 200), 1))
            {
                foreach (var drop in _raindrops)
                {
                    int screenX = drop.X * 8;
                    int screenY = drop.Y * 15;
                    g.DrawLine(rainPen, screenX, screenY, screenX + 2, screenY + drop.Length * 3);
                }
            }
        }
        
        private void DrawWindLines(System.Drawing.Graphics g, int screenWidth, int screenHeight)
        {
            using (var windPen = new Pen(Color.FromArgb(80, 200, 200, 200), 2))
            {
                for (int i = 0; i < 10; i++)
                {
                    int y = 100 + i * 40;
                    int offset = (_stateTimer * _windStrength) % 100;
                    if (_windDirection < 0) offset = -offset;
                    
                    g.DrawLine(windPen, offset, y, offset + 60, y);
                    g.DrawLine(windPen, offset + 100, y, offset + 160, y);
                }
            }
        }
        
        private void DrawLightning(System.Drawing.Graphics g, Lightning lightning)
        {
            // Intensità decresce con i frame
            int alpha = 255 - (lightning.Frame * 30);
            if (alpha < 0) alpha = 0;
            
            using (var lightningPen = new Pen(Color.FromArgb(alpha, 255, 255, 255), 3))
            using (var glowPen = new Pen(Color.FromArgb(alpha / 2, 150, 200, 255), 6))
            {
                int x = lightning.X * 8;
                int startY = lightning.StartY * 15;
                int endY = lightning.EndY * 15;
                
                // Bagliore
                g.DrawLine(glowPen, x, startY, x, endY);
                
                // Fulmine zigzag
                int segments = 5;
                int currentY = startY;
                int currentX = x;
                
                for (int i = 0; i < segments; i++)
                {
                    int nextY = startY + ((endY - startY) * (i + 1)) / segments;
                    int nextX = x + _random.Next(-15, 15);
                    
                    g.DrawLine(lightningPen, currentX, currentY, nextX, nextY);
                    currentX = nextX;
                    currentY = nextY;
                }
            }
        }
        
        private void DrawRainbow(System.Drawing.Graphics g, int screenWidth, int screenHeight)
        {
            // Arcobaleno con 7 colori (ROYGBIV)
            Color[] colors = new[]
            {
                Color.FromArgb(150, 255, 0, 0),    // Rosso
                Color.FromArgb(150, 255, 127, 0),  // Arancione
                Color.FromArgb(150, 255, 255, 0),  // Giallo
                Color.FromArgb(150, 0, 255, 0),    // Verde
                Color.FromArgb(150, 0, 0, 255),    // Blu
                Color.FromArgb(150, 75, 0, 130),   // Indaco
                Color.FromArgb(150, 148, 0, 211)   // Violetto
            };
            
            int centerX = screenWidth / 2;
            int centerY = screenHeight - 50;
            int baseRadius = 200;
            
            // Disegna archi dall'esterno verso l'interno
            for (int i = colors.Length - 1; i >= 0; i--)
            {
                int radius = baseRadius + (i * 15);
                using (var pen = new Pen(colors[i], 12))
                {
                    g.DrawArc(pen, centerX - radius, centerY - radius / 2, 
                             radius * 2, radius * 2, 180, 180);
                }
            }
        }
        
        public List<Raindrop> GetRaindrops() => _raindrops;
        
        private string GetWeatherStateName(WeatherState state)
        {
            return state switch
            {
                WeatherState.Clear => "SERENO",
                WeatherState.Sunny => "SOLE",
                WeatherState.Rain => "PIOGGIA",
                WeatherState.Thunderstorm => "TEMPORALE",
                WeatherState.Wind => "VENTO",
                _ => "SCONOSCIUTO"
            };
        }
    }
    
    public enum WeatherState
    {
        Clear,
        Sunny,
        Rain,
        Thunderstorm,
        Wind,
        Rainbow
    }
    
    public class Raindrop
    {
        public int X { get; set; }
        public int Y { get; set; }
        public int Speed { get; set; }
        public int Length { get; set; }
    }
    
    public class Lightning
    {
        public int X { get; set; }
        public int StartY { get; set; }
        public int EndY { get; set; }
        public int Frame { get; set; }
        public int MaxFrames { get; set; }
    }
}
