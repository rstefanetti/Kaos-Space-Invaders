using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;

namespace SpaceInvaders.GraphicsMode;

// AI Bot companion that shows encouraging comic-style speech bubbles
public class AIBotCompanion
{
    public string Name { get; } = "BOB"; // Nome del robot AI companion - BOB
    private bool _hasGreeted = false;
    private string? _currentMessage;
    private int _messageTimer;
    private const int MessageDuration = 90; // 3 seconds at 30 FPS
    private float _messageAlpha;
    private readonly Random _random;
    private float _bobOffset;
    private const float BobSpeed = 0.1f;
    private Image? _bobImage;
    
    // Evento per quando BOB vuole mandare un messaggio alla MessageBar
    public event Action<string, Color>? OnBobMessage;
    
    // Comic-style exclamations in Italian
    private readonly string[] _shootMessages = { "BANG!", "POW!", "ZAP!", "BOOM!" };
    private readonly string[] _hitMessages = { "OHHH!", "AHI!", "UFFA!", "ATTENTO!" };
    private readonly string[] _victoryMessages = { "DAJE!", "GRANDE!", "BRAVO!", "YEAH!" };
    private readonly string[] _comboMessages = { "WOW!", "FIRE!", "SUPER!", "COMBO!" };
    private readonly string[] _encouragementMessages = { "FORZA!", "VAI!", "SÌ!", "DAJE!" };
    
    public AIBotCompanion()
    {
        _random = new Random();
        _messageTimer = 0;
        _messageAlpha = 0;
        _bobOffset = 0;
        
        // Carica immagine BOB
        try
        {
            string imagePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "bob.png");
            if (File.Exists(imagePath))
            {
                _bobImage = Image.FromFile(imagePath);
            }
        }
        catch
        {
            _bobImage = null;
        }
    }
    
    public void Update()
    {
        // Update bob animation
        _bobOffset += BobSpeed;
        if (_bobOffset > Math.PI * 2) _bobOffset -= (float)(Math.PI * 2);
        
        if (_currentMessage == null || _messageTimer <= 0) return;
        
        _messageTimer--;
        
        // Fade in
        if (_messageTimer > MessageDuration - 10)
        {
            _messageAlpha = (MessageDuration - _messageTimer) / 10f;
        }
        // Fade out
        else if (_messageTimer < 10)
        {
            _messageAlpha = _messageTimer / 10f;
        }
        // Full visibility
        else
        {
            _messageAlpha = 1.0f;
        }
        
        if (_messageTimer <= 0)
        {
            _currentMessage = null;
        }
    }
    
    public void ShowMessage(string message)
    {
        _currentMessage = message;
        _messageTimer = MessageDuration;
        _messageAlpha = 0;
        
        // Manda il messaggio alla MessageBar (in giallo per BOB)
        OnBobMessage?.Invoke(message, Color.Yellow);
    }
    
    public void OnShoot()
    {
        // Disabilitato - no messaggi
    }
    
    public void OnHit()
    {
        // Disabilitato - no messaggi
    }
    
    public void OnVictory()
    {
        // Disabilitato - no messaggi
    }
    
    public void OnNewRecord()
    {
        // Disabilitato - no messaggi
    }
    
    public void GreetPlayer()
    {
        // Disabilitato - no messaggi
        _hasGreeted = true;
    }
    
    public void OnGandalfRescue()
    {
        // Disabilitato - no messaggi (ora lo dice Obi-Wan)
    }
    
    public void OnCombo()
    {
        // Disabilitato - no messaggi
    }
    
    public void Draw(Graphics g, int screenWidth, int screenHeight)
    {
        // Position in bottom right corner
        int botX = screenWidth - 100;
        int botY = screenHeight - 120;
        
        // Bob animation
        float bob = (float)Math.Sin(_bobOffset) * 5f;
        botY += (int)bob;
        
        // Draw AI robot character
        DrawRobot(g, botX, botY);
        
        // Draw speech bubble if message is active - centrato sullo schermo
        if (_currentMessage != null && _messageAlpha > 0)
        {
            // Calcola posizione centrata
            using var font = new Font("Arial", 14, FontStyle.Bold);
            SizeF textSize = g.MeasureString(_currentMessage, font);
            int messageX = (screenWidth - (int)textSize.Width - 30) / 2; // Centrato orizzontalmente
            int messageY = screenHeight / 2; // Centrato verticalmente
            
            DrawSpeechBubble(g, messageX, messageY, _currentMessage, _messageAlpha, font);
        }
    }
    
    private void DrawRobot(Graphics g, int x, int y)
    {
        // Se l'immagine è caricata, disegnala con bordo verde
        if (_bobImage != null)
        {
            // Bordo verde luminescente
            using (var greenGlowPen = new Pen(Color.FromArgb(180, 0, 255, 0), 3))
            {
                g.DrawRectangle(greenGlowPen, x - 3, y - 3, 66, 86);
            }
            
            // Glow verde esterno
            using (var greenGlowBrush = new SolidBrush(Color.FromArgb(30, 0, 255, 0)))
            {
                g.FillRectangle(greenGlowBrush, x - 6, y - 6, 72, 92);
            }
            
            g.DrawImage(_bobImage, x, y, 60, 80);
            
            // Bandiera italiana vicino a BOB (a destra)
            DrawItalianFlag(g, x + 70, y + 20);
            return;
        }
        
        // Fallback: disegno originale
        g.SmoothingMode = SmoothingMode.AntiAlias;
        
        // Robot body (cyan metallic)
        using var bodyBrush = new LinearGradientBrush(
            new Rectangle(x, y, 60, 80),
            Color.FromArgb(100, 200, 255),
            Color.FromArgb(50, 150, 200),
            90f
        );
        g.FillRectangle(bodyBrush, x + 15, y + 20, 30, 40);
        
        // Robot head
        using var headBrush = new LinearGradientBrush(
            new Rectangle(x, y, 60, 30),
            Color.FromArgb(150, 220, 255),
            Color.FromArgb(80, 180, 220),
            90f
        );
        g.FillEllipse(headBrush, x + 10, y, 40, 30);
        
        // Eyes (glowing)
        using var eyeBrush = new SolidBrush(Color.FromArgb(255, 255, 0));
        g.FillEllipse(eyeBrush, x + 18, y + 8, 8, 8);
        g.FillEllipse(eyeBrush, x + 34, y + 8, 8, 8);
        
        // Eye glow
        using var glowBrush = new SolidBrush(Color.FromArgb(100, 255, 255, 0));
        g.FillEllipse(glowBrush, x + 15, y + 5, 14, 14);
        g.FillEllipse(glowBrush, x + 31, y + 5, 14, 14);
        
        // Antenna
        using var antennaPen = new Pen(Color.FromArgb(100, 200, 255), 2);
        g.DrawLine(antennaPen, x + 30, y, x + 30, y - 10);
        g.FillEllipse(eyeBrush, x + 27, y - 13, 6, 6);
        
        // Arms
        g.DrawLine(antennaPen, x + 15, y + 30, x + 5, y + 40);
        g.DrawLine(antennaPen, x + 45, y + 30, x + 55, y + 40);
        
        // Legs
        g.FillRectangle(bodyBrush, x + 20, y + 60, 8, 20);
        g.FillRectangle(bodyBrush, x + 32, y + 60, 8, 20);
        
        // Outline
        using var outlinePen = new Pen(Color.FromArgb(200, 255, 255, 255), 2);
        g.DrawRectangle(outlinePen, x + 15, y + 20, 30, 40);
        g.DrawEllipse(outlinePen, x + 10, y, 40, 30);
    }
    
    private void DrawSpeechBubble(Graphics g, int x, int y, string message, float alpha, Font font)
    {
        int bubbleAlpha = (int)(255 * alpha);
        
        SizeF textSize = g.MeasureString(message, font);
        
        int width = (int)textSize.Width + 30; // Padding
        int height = (int)textSize.Height + 20; // Padding
        
        // Comic-style jagged bubble
        var bubblePath = new GraphicsPath();
        
        // Main bubble rectangle with rounded corners
        var bubbleRect = new Rectangle(x, y, width, height);
        int arc = 15;
        bubblePath.AddArc(bubbleRect.X, bubbleRect.Y, arc, arc, 180, 90);
        bubblePath.AddArc(bubbleRect.Right - arc, bubbleRect.Y, arc, arc, 270, 90);
        bubblePath.AddArc(bubbleRect.Right - arc, bubbleRect.Bottom - arc, arc, arc, 0, 90);
        bubblePath.AddArc(bubbleRect.X, bubbleRect.Bottom - arc, arc, arc, 90, 90);
        bubblePath.CloseFigure();
        
        // Fill bubble (white with slight transparency)
        using var fillBrush = new SolidBrush(Color.FromArgb(bubbleAlpha, 255, 255, 255));
        g.FillPath(fillBrush, bubblePath);
        
        // Thick black outline
        using var outlinePen = new Pen(Color.FromArgb(bubbleAlpha, 0, 0, 0), 3);
        g.DrawPath(outlinePen, bubblePath);
        
        // Draw text (black, bold)
        using var textBrush = new SolidBrush(Color.FromArgb(bubbleAlpha, 0, 0, 0));
        g.DrawString(message, font, textBrush, x + 15, y + 10);
        
        bubblePath.Dispose();
    }
    
    private void DrawItalianFlag(Graphics g, int x, int y)
    {
        // Bandiera italiana piccola (20x30 pixel)
        int flagWidth = 20;
        int flagHeight = 30;
        int stripeWidth = flagWidth / 3;
        
        g.SmoothingMode = SmoothingMode.AntiAlias;
        
        // Asta della bandiera (grigia)
        using (var poleBrush = new SolidBrush(Color.Gray))
        {
            g.FillRectangle(poleBrush, x - 2, y - 5, 2, flagHeight + 10);
        }
        
        // Verde (sinistra)
        using (var greenBrush = new SolidBrush(Color.FromArgb(0, 146, 70)))
        {
            g.FillRectangle(greenBrush, x, y, stripeWidth, flagHeight);
        }
        
        // Bianco (centro)
        using (var whiteBrush = new SolidBrush(Color.White))
        {
            g.FillRectangle(whiteBrush, x + stripeWidth, y, stripeWidth, flagHeight);
        }
        
        // Rosso (destra)
        using (var redBrush = new SolidBrush(Color.FromArgb(206, 43, 55)))
        {
            g.FillRectangle(redBrush, x + stripeWidth * 2, y, stripeWidth, flagHeight);
        }
        
        // Bordo nero attorno alla bandiera
        using (var borderPen = new Pen(Color.Black, 1))
        {
            g.DrawRectangle(borderPen, x, y, flagWidth, flagHeight);
        }
        
        // Effetto sventolante (piccola onda)
        using (var wavePen = new Pen(Color.FromArgb(100, 255, 255, 255), 1))
        {
            g.DrawLine(wavePen, x + stripeWidth, y + 5, x + stripeWidth, y + flagHeight - 5);
            g.DrawLine(wavePen, x + stripeWidth * 2, y + 5, x + stripeWidth * 2, y + flagHeight - 5);
        }
    }
}
