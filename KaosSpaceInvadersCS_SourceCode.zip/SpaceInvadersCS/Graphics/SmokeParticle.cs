namespace SpaceInvaders;

using System.Drawing;

/// <summary>
/// Particella di fumo che sale dal cratere
/// </summary>
public class SmokeParticle
{
    public float X { get; set; }
    public float Y { get; set; }
    public float VelocityX { get; set; }
    public float VelocityY { get; set; }
    public float Size { get; set; }
    public int Life { get; set; }
    public int MaxLife { get; private set; }
    public bool IsActive => Life > 0;
    
    public SmokeParticle(float x, float y, float velocityX, float velocityY, float size, int life)
    {
        X = x;
        Y = y;
        VelocityX = velocityX;
        VelocityY = velocityY;
        Size = size;
        Life = life;
        MaxLife = life;
    }
    
    public void Update()
    {
        X += VelocityX;
        Y += VelocityY;
        
        // Il fumo rallenta mentre sale
        VelocityY *= 0.98f;
        VelocityX *= 0.95f;
        
        // Il fumo si espande
        Size += 0.05f;
        
        Life--;
    }
    
    /// <summary>
    /// Opacità della particella che diminuisce nel tempo
    /// </summary>
    public float GetOpacity()
    {
        return (float)Life / MaxLife;
    }
}
