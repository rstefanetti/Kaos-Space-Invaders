using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;

namespace SpaceInvaders.GraphicsMode;

public class CortanaHelper
{
    private Image? _cortanaImage;
    private int _usesRemaining;
    private string? _currentMessage;
    private int _messageTimer;
    private float _messageAlpha;
    private const int MaxUses = 3;
    private const int MessageDuration = 90; // 3 secondi a 30 FPS (ridotto da 180)
    private int _snakeSpawnTimer;
    private readonly Random _random;
    
    public bool IsAvailable => _usesRemaining > 0;
    public int UsesRemaining => _usesRemaining;
    public bool IsMessageActive => _messageTimer > 0;
    
    // Evento per spawn snake casuali (quando Cortana è attiva)
    public event Action<int>? OnRandomSnakeSpawn; // Passa la posizione X casuale
    
    public CortanaHelper()
    {
        _usesRemaining = MaxUses;
        _random = new Random();
        _snakeSpawnTimer = 0;
        LoadCortanaImage();
    }
    
    private void LoadCortanaImage()
    {
        try
        {
            string imagePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "cortana.png");
            if (File.Exists(imagePath))
            {
                _cortanaImage = Image.FromFile(imagePath);
            }
        }
        catch
        {
            _cortanaImage = null;
        }
    }
    
    public bool TryActivate()
    {
        if (_usesRemaining > 0)
        {
            _usesRemaining--;
            _currentMessage = "Cortana corre in tuo aiuto Spartan BOB!";
            _messageTimer = MessageDuration;
            _messageAlpha = 1.0f;
            return true;
        }
        else
        {
            _currentMessage = "Cortana non più disponibile Spartans!";
            _messageTimer = MessageDuration;
            _messageAlpha = 1.0f;
            return false;
        }
    }
    
    public void Update()
    {
        if (_messageTimer > 0)
        {
            _messageTimer--;
            
            // Fade out nell'ultimo secondo
            if (_messageTimer < 30)
            {
                _messageAlpha = _messageTimer / 30f;
            }
            
            if (_messageTimer == 0)
            {
                _currentMessage = null;
                _messageAlpha = 0;
            }
        }
        
        // Se Cortana è ancora disponibile, ogni tanto spawna snake casuali (ogni 10 secondi circa)
        if (_usesRemaining > 0)
        {
            _snakeSpawnTimer++;
            if (_snakeSpawnTimer > 300) // 10 secondi a 30 FPS
            {
                // 30% di probabilità di spawnare uno snake casuale
                if (_random.Next(100) < 30)
                {
                    int randomX = _random.Next(10, 90); // Posizione X casuale
                    OnRandomSnakeSpawn?.Invoke(randomX);
                }
                _snakeSpawnTimer = 0;
            }
        }
    }
    
    public void Draw(Graphics g, int screenWidth, int screenHeight)
    {
        // Disegna Cortana in alto a destra (ridotto)
        int cortanaX = screenWidth - 130;
        int cortanaY = 50;
        
        g.SmoothingMode = SmoothingMode.AntiAlias;
        
        // Disegna immagine Cortana se disponibile
        if (_cortanaImage != null && _usesRemaining >= 0)
        {
            // Bordo verde luminescente attorno a Cortana
            using (var greenGlowPen = new Pen(Color.FromArgb(180, 0, 255, 0), 4))
            {
                g.DrawEllipse(greenGlowPen, cortanaX - 5, cortanaY - 5, 110, 110);
            }
            
            // Glow verde esterno
            using (var glowBrush = new SolidBrush(Color.FromArgb(30, 0, 255, 0)))
            {
                g.FillEllipse(glowBrush, cortanaX - 10, cortanaY - 10, 120, 120);
            }
            
            g.DrawImage(_cortanaImage, cortanaX, cortanaY, 100, 100);
        }
        else if (_usesRemaining >= 0)
        {
            // Fallback: disegna rappresentazione stilizzata di Cortana
            DrawCortanaFallback(g, cortanaX + 50, cortanaY + 50);
        }
        
        // Mostra contatore utilizzi rimanenti
        if (_usesRemaining > 0)
        {
            using (var font = new Font("Arial", 10, FontStyle.Bold))
            using (var brush = new SolidBrush(Color.Cyan))
            {
                string usesText = $"Cortana: {_usesRemaining}x";
                g.DrawString(usesText, font, brush, cortanaX + 10, cortanaY + 105);
            }
        }
        
        // Disegna messaggio se attivo (centro schermo)
        if (_currentMessage != null && _messageAlpha > 0)
        {
            DrawMessage(g, screenWidth / 2, screenHeight / 2, _currentMessage, _messageAlpha);
        }
    }
    
    private void DrawCortanaFallback(Graphics g, int centerX, int centerY)
    {
        // Forma umanoide stilizzata blu/cyan (rappresentazione AI)
        using (var cortanaBrush = new LinearGradientBrush(
            new Rectangle(centerX - 40, centerY - 60, 80, 120),
            Color.FromArgb(100, 150, 255),
            Color.FromArgb(0, 100, 200),
            LinearGradientMode.Vertical))
        {
            // Testa
            g.FillEllipse(cortanaBrush, centerX - 20, centerY - 60, 40, 40);
            
            // Corpo
            Point[] bodyPoints = new Point[]
            {
                new Point(centerX - 15, centerY - 20),
                new Point(centerX + 15, centerY - 20),
                new Point(centerX + 10, centerY + 40),
                new Point(centerX - 10, centerY + 40)
            };
            g.FillPolygon(cortanaBrush, bodyPoints);
            
            // Linee luminose (dettagli AI)
            using (var glowPen = new Pen(Color.Cyan, 2))
            {
                g.DrawLine(glowPen, centerX - 10, centerY - 50, centerX + 10, centerY - 50);
                g.DrawLine(glowPen, centerX - 10, centerY, centerX + 10, centerY);
                g.DrawLine(glowPen, centerX - 8, centerY + 20, centerX + 8, centerY + 20);
            }
        }
    }
    
    private void DrawMessage(Graphics g, int x, int y, string message, float alpha)
    {
        int msgAlpha = (int)(255 * alpha);
        
        // Font più piccolo (14 invece di 20)
        using var font = new Font("Arial", 14, FontStyle.Bold);
        
        // Background semi-trasparente
        using (var bgBrush = new SolidBrush(Color.FromArgb(msgAlpha * 3 / 4, 0, 0, 0)))
        {
            SizeF textSize = g.MeasureString(message, font);
            int padding = 15;
            Rectangle bgRect = new Rectangle(
                x - (int)textSize.Width / 2 - padding,
                y - (int)textSize.Height / 2 - padding,
                (int)textSize.Width + padding * 2,
                (int)textSize.Height + padding * 2
            );
            g.FillRectangle(bgBrush, bgRect);
            
            // Bordo cyan luminoso
            using (var borderPen = new Pen(Color.FromArgb(msgAlpha, Color.Cyan), 2))
            {
                g.DrawRectangle(borderPen, bgRect);
            }
        }
        
        // Testo con glow ridotto
        // Glow effect
        using (var glowBrush = new SolidBrush(Color.FromArgb(msgAlpha / 2, 0, 200, 255)))
        {
            for (int i = -1; i <= 1; i++)
            {
                for (int j = -1; j <= 1; j++)
                {
                    if (i != 0 || j != 0)
                    {
                        g.DrawString(message, font, glowBrush, 
                            x - g.MeasureString(message, font).Width / 2 + i, 
                            y - g.MeasureString(message, font).Height / 2 + j);
                    }
                }
            }
        }
        
        // Testo principale
        using (var textBrush = new SolidBrush(Color.FromArgb(msgAlpha, Color.White)))
        {
            g.DrawString(message, font, textBrush, 
                x - g.MeasureString(message, font).Width / 2, 
                y - g.MeasureString(message, font).Height / 2);
        }
    }
}
