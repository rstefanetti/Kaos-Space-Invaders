using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;

namespace SpaceInvaders.GraphicsMode;

// Pseudo-3D effects using 2D transformations
public class Effects3D
{
    private float _rotation;
    private const float RotationSpeed = 0.05f;
    
    public void Update()
    {
        _rotation += RotationSpeed;
        if (_rotation > 360) _rotation -= 360;
    }
    
    // Apply perspective scaling based on depth (y-position)
    public static float GetPerspectiveScale(float y, float screenHeight)
    {
        // Objects further away (lower y) are smaller
        float depth = y / screenHeight;
        return 0.7f + (depth * 0.3f); // Scale from 0.7 to 1.0
    }
    
    // Apply rotation matrix to a point
    public static PointF RotatePoint(PointF point, PointF center, float angleDegrees)
    {
        float angleRadians = angleDegrees * (float)Math.PI / 180f;
        float cos = (float)Math.Cos(angleRadians);
        float sin = (float)Math.Sin(angleRadians);
        
        float dx = point.X - center.X;
        float dy = point.Y - center.Y;
        
        return new PointF(
            center.X + dx * cos - dy * sin,
            center.Y + dx * sin + dy * cos
        );
    }
    
    // Draw sprite with rotation
    public static void DrawRotatedSprite(Graphics g, Action<Graphics> drawAction, 
        float x, float y, float width, float height, float angleDegrees)
    {
        var state = g.Save();
        
        // Translate to center, rotate, translate back
        g.TranslateTransform(x + width / 2, y + height / 2);
        g.RotateTransform(angleDegrees);
        g.TranslateTransform(-(x + width / 2), -(y + height / 2));
        
        drawAction(g);
        
        g.Restore(state);
    }
    
    // Apply wobble effect (for aliens)
    public float GetWobbleOffset()
    {
        return (float)Math.Sin(_rotation) * 3f;
    }
    
    // Get rotation angle for spinning effect
    public float GetRotationAngle()
    {
        return _rotation;
    }
    
    // Draw parallax starfield with multiple layers
    public static void DrawParallaxStarfield(Graphics g, int width, int height, int frame)
    {
        Random rnd = new Random(12345); // Fixed seed for consistent stars
        
        // Layer 1 - Far stars (slow, small)
        using var farBrush = new SolidBrush(Color.FromArgb(100, Color.White));
        for (int i = 0; i < 50; i++)
        {
            int x = rnd.Next(width);
            int y = (rnd.Next(height) + frame / 4) % height;
            g.FillRectangle(farBrush, x, y, 1, 1);
        }
        
        // Layer 2 - Mid stars (medium speed)
        using var midBrush = new SolidBrush(Color.FromArgb(150, Color.White));
        for (int i = 0; i < 30; i++)
        {
            int x = rnd.Next(width);
            int y = (rnd.Next(height) + frame / 2) % height;
            g.FillRectangle(midBrush, x, y, 2, 2);
        }
        
        // Layer 3 - Near stars (fast, bright)
        using var nearBrush = new SolidBrush(Color.FromArgb(255, Color.White));
        for (int i = 0; i < 20; i++)
        {
            int x = rnd.Next(width);
            int y = (rnd.Next(height) + frame) % height;
            g.FillRectangle(nearBrush, x, y, 2, 2);
            
            // Add twinkle effect
            if ((frame + i * 10) % 60 < 30)
            {
                using var glowBrush = new SolidBrush(Color.FromArgb(50, Color.Cyan));
                g.FillEllipse(glowBrush, x - 2, y - 2, 6, 6);
            }
        }
    }
    
    // Draw CRT scanlines effect
    public static void DrawScanlines(Graphics g, int width, int height)
    {
        using var scanlineBrush = new SolidBrush(Color.FromArgb(20, Color.Black));
        for (int y = 0; y < height; y += 2)
        {
            g.FillRectangle(scanlineBrush, 0, y, width, 1);
        }
    }
    
    // Draw screen vignette (darkened corners)
    public static void DrawVignette(Graphics g, int width, int height)
    {
        using var path = new GraphicsPath();
        path.AddRectangle(new Rectangle(0, 0, width, height));
        
        using var brush = new PathGradientBrush(path);
        brush.CenterPoint = new PointF(width / 2, height / 2);
        brush.CenterColor = Color.Transparent;
        brush.SurroundColors = new[] { Color.FromArgb(100, Color.Black) };
        
        g.FillPath(brush, path);
    }
    
    // Draw glow effect around text or sprites
    public static void DrawGlow(Graphics g, Rectangle bounds, Color glowColor, int intensity = 10)
    {
        for (int i = intensity; i > 0; i--)
        {
            int alpha = (255 * i) / (intensity * 4);
            using var glowBrush = new SolidBrush(Color.FromArgb(alpha, glowColor));
            var glowRect = new Rectangle(
                bounds.X - i,
                bounds.Y - i,
                bounds.Width + i * 2,
                bounds.Height + i * 2
            );
            g.FillRectangle(glowBrush, glowRect);
        }
    }
    
    // Apply chromatic aberration effect (RGB channel offset)
    public static void ApplyChromaticAberration(Graphics g, Bitmap source, int offsetX, int offsetY)
    {
        // This would require pixel manipulation
        // Simplified version: draw with slight color offsets
        var redMatrix = new ColorMatrix();
        redMatrix.Matrix00 = 1; redMatrix.Matrix11 = 0; redMatrix.Matrix22 = 0;
        var redAttr = new ImageAttributes();
        redAttr.SetColorMatrix(redMatrix);
        
        var destRect = new Rectangle(offsetX, offsetY, source.Width, source.Height);
        g.DrawImage(source, destRect, 0, 0, source.Width, source.Height, GraphicsUnit.Pixel, redAttr);
        
        redAttr.Dispose();
    }
}
