using System.Drawing;
using System.Drawing.Drawing2D;
using SpaceInvaders.Entities;

namespace SpaceInvaders.GraphicsMode;

public class GraphicsRenderer : IRenderer
{
    private readonly GamePanel _gamePanel;
    private int _starfieldFrame;
    private readonly Effects3D _effects3D;
    private readonly EarthBackground _earthBackground;
    private readonly SaturnPlanet _saturnPlanet;
    
    public GraphicsRenderer(GamePanel gamePanel)
    {
        _gamePanel = gamePanel;
        _starfieldFrame = 0;
        _effects3D = new Effects3D();
        _earthBackground = new EarthBackground();
        _saturnPlanet = new SaturnPlanet();
    }
    
    // IRenderer interface implementation
    public void Render(GameEngine engine)
    {
        Render(engine, null);
    }
    
    // Extended render method with particle system support
    public void Render(GameEngine engine, ParticleSystem? particleSystem, AIBotCompanion? aiBotCompanion = null, CortanaHelper? cortanaHelper = null, CortanaChatUI? cortanaChatUI = null, LeaderboardDisplay? leaderboardDisplay = null, MessageBar? messageBar = null)
    {
        _starfieldFrame++;
        _effects3D.Update();
        _earthBackground.Update();
        _saturnPlanet.Update();
        _gamePanel.SetGameState(engine, _starfieldFrame, particleSystem, _effects3D, aiBotCompanion, _earthBackground, _saturnPlanet, cortanaHelper, cortanaChatUI, leaderboardDisplay, messageBar);
        _gamePanel.Invalidate();
    }
    
    public void ShowWelcomeScreen()
    {
        // Welcome screen is shown in the form itself
    }
}

public class GamePanel : Panel
{
    private GameEngine? _engine;
    private int _starfieldFrame;
    private ParticleSystem? _particleSystem;
    private Effects3D? _effects3D;
    private AIBotCompanion? _aiBotCompanion;
    private CortanaHelper? _cortanaHelper;
    private CortanaChatUI? _cortanaChatUI;
    private LeaderboardDisplay? _leaderboardDisplay;
    private MessageBar? _messageBar;
    private EarthBackground? _earthBackground;
    private SaturnPlanet? _saturnPlanet;
    private const int SpriteSize = 30;
    
    public GamePanel()
    {
        // Enable advanced double buffering to eliminate flickering
        DoubleBuffered = true;
        SetStyle(ControlStyles.UserPaint | 
                 ControlStyles.AllPaintingInWmPaint | 
                 ControlStyles.OptimizedDoubleBuffer, true);
        UpdateStyles();
        BackColor = Color.Black;
    }
    
    public void SetGameState(GameEngine engine, int starfieldFrame, ParticleSystem? particleSystem = null, Effects3D? effects3D = null, AIBotCompanion? aiBotCompanion = null, EarthBackground? earthBackground = null, SaturnPlanet? saturnPlanet = null, CortanaHelper? cortanaHelper = null, CortanaChatUI? cortanaChatUI = null, LeaderboardDisplay? leaderboardDisplay = null, MessageBar? messageBar = null)
    {
        _engine = engine;
        _starfieldFrame = starfieldFrame;
        _particleSystem = particleSystem;
        _effects3D = effects3D;
        _aiBotCompanion = aiBotCompanion;
        _earthBackground = earthBackground;
        _saturnPlanet = saturnPlanet;
        _cortanaHelper = cortanaHelper;
        _cortanaChatUI = cortanaChatUI;
        _leaderboardDisplay = leaderboardDisplay;
        _messageBar = messageBar;
    }
    
    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        
        if (_engine == null) return;
        
        Graphics g = e.Graphics;
        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        
        // Draw Earth background from space
        _earthBackground?.Draw(g, Width, Height);
        
        // Draw Saturn planet (in alto a sinistra)
        _saturnPlanet?.Draw(g, Width, Height);
        
        // Draw craters on the ground (after background, before entities)
        DrawCraters(g);
        
        // Draw smoke particles (after craters, before entities)
        DrawSmoke(g);
        
        // Draw all entities with 3D effects
        int frame = _engine.GetAnimationFrame();
        float wobbleOffset = _effects3D?.GetWobbleOffset() ?? 0;
        
        foreach (var entity in _engine.GetAllEntities())
        {
            int screenX = entity.X * (Width / 100);
            int screenY = entity.Y * (Height / 36);
            
            // Apply perspective scaling based on depth
            float scale = 1.0f;
            if (_effects3D != null && entity.Type != EntityType.Player)
            {
                scale = Effects3D.GetPerspectiveScale(screenY, Height);
            }
            
            int scaledSize = (int)(SpriteSize * scale);
            
            switch (entity.Type)
            {
                case EntityType.Player:
                    SpriteLibrary.DrawPlayer(g, screenX - SpriteSize/2, screenY - SpriteSize/2, SpriteSize);
                    
                    // Scudo protettivo se attivo
                    if (_engine.Player.HasProtectiveShield)
                    {
                        SpriteLibrary.DrawProtectiveShield(g, screenX, screenY, SpriteSize, frame);
                    }
                    break;
                
                case EntityType.UFO:
                    // UFO - disco volante con contorno fluorescente (senza rotazione per evitare rettangolo)
                    SpriteLibrary.DrawUFO(g, screenX - SpriteSize, screenY - SpriteSize/2, SpriteSize/2);
                    break;
                
                case EntityType.TriangularUFO:
                    // UFO Triangolare - renderizzato con metodo custom (ha già le sue coordinate pixel)
                    // Non serve disegnare qui, viene disegnato dopo con il suo metodo Draw()
                    break;
                    
                case EntityType.AlienType1:
                case EntityType.AlienType2:
                case EntityType.AlienType3:
                    // Aliens with wobble and scale
                    int alienType = entity.Type == EntityType.AlienType1 ? 1 : 
                                   entity.Type == EntityType.AlienType2 ? 2 : 3;
                    
                    int wobbleX = (int)(screenX + wobbleOffset);
                    SpriteLibrary.DrawAlien(g, wobbleX - scaledSize/2, screenY - scaledSize/2, alienType, frame, scaledSize);
                    break;
                    
                case EntityType.PlayerBullet:
                    SpriteLibrary.DrawBullet(g, screenX, screenY, true, 15);
                    
                    // Trail glow
                    if (_effects3D != null)
                    {
                        Effects3D.DrawGlow(g, 
                            new Rectangle(screenX - 3, screenY - 8, 6, 16),
                            Color.Cyan, 3);
                    }
                    break;
                    
                case EntityType.AlienBullet:
                    SpriteLibrary.DrawBullet(g, screenX, screenY, false, 15);
                    
                    // Trail glow
                    if (_effects3D != null)
                    {
                        Effects3D.DrawGlow(g, 
                            new Rectangle(screenX - 3, screenY - 8, 6, 16),
                            Color.Red, 3);
                    }
                    break;
                    
                case EntityType.Shield:
                    SpriteLibrary.DrawShield(g, screenX - SpriteSize/2, screenY - SpriteSize/2, entity.Health, SpriteSize);
                    break;
                    
                case EntityType.Asteroid:
                    var asteroid = entity as Asteroid;
                    if (asteroid != null)
                    {
                        int asteroidSize = asteroid.Size * 8;
                        SpriteLibrary.DrawAsteroid(g, screenX - asteroidSize/2, screenY - asteroidSize/2, 
                            asteroidSize, asteroid.Rotation);
                    }
                    break;
                    
                case EntityType.Comet:
                    var comet = entity as Comet;
                    if (comet != null)
                    {
                        // Calcola direzione dalla velocità
                        int speedX = 2; // Approssimazione
                        int speedY = 1;
                        SpriteLibrary.DrawComet(g, screenX, screenY, speedX, speedY);
                    }
                    break;
                    
                case EntityType.Heart:
                    var heart = entity as Heart;
                    if (heart != null)
                    {
                        SpriteLibrary.DrawHeart(g, screenX, screenY, heart.PulsePhase);
                    }
                    break;
                    
                case EntityType.Powerup:
                    // Prova prima a castare come DoubleShotPowerup (vecchio)
                    var doubleShotPowerup = entity as DoubleShotPowerup;
                    if (doubleShotPowerup != null)
                    {
                        SpriteLibrary.DrawDoubleShotPowerup(g, screenX, screenY, doubleShotPowerup.GlowPhase);
                    }
                    else
                    {
                        // Altrimenti è un nuovo PowerUp con Draw() method
                        var newPowerup = entity as PowerUp;
                        if (newPowerup != null)
                        {
                            newPowerup.Draw(g);
                        }
                    }
                    break;
                    
                case EntityType.Snake:
                    var snake = entity as Snake;
                    if (snake != null)
                    {
                        snake.Draw(g);
                    }
                    break;
            }
        }
        
        // Draw Gandalf if active
        if (_engine.GandalfActive)
        {
            SpriteLibrary.DrawGandalf(g, 50, Height - 150, _starfieldFrame);
        }
        
        // Draw Pac-Man Chase if active
        if (_engine.CurrentPacManChase != null && _engine.CurrentPacManChase.IsActive)
        {
            _engine.CurrentPacManChase.Draw(g, 0, 40); // 40 è l'offset per la barra superiore
        }
        
        // Draw particle effects
        _particleSystem?.Draw(g);
        
        // Draw weather effects (before UI elements)
        _engine?.Weather?.Draw(g, Width, Height);
        
        // Draw seagulls (gabbiani che svolazzano)
        if (_engine != null)
        {
            foreach (var seagull in _engine.Seagulls)
            {
                seagull.Draw(g);
            }
            
            // Draw Super Aliens (super alieni fusione)
            foreach (var superAlien in _engine.SuperAliens)
            {
                if (superAlien.IsActive)
                {
                    superAlien.Draw(g, Width, Height);
                }
            }
            
            // Draw Triangular UFO (UFO triangolare - 1000 punti)
            if (_engine.TriangularUfo.IsActive)
            {
                _engine.TriangularUfo.Draw(g, Width, Height);
            }
            
            // Draw Nuclear Missiles (missili nucleari)
            foreach (var missile in _engine.NuclearMissiles)
            {
                if (missile.IsActive)
                {
                    missile.Draw(g, Width, Height);
                }
            }
            
            // Draw Radioactive Mushrooms (funghi atomici)
            foreach (var mushroom in _engine.RadioactiveMushrooms)
            {
                if (mushroom.IsActive)
                {
                    mushroom.Draw(g, Width, Height);
                }
            }
        }
        
        // Draw AI Bot Companion - NON disegnamo i messaggi centrali, solo BOB
        // I messaggi andranno nella MessageBar in basso
        
        // Draw Cortana Helper
        _cortanaHelper?.Draw(g, Width, Height);
        
        // Draw Cortana Chat UI (sopra tutto, tranne messaggi e sottotitoli)
        _cortanaChatUI?.Draw(g, Width, Height);
        
        // Draw message bar in basso (messaggi tipo flipper)
        _messageBar?.Draw(g, Width, Height);
        
        // Draw Boss Fight se attivo O completato (mostra messaggio finale)
        if (_engine.CurrentBossFight != null && (_engine.CurrentBossFight.IsActive || _engine.CurrentBossFight.IsCompleted))
        {
            _engine.CurrentBossFight.Draw(g, Width, Height);
        }
        
        // Draw Leaderboard Display (sopra tutto quando visibile)
        _leaderboardDisplay?.Draw(g, Width, Height);
        
        // Draw HUD
        DrawHUD(g);
    }
    
    private void DrawHUD(Graphics g)
    {
        if (_engine == null) return;
        
        using var font = new Font("Consolas", 16, FontStyle.Bold);
        using var brush = new SolidBrush(Color.White);
        using var shadowBrush = new SolidBrush(Color.Black);
        
        // Score (sinistra)
        string scoreText = $"PUNTEGGIO: {_engine.Player.Score:D6}";
        g.DrawString(scoreText, font, shadowBrush, 11, 11);
        g.DrawString(scoreText, font, brush, 10, 10);
        
        // Livello (sinistra, sotto il punteggio)
        string levelText = $"LIVELLO: {_engine.CurrentLevel}/10";
        g.DrawString(levelText, font, shadowBrush, 11, 36);
        g.DrawString(levelText, font, brush, 10, 35);
        
        // Lives (centro)
        string livesText = $"VITE: ";
        g.DrawString(livesText, font, shadowBrush, Width/2 - 80, 11);
        g.DrawString(livesText, font, brush, Width/2 - 81, 10);
        
        for (int i = 0; i < _engine.Player.Lives; i++)
        {
            SpriteLibrary.DrawPlayer(g, Width/2 + i * 35, 12, 20);
        }
        
        // Barra energia (sotto le vite)
        DrawEnergyBar(g);
        
        // High Score (destra, vicino alla progress bar)
        if (_engine.HighScore > 0)
        {
            string recordText = $"RECORD: {_engine.HighScore:D6}";
            SizeF recordSize = g.MeasureString(recordText, font);
            float recordX = Width - recordSize.Width - 15;
            g.DrawString(recordText, font, shadowBrush, recordX + 1, 11);
            using var goldBrush = new SolidBrush(Color.Gold);
            g.DrawString(recordText, font, goldBrush, recordX, 10);
        }
        
        // Progress bar (colonna destra) - % mancante per finire il livello
        DrawLevelProgress(g);
        
        // Game Over / Victory messages
        if (_engine.IsGameOver || _engine.IsVictory)
        {
            using var bigFont = new Font("Arial", 48, FontStyle.Bold);
            using var medFont = new Font("Arial", 24, FontStyle.Bold);
            using var overlayBrush = new SolidBrush(Color.FromArgb(150, Color.Black));
            
            g.FillRectangle(overlayBrush, 0, 0, Width, Height);
            
            string mainText = _engine.IsVictory ? "VITTORIA!" : "GAME OVER";
            Color mainColor = _engine.IsVictory ? Color.Gold : Color.Red;
            
            SizeF mainSize = g.MeasureString(mainText, bigFont);
            float mainX = (Width - mainSize.Width) / 2;
            float mainY = Height / 2 - 100;
            
            using var mainBrush = new SolidBrush(mainColor);
            using var outlinePen = new Pen(Color.White, 3);
            
            // Draw outline
            var path = new System.Drawing.Drawing2D.GraphicsPath();
            path.AddString(mainText, bigFont.FontFamily, (int)bigFont.Style, bigFont.Size, 
                          new PointF(mainX, mainY), StringFormat.GenericDefault);
            g.DrawPath(outlinePen, path);
            g.FillPath(mainBrush, path);
            
            // Instructions
            string instruction = "Premi ESC per Uscire";
            SizeF instrSize = g.MeasureString(instruction, medFont);
            g.DrawString(instruction, medFont, brush, (Width - instrSize.Width) / 2, mainY + 120);
            
            // Final score
            string finalScore = $"Punteggio Finale: {_engine.Player.Score}";
            SizeF scoreSize = g.MeasureString(finalScore, medFont);
            using var scoreBrush = new SolidBrush(Color.Yellow);
            g.DrawString(finalScore, medFont, scoreBrush, (Width - scoreSize.Width) / 2, mainY + 70);
        }
        
        // Draw AI bot companion
        _aiBotCompanion?.Draw(g, Width, Height);
        
        // Apply arcade effects
        if (_effects3D != null)
        {
            Effects3D.DrawScanlines(g, Width, Height);
            Effects3D.DrawVignette(g, Width, Height);
        }
    }
    
    private void DrawLevelProgress(Graphics g)
    {
        if (_engine == null) return;
        
        // Calculate progress
        var aliens = _engine.GetAllEntities().Where(e => 
            e.Type == EntityType.AlienType1 || 
            e.Type == EntityType.AlienType2 || 
            e.Type == EntityType.AlienType3).ToList();
        
        int totalAliens = 55; // 11 columns x 5 rows
        int remainingAliens = aliens.Count(a => a.IsActive);
        int destroyedAliens = totalAliens - remainingAliens;
        float completionPercent = (float)destroyedAliens / totalAliens * 100f;
        float remainingPercent = 100f - completionPercent;
        
        // Position in bottom right corner (reduced size)
        int barX = Width - 90;
        int barY = Height - 180;
        int barWidth = 70;
        int barHeight = 150;
        
        // Background panel
        using var panelBrush = new SolidBrush(Color.FromArgb(120, 0, 0, 0));
        g.FillRectangle(panelBrush, barX - 10, barY - 25, barWidth + 20, barHeight + 50);
        
        // Title
        using var titleFont = new Font("Consolas", 9, FontStyle.Bold);
        using var titleBrush = new SolidBrush(Color.White);
        string title = "PROGRESSO";
        SizeF titleSize = g.MeasureString(title, titleFont);
        g.DrawString(title, titleFont, titleBrush, barX + (barWidth - titleSize.Width) / 2, barY - 18);
        
        // Progress bar border
        using var borderPen = new Pen(Color.FromArgb(200, 100, 200, 255), 2);
        g.DrawRectangle(borderPen, barX, barY, barWidth, barHeight);
        
        // Progress fill (from bottom to top)
        int fillHeight = (int)(barHeight * completionPercent / 100f);
        if (fillHeight > 0)
        {
            using var fillBrush = new LinearGradientBrush(
                new Rectangle(barX, barY + barHeight - fillHeight, barWidth, fillHeight),
                Color.FromArgb(200, 50, 255, 100), // Green
                Color.FromArgb(200, 100, 200, 255), // Blue
                LinearGradientMode.Vertical
            );
            g.FillRectangle(fillBrush, barX + 2, barY + barHeight - fillHeight + 2, barWidth - 4, fillHeight - 2);
        }
        
        // Percentage text (remaining %)
        using var percentFont = new Font("Consolas", 16, FontStyle.Bold);
        using var percentBrush = new SolidBrush(Color.White);
        using var shadowBrush = new SolidBrush(Color.Black);
        string percentText = $"{remainingPercent:F0}%";
        SizeF percentSize = g.MeasureString(percentText, percentFont);
        
        // Draw shadow
        g.DrawString(percentText, percentFont, shadowBrush, 
            barX + (barWidth - percentSize.Width) / 2 + 1, barY + barHeight + 8);
        // Draw main text
        g.DrawString(percentText, percentFont, percentBrush, 
            barX + (barWidth - percentSize.Width) / 2, barY + barHeight + 7);
    }
    
    private void DrawCraters(Graphics g)
    {
        if (_engine == null) return;
        
        foreach (var crater in _engine.Craters)
        {
            if (!crater.IsActive) continue;
            
            int screenX = crater.X * (Width / 100);
            int screenY = crater.Y * (Height / 36);
            int craterSize = crater.Size * 6; // Dimensione proporzionale all'asteroide
            
            float opacity = crater.GetOpacity();
            int alpha = (int)(opacity * 180); // Max 180 per semi-trasparenza
            
            // Disegna cratere circolare con gradiente dal centro
            using var path = new System.Drawing.Drawing2D.GraphicsPath();
            path.AddEllipse(screenX - craterSize / 2, screenY - craterSize / 2, craterSize, craterSize);
            
            using var pathBrush = new System.Drawing.Drawing2D.PathGradientBrush(path);
            pathBrush.CenterPoint = new PointF(screenX, screenY);
            pathBrush.CenterColor = Color.FromArgb(alpha, 40, 30, 20); // Marrone scuro al centro
            pathBrush.SurroundColors = new[] { Color.FromArgb(alpha / 3, 80, 60, 40) }; // Marrone chiaro ai bordi
            
            g.FillPath(pathBrush, path);
            
            // Bordo del cratere (più scuro)
            using var borderPen = new Pen(Color.FromArgb(alpha / 2, 30, 20, 10), 2);
            g.DrawEllipse(borderPen, screenX - craterSize / 2, screenY - craterSize / 2, craterSize, craterSize);
            
            // Piccole rocce sparse intorno al cratere (detriti)
            if (opacity > 0.5f) // Solo quando il cratere è ancora abbastanza fresco
            {
                Random craterRandom = new Random(crater.X + crater.Y); // Seed fisso per consistenza
                for (int i = 0; i < 5; i++)
                {
                    float angle = i * (360f / 5f) + craterRandom.Next(30);
                    float distance = craterSize / 2 + craterRandom.Next(5, 15);
                    int debrisX = screenX + (int)(Math.Cos(angle * Math.PI / 180) * distance);
                    int debrisY = screenY + (int)(Math.Sin(angle * Math.PI / 180) * distance);
                    int debrisSize = 2 + craterRandom.Next(3);
                    
                    using var debrisBrush = new SolidBrush(Color.FromArgb(alpha / 2, 60, 50, 40));
                    g.FillEllipse(debrisBrush, debrisX - debrisSize / 2, debrisY - debrisSize / 2, debrisSize, debrisSize);
                }
            }
        }
    }
    
    /// <summary>
    /// Disegna le particelle di fumo che escono dai crateri
    /// </summary>
    private void DrawSmoke(Graphics g)
    {
        foreach (var smoke in _engine.SmokeParticles)
        {
            if (smoke.IsActive)
            {
                // Calcola opacità in base alla vita rimanente
                float opacity = smoke.GetOpacity();
                int alpha = (int)(opacity * 150); // Max alpha 150 per fumo trasparente
                
                // Colore del fumo (grigio scuro)
                Color smokeColor = Color.FromArgb(alpha, 80, 80, 80);
                
                // Converti coordinate di gioco a pixel
                float pixelX = smoke.X * 8;
                float pixelY = smoke.Y * 15;
                float pixelSize = smoke.Size * 2;
                
                // Disegna il fumo come cerchio sfumato
                using var brush = new SolidBrush(smokeColor);
                g.FillEllipse(brush, pixelX - pixelSize / 2, pixelY - pixelSize / 2, pixelSize, pixelSize);
            }
        }
    }
    
    /// <summary>
    /// Disegna la barra energia dell'astronave
    /// </summary>
    private void DrawEnergyBar(Graphics g)
    {
        // Posizione sotto le vite (centro schermo)
        float barX = Width / 2 - 60;
        float barY = 40;
        float barWidth = 120;
        float barHeight = 12;
        
        // Bordo esterno
        using var borderPen = new Pen(Color.FromArgb(200, 100, 100, 150), 2);
        g.DrawRectangle(borderPen, barX, barY, barWidth, barHeight);
        
        // Sfondo barra (nero trasparente)
        using var bgBrush = new SolidBrush(Color.FromArgb(100, 0, 0, 0));
        g.FillRectangle(bgBrush, barX + 1, barY + 1, barWidth - 2, barHeight - 2);
        
        // Energia rimanente
        float energyPercent = (float)_engine.Player.Energy / Player.MaxEnergy;
        float energyWidth = (barWidth - 4) * energyPercent;
        
        // Colore in base all'energia
        Color energyColor;
        if (energyPercent > 0.6f)
            energyColor = Color.FromArgb(200, 0, 255, 0); // Verde
        else if (energyPercent > 0.3f)
            energyColor = Color.FromArgb(200, 255, 255, 0); // Giallo
        else
            energyColor = Color.FromArgb(200, 255, 0, 0); // Rosso
        
        using var energyBrush = new SolidBrush(energyColor);
        g.FillRectangle(energyBrush, barX + 2, barY + 2, energyWidth, barHeight - 4);
        
        // Testo energia
        using var smallFont = new Font("Arial", 8, FontStyle.Bold);
        string energyText = $"ENERGIA: {_engine.Player.Energy}/{Player.MaxEnergy}";
        SizeF textSize = g.MeasureString(energyText, smallFont);
        using var textBrush = new SolidBrush(Color.White);
        using var textShadow = new SolidBrush(Color.Black);
        g.DrawString(energyText, smallFont, textShadow, barX + (barWidth - textSize.Width) / 2 + 1, barY - 15 + 1);
        g.DrawString(energyText, smallFont, textBrush, barX + (barWidth - textSize.Width) / 2, barY - 15);
    }
}
