namespace SpaceInvaders;

public class ConsoleRenderer : IRenderer
{
    private const int ScreenWidth = 100;
    private const int ScreenHeight = 36;
    private char[,] _buffer;
    private char[,] _previousBuffer;
    
    public ConsoleRenderer()
    {
        _buffer = new char[ScreenHeight, ScreenWidth];
        _previousBuffer = new char[ScreenHeight, ScreenWidth];
        ClearBuffer();
    }
    
    private void ClearBuffer()
    {
        for (int y = 0; y < ScreenHeight; y++)
        {
            for (int x = 0; x < ScreenWidth; x++)
            {
                _buffer[y, x] = ' ';
            }
        }
    }
    
    public void Render(GameEngine engine)
    {
        ClearBuffer();
        DrawBorders();
        DrawEntities(engine);
        DrawHUD(engine);
        FlushToConsole();
    }
    
    private void DrawBorders()
    {
        // Top border
        _buffer[0, 0] = '╔';
        _buffer[0, ScreenWidth - 1] = '╗';
        for (int x = 1; x < ScreenWidth - 1; x++)
        {
            _buffer[0, x] = '═';
        }
        
        // Bottom border
        _buffer[ScreenHeight - 1, 0] = '╚';
        _buffer[ScreenHeight - 1, ScreenWidth - 1] = '╝';
        for (int x = 1; x < ScreenWidth - 1; x++)
        {
            _buffer[ScreenHeight - 1, x] = '═';
        }
        
        // Side borders
        for (int y = 1; y < ScreenHeight - 1; y++)
        {
            _buffer[y, 0] = '║';
            _buffer[y, ScreenWidth - 1] = '║';
        }
    }
    
    private void DrawEntities(GameEngine engine)
    {
        int frame = engine.GetAnimationFrame();
        
        foreach (var entity in engine.GetAllEntities())
        {
            int x = entity.X;
            int y = entity.Y;
            
            // Check bounds
            if (x >= 0 && x < ScreenWidth && y >= 0 && y < ScreenHeight)
            {
                _buffer[y, x] = entity.GetSprite(frame);
            }
        }
    }
    
    private void DrawHUD(GameEngine engine)
    {
        var player = engine.Player;
        
        // Score and lives at top
        string scoreText = $" SCORE: {player.Score:D6}";
        string livesText = $"LIVES: {new string('♥', player.Lives)}";
        string highScoreText = $"HIGH: {engine.HighScore:D6} ";
        
        DrawText(1, 2, scoreText);
        DrawText(1, 40, livesText);
        DrawText(1, ScreenWidth - highScoreText.Length - 2, highScoreText);
        
        // Game status messages
        if (engine.IsGameOver)
        {
            string gameOverText =  "╔════════════════════════╗";
            string gameOverText2 = "║    GAME OVER!          ║";
            string gameOverText3 = "║  Press R to Restart    ║";
            string gameOverText4 = "║  Press ESC to Exit     ║";
            string gameOverText5 = "╚════════════════════════╝";
            
            int startY = ScreenHeight / 2 - 2;
            int startX = (ScreenWidth - gameOverText.Length) / 2;
            
            DrawText(startY, startX, gameOverText);
            DrawText(startY + 1, startX, gameOverText2);
            DrawText(startY + 2, startX, gameOverText3);
            DrawText(startY + 3, startX, gameOverText4);
            DrawText(startY + 4, startX, gameOverText5);
        }
        else if (engine.IsVictory)
        {
            string victoryText =  "╔════════════════════════╗";
            string victoryText2 = "║    VICTORY!            ║";
            string victoryText3 = "║  All Aliens Destroyed  ║";
            string victoryText4 = "║  Press R to Restart    ║";
            string victoryText5 = "╚════════════════════════╝";
            
            int startY = ScreenHeight / 2 - 2;
            int startX = (ScreenWidth - victoryText.Length) / 2;
            
            DrawText(startY, startX, victoryText);
            DrawText(startY + 1, startX, victoryText2);
            DrawText(startY + 2, startX, victoryText3);
            DrawText(startY + 3, startX, victoryText4);
            DrawText(startY + 4, startX, victoryText5);
        }
    }
    
    private void DrawText(int y, int x, string text)
    {
        for (int i = 0; i < text.Length && x + i < ScreenWidth; i++)
        {
            if (y >= 0 && y < ScreenHeight && x + i >= 0)
            {
                _buffer[y, x + i] = text[i];
            }
        }
    }
    
    private void FlushToConsole()
    {
        try
        {
            Console.SetCursorPosition(0, 0);
        }
        catch
        {
            // If we can't set cursor position, just clear and redraw
            Console.Clear();
        }
        
        // Only update changed lines (optimization)
        for (int y = 0; y < ScreenHeight; y++)
        {
            // Check if we can write to this line
            if (y >= Console.WindowHeight) break;
            
            bool lineChanged = false;
            for (int x = 0; x < ScreenWidth; x++)
            {
                if (_buffer[y, x] != _previousBuffer[y, x])
                {
                    lineChanged = true;
                    break;
                }
            }
            
            if (lineChanged)
            {
                try
                {
                    Console.SetCursorPosition(0, y);
                    for (int x = 0; x < ScreenWidth && x < Console.WindowWidth; x++)
                    {
                        Console.Write(_buffer[y, x]);
                        _previousBuffer[y, x] = _buffer[y, x];
                    }
                }
                catch
                {
                    // Skip this line if we can't write to it
                    continue;
                }
            }
        }
    }
    
    public void ShowWelcomeScreen()
    {
        Console.Clear();
        Console.SetCursorPosition(0, 0);
        
        string[] welcome = {         
        };
        
        foreach (var line in welcome)
        {
            Console.WriteLine(line);
        }
        
        Console.ReadKey(true);
        Console.Clear();
    }
}
