using System.Text.Json;
using System.Xml.Linq;

namespace SpaceInvaders;

public class HighScoreEntry
{
    public string PlayerName { get; set; } = "Anonymous";
    public int Score { get; set; }
    public DateTime Date { get; set; }
    public int Level { get; set; }
    
    public HighScoreEntry() { }
    
    public HighScoreEntry(string name, int score, int level)
    {
        PlayerName = name;
        Score = score;
        Level = level;
        Date = DateTime.Now;
    }
}

public class LeaderboardManager
{
    private const int MaxEntries = 10;
    private readonly string _jsonFilePath;
    private readonly string _xmlFilePath;
    private List<HighScoreEntry> _entries;
    
    public LeaderboardManager()
    {
        string appDataFolder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "SpaceInvaders"
        );
        
        Directory.CreateDirectory(appDataFolder);
        
        _jsonFilePath = Path.Combine(appDataFolder, "highscores.json");
        _xmlFilePath = Path.Combine(appDataFolder, "highscores.xml");
        
        _entries = new List<HighScoreEntry>();
        Load();
    }
    
    public void Load()
    {
        try
        {
            // Prova prima XML, poi JSON come fallback
            if (File.Exists(_xmlFilePath))
            {
                LoadFromXml();
            }
            else if (File.Exists(_jsonFilePath))
            {
                string json = File.ReadAllText(_jsonFilePath);
                _entries = JsonSerializer.Deserialize<List<HighScoreEntry>>(json) 
                          ?? new List<HighScoreEntry>();
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error loading high scores: {ex.Message}");
            _entries = new List<HighScoreEntry>();
        }
    }
    
    public void Save()
    {
        try
        {
            // Salva sia in JSON che XML
            SaveToJson();
            SaveToXml();
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error saving high scores: {ex.Message}");
        }
    }
    
    private void SaveToJson()
    {
        var options = new JsonSerializerOptions { WriteIndented = true };
        string json = JsonSerializer.Serialize(_entries, options);
        File.WriteAllText(_jsonFilePath, json);
    }
    
    private void SaveToXml()
    {
        var root = new XElement("Leaderboard");

        foreach (var entry in _entries)
        {
            var entryElement = new XElement("Entry",
                new XElement("PlayerName", entry.PlayerName),
                new XElement("Score", entry.Score),
                new XElement("Level", entry.Level),
                new XElement("Date", entry.Date.ToString("yyyy-MM-dd HH:mm:ss"))
            );
            root.Add(entryElement);
        }

        var doc = new XDocument(
            new XDeclaration("1.0", "utf-8", "yes"),
            root
        );

        doc.Save(_xmlFilePath);
    }
    
    private void LoadFromXml()
    {
        var doc = XDocument.Load(_xmlFilePath);
        _entries = new List<HighScoreEntry>();

        foreach (var entryElement in doc.Root?.Elements("Entry") ?? Enumerable.Empty<XElement>())
        {
            var entry = new HighScoreEntry
            {
                PlayerName = entryElement.Element("PlayerName")?.Value ?? "Unknown",
                Score = int.Parse(entryElement.Element("Score")?.Value ?? "0"),
                Level = int.Parse(entryElement.Element("Level")?.Value ?? "1"),
                Date = DateTime.Parse(entryElement.Element("Date")?.Value ?? DateTime.Now.ToString())
            };
            _entries.Add(entry);
        }

        // Ordina per sicurezza
        _entries = _entries.OrderByDescending(s => s.Score).Take(MaxEntries).ToList();
    }
    
    public bool IsHighScore(int score)
    {
        return _entries.Count < MaxEntries || score > _entries.Last().Score;
    }
    
    public int AddScore(string playerName, int score, int level)
    {
        var newEntry = new HighScoreEntry(playerName, score, level);
        _entries.Add(newEntry);
        _entries = _entries.OrderByDescending(e => e.Score).Take(MaxEntries).ToList();
        Save();
        
        // Return the rank (1-based position)
        return _entries.IndexOf(newEntry) + 1;
    }
    
    public List<HighScoreEntry> GetTopScores(int count = 10)
    {
        return _entries.Take(count).ToList();
    }
    
    public int GetRank(int score)
    {
        return _entries.Count(e => e.Score > score) + 1;
    }
    
    public void Clear()
    {
        _entries.Clear();
        Save();
    }
    
    public int GetHighScore()
    {
        return _entries.Count > 0 ? _entries.Max(e => e.Score) : 0;
    }
    
    public string GetXmlFilePath()
    {
        return _xmlFilePath;
    }
    
    public string GetJsonFilePath()
    {
        return _jsonFilePath;
    }
}
