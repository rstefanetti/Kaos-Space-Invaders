namespace SpaceInvaders;

public class AlienFormation
{
    private readonly List<Alien> _aliens;
    private int _direction; // -1 = left, 1 = right
    private int _stepsSinceDirectionChange;
    private int _stepsBeforeMove;
    private const int AlienColumns = 11;
    private const int AlienRows = 5;
    
    public int AliveCount => _aliens.Count(a => a.IsActive);
    
    public AlienFormation()
    {
        _aliens = new List<Alien>();
        _direction = 1;
        _stepsSinceDirectionChange = 0;
        _stepsBeforeMove = 15; // Rallentato da 10 a 15 (più lento)
        CreateAliens();
    }
    
    public void IncreaseSpeed(float multiplier)
    {
        // Riduci steps = aumenta velocità
        _stepsBeforeMove = Math.Max(5, (int)(15 / multiplier)); // Minimo 5 invece di 3
    }
    
    private void CreateAliens()
    {
        for (int row = 0; row < AlienRows; row++)
        {
            EntityType type = row switch
            {
                0 => EntityType.AlienType1,
                1 or 2 => EntityType.AlienType2,
                _ => EntityType.AlienType3
            };
            
            for (int col = 0; col < AlienColumns; col++)
            {
                int x = 10 + (col * 6);
                int y = 3 + (row * 2);
                _aliens.Add(new Alien(x, y, type));
            }
        }
    }
    
    public void Update()
    {
        _stepsSinceDirectionChange++;
        
        if (_stepsSinceDirectionChange >= _stepsBeforeMove)
        {
            _stepsSinceDirectionChange = 0;
            MoveAliens();
        }
    }
    
    private void MoveAliens()
    {
        // Check if any alien hit the edge
        bool hitEdge = _aliens.Where(a => a.IsActive).Any(a =>
            (_direction == 1 && a.X >= 90) || (_direction == -1 && a.X <= 5));
        
        if (hitEdge)
        {
            // Move down and reverse direction
            foreach (var alien in _aliens.Where(a => a.IsActive))
            {
                alien.Y += 1;
            }
            _direction *= -1;
        }
        else
        {
            // Move horizontally
            foreach (var alien in _aliens.Where(a => a.IsActive))
            {
                alien.X += _direction;
            }
        }
        
        // Toggle animation frame
        foreach (var alien in _aliens)
        {
            alien.AnimationFrame = (alien.AnimationFrame + 1) % 2;
        }
    }
    
    public IEnumerable<Alien> GetAliens() => _aliens;
    
    public IEnumerable<Alien> GetActiveAliens() => _aliens.Where(a => a.IsActive);
    
    public bool HasReachedBottom(int maxY)
    {
        return _aliens.Where(a => a.IsActive).Any(a => a.Y >= maxY - 5);
    }
    
    public Alien? GetRandomShooter()
    {
        var activeAliens = _aliens.Where(a => a.IsActive).ToList();
        if (activeAliens.Count == 0) return null;
        
        // Get bottom-most alien in each column
        var shooters = activeAliens
            .GroupBy(a => a.X)
            .Select(g => g.OrderByDescending(a => a.Y).First())
            .Where(a => a.ShouldShoot())
            .ToList();
        
        if (shooters.Count == 0) return null;
        
        var random = new Random();
        return shooters[random.Next(shooters.Count)];
    }
}
