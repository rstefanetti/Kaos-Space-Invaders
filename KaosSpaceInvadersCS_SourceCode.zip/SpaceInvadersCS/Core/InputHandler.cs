namespace SpaceInvaders;

public class InputHandler
{
    private readonly Dictionary<ConsoleKey, Action> _keyBindings;
    
    public InputHandler()
    {
        _keyBindings = new Dictionary<ConsoleKey, Action>();
    }
    
    public void RegisterKeyBinding(ConsoleKey key, Action action)
    {
        _keyBindings[key] = action;
    }
    
    public bool ProcessInput()
    {
        if (!Console.KeyAvailable) return true;
        
        var keyInfo = Console.ReadKey(true);
        
        if (_keyBindings.TryGetValue(keyInfo.Key, out var action))
        {
            action?.Invoke();
        }
        
        return keyInfo.Key != ConsoleKey.Escape;
    }
}
