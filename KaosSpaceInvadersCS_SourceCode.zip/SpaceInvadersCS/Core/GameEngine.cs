namespace SpaceInvaders;

using SpaceInvaders.Entities;

public class GameEngine
{
    private readonly Player _player;
    private AlienFormation _alienFormation;
    private readonly List<Bullet> _bullets;
    private readonly List<Shield> _shields;
    private readonly UFO _ufo;
    private readonly TriangularUFO _triangularUFO; // UFO triangolare (1000 punti)
    private readonly List<Asteroid> _asteroids;
    private readonly List<Comet> _comets;
    private readonly List<Heart> _hearts;
    private readonly List<DoubleShotPowerup> _doubleShotPowerups;
    private readonly List<PowerUp> _powerUps; // Nuovi potenziamenti casuali
    private readonly List<Crater> _craters;
    private readonly List<SmokeParticle> _smokeParticles;
    private Snake? _snake1;
    private readonly List<Snake> _randomSnakes; // Snake extra spawnati da Cortana
    private PacManChase? _pacmanChase;
    private BossFight? _bossFight; // Boss fight alla fine del livello
    private readonly List<Seagull> _seagulls; // Gabbiani che svolazzano
    private readonly List<SuperAlien> _superAliens; // Super alieni fusione di 2 nemici
    private readonly List<NuclearMissile> _nuclearMissiles; // Missili nucleari
    private readonly List<RadioactiveMushroom> _radioactiveMushrooms; // Funghi atomici
    private readonly Random _random;
    private readonly SpaceInvadersCS.Graphics.WeatherSystem _weatherSystem;
    private int _frameCount;
    private int _ufoSpawnTimer;
    private int _triangularUFOSpawnTimer; // Timer per UFO triangolare
    private int _asteroidSpawnTimer;
    private int _cometSpawnTimer;
    private int _heartSpawnTimer;
    private int _doubleShotSpawnTimer;
    private int _snakeSpawnTimer;
    private int _superAlienSpawnTimer; // Timer per spawn Super Alien
    private int _nuclearMissileSpawnTimer; // Timer per missile nucleare
    private bool _gandalfActive;
    private int _gandalfTimer;
    private int _gandalfMinuteTimer; // Timer per apparizione ogni minuto
    
    public Player Player => _player;
    public UFO Ufo => _ufo;
    public TriangularUFO TriangularUfo => _triangularUFO; // UFO triangolare
    public bool IsGameOver { get; private set; }
    public bool IsVictory { get; private set; }
    public int HighScore { get; private set; }
    public int CurrentLevel { get; private set; }
    public int TotalScore { get; private set; } // Accumulo punteggio totale
    public bool GandalfActive => _gandalfActive;
    public IEnumerable<Asteroid> Asteroids => _asteroids;
    public IEnumerable<Comet> Comets => _comets;
    public IEnumerable<Heart> Hearts => _hearts;
    public IEnumerable<DoubleShotPowerup> DoubleShotPowerups => _doubleShotPowerups;
    public IEnumerable<PowerUp> PowerUps => _powerUps; // Nuovi potenziamenti
    public IEnumerable<Crater> Craters => _craters;
    public IEnumerable<SmokeParticle> SmokeParticles => _smokeParticles; // Corretto tipo
    public Snake? CurrentSnake1 => _snake1;
    public PacManChase? CurrentPacManChase => _pacmanChase;
    public BossFight? CurrentBossFight => _bossFight; // Boss fight attivo
    public IEnumerable<Seagull> Seagulls => _seagulls; // Gabbiani
    public IEnumerable<SuperAlien> SuperAliens => _superAliens; // Super alieni
    public IEnumerable<NuclearMissile> NuclearMissiles => _nuclearMissiles; // Missili nucleari
    public IEnumerable<RadioactiveMushroom> RadioactiveMushrooms => _radioactiveMushrooms; // Funghi atomici
    public SpaceInvadersCS.Graphics.WeatherSystem Weather => _weatherSystem;
    
    // Events for graphics mode
    public event Action<int, int, Color>? OnExplosion;
    public event Action<int, int, bool>? OnShoot;
    public event Action<int, int>? OnAlienHit;
    public event Action? OnPlayerHit;
    public event Action? OnGameOver;
    public event Action? OnVictory;
    public event Action<int>? OnUFODestroyed; // Bonus score
    public event Action? OnUFOSpawned; // UFO appears
    public event Action<int>? OnLevelComplete; // Level completed
    public event Action? OnGandalfAppears; // Gandalf rescue
    public event Action? OnCortanaActivated; // Cortana rescue
    public event Action? OnSnakeSpawned; // Snake appears
    public event Action<string>? OnPacManMessage; // Pac-Man thanks message
    public event Action<List<System.Drawing.Point>>? OnLightningStrike; // Lightning hits
    public event Action<string>? OnWeatherChange; // Weather state changes
    public event Action<int, int, int>? OnAsteroidImpact; // Asteroid hits ground (x, y, size)
    public event Action<int>? OnBossFightStart; // Boss fight iniziato
    public event Action<int>? OnBossFightComplete; // Boss fight completato (con reward)
    public event Action? OnBossFightFailed; // Boss fight fallito (timeout)
    public event Action<PowerUpType>? OnPowerUpCollected; // PowerUp raccolto

    
    public GameEngine()
    {
        _random = new Random();
        _player = new Player(50, 32);
        _alienFormation = new AlienFormation();
        _bullets = new List<Bullet>();
        _shields = new List<Shield>();
        _ufo = new UFO(_random);
        _triangularUFO = new TriangularUFO(_random); // Inizializza UFO triangolare
        _asteroids = new List<Asteroid>();
        _comets = new List<Comet>();
        _hearts = new List<Heart>();
        _doubleShotPowerups = new List<DoubleShotPowerup>();
        _powerUps = new List<PowerUp>(); // Inizializza nuovi powerup
        _craters = new List<Crater>();
        _smokeParticles = new List<SmokeParticle>();
        _snake1 = null;
        _randomSnakes = new List<Snake>();
        _pacmanChase = null;
        _bossFight = null; // Inizializza boss fight
        _seagulls = new List<Seagull>(); // Inizializza gabbiani
        _superAliens = new List<SuperAlien>(); // Inizializza super alieni
        _nuclearMissiles = new List<NuclearMissile>(); // Inizializza missili nucleari
        _radioactiveMushrooms = new List<RadioactiveMushroom>(); // Inizializza funghi atomici
        _weatherSystem = new SpaceInvadersCS.Graphics.WeatherSystem();
        _frameCount = 0;
        _ufoSpawnTimer = 0;
        _triangularUFOSpawnTimer = _random.Next(180, 300); // 6-10 secondi (ridotto)
        _asteroidSpawnTimer = 0;
        _cometSpawnTimer = 0;
        _heartSpawnTimer = 0;
        _doubleShotSpawnTimer = 0;
        _snakeSpawnTimer = 0;
        _superAlienSpawnTimer = _random.Next(600, 900); // 20-30 secondi
        _nuclearMissileSpawnTimer = _random.Next(900, 1500); // 30-50 secondi
        _gandalfActive = false;
        _gandalfTimer = 0;
        _gandalfMinuteTimer = 0;
        IsGameOver = false;
        IsVictory = false;
        HighScore = 0;
        CurrentLevel = 1;
        TotalScore = 0;
        
        CreateShields();
        SpawnSeagulls(); // Crea i 2 gabbiani iniziali
        
        // Setup weather events
        _weatherSystem.OnLightningStrike += HandleLightningStrike;
        _weatherSystem.OnWindPush += HandleWindPush;
        _weatherSystem.OnWeatherChange += HandleWeatherChange;
    }
    
    public void CreateShields()
    {
        _shields.Clear(); // Pulisci scudi esistenti
        int[] shieldPositions = { 20, 40, 60, 80 };
        
        foreach (var x in shieldPositions)
        {
            // Create 5 segments for each shield (was 3) - bigger shields
            for (int i = 0; i < 5; i++)
            {
                _shields.Add(new Shield(x + i, 28));
            }
        }
    }
    
    private void SpawnSeagulls()
    {
        // Crea 2 gabbiani in posizioni casuali
        _seagulls.Clear();
        for (int i = 0; i < 2; i++)
        {
            int x = _random.Next(100, 700);
            int y = _random.Next(80, 200);
            _seagulls.Add(new Seagull(_random, x, y));
        }
    }
    
    public void Update()
    {
        if (IsGameOver || IsVictory) return;
        
        _frameCount++;
        
        // Update weather system
        _weatherSystem.Update();
        
        // Update seagulls (sempre attivi)
        foreach (var seagull in _seagulls)
        {
            seagull.Update();
        }
        
        // Update player (per gestione scudo e powerup)
        _player.Update();
        
        // Update bullets
        foreach (var bullet in _bullets)
        {
            bullet.Update();
        }
        
        // Remove inactive bullets
        _bullets.RemoveAll(b => !b.IsActive);
        
        // Update alien formation
        _alienFormation.Update();
        
        // Update UFO
        _ufo.Update();
        
        // UFO spawn logic - random appearance every 10-20 seconds (300-600 frames)
        _ufoSpawnTimer++;
        if (!_ufo.IsActive && _ufoSpawnTimer > 240 + _random.Next(360)) // 8-20 secondi (ridotto)
        {
            _ufo.Spawn();
            _ufoSpawnTimer = 0;
            OnUFOSpawned?.Invoke(); // Notify UFO arrival
        }
        
        // Update e spawn TriangularUFO
        _triangularUFO.Update();
        
        // TriangularUFO spawn logic - ogni 6-10 secondi (ridotto)
        _triangularUFOSpawnTimer++;
        if (!_triangularUFO.IsActive && _triangularUFOSpawnTimer > 180 + _random.Next(120))
        {
            _triangularUFO.Spawn();
            _triangularUFOSpawnTimer = 0;
            OnUFOSpawned?.Invoke(); // Notify UFO triangolare arrival
        }
        
        // Asteroid spawn logic - ogni 5-10 secondi
        _asteroidSpawnTimer++;
        if (_asteroidSpawnTimer > 150 + _random.Next(150))
        {
            int asteroidX = _random.Next(5, 95);
            _asteroids.Add(new Asteroid(asteroidX, 0));
            _asteroidSpawnTimer = 0;
        }
        
        // Comet spawn logic - ogni 15-30 secondi
        _cometSpawnTimer++;
        if (_cometSpawnTimer > 450 + _random.Next(450))
        {
            // Cometa da sinistra o destra
            bool fromLeft = _random.Next(2) == 0;
            int cometX = fromLeft ? 0 : 100;
            int cometY = 5 + _random.Next(15);
            int speedX = fromLeft ? 2 : -2;
            int speedY = 1;
            _comets.Add(new Comet(cometX, cometY, speedX, speedY));
            _cometSpawnTimer = 0;
        }
        
        // Update asteroids
        foreach (var asteroid in _asteroids)
        {
            asteroid.Update();
            
            // Check if asteroid hit the ground (Y >= 35)
            if (!asteroid.IsActive && asteroid.Y >= 35)
            {
                // Create crater at impact location
                var crater = new Crater(asteroid.X, asteroid.Y, asteroid.Size, 900); // Dura 30 secondi
                
                // Subscribe to smoke emission
                crater.OnSmokeEmit += (x, y) =>
                {
                    // Crea particella di fumo
                    float velocityX = ((float)_random.NextDouble() - 0.5f) * 0.2f;
                    float velocityY = -0.3f - (float)_random.NextDouble() * 0.2f; // Sale verso l'alto
                    float size = 2f + (float)_random.NextDouble() * 2f;
                    int life = 60 + _random.Next(60); // 2-4 secondi
                    _smokeParticles.Add(new SmokeParticle(x, y, velocityX, velocityY, size, life));
                };
                
                _craters.Add(crater);
                OnAsteroidImpact?.Invoke(asteroid.X, asteroid.Y, asteroid.Size);
            }
        }
        _asteroids.RemoveAll(a => !a.IsActive);
        
        // Update comets
        foreach (var comet in _comets)
        {
            comet.Update();
        }
        _comets.RemoveAll(c => !c.IsActive);
        
        // Heart spawn logic - ogni 20-30 secondi
        _heartSpawnTimer++;
        if (_heartSpawnTimer > 600 + _random.Next(300))
        {
            int heartX = _random.Next(5, 95);
            _hearts.Add(new Heart(heartX, 0));
            _heartSpawnTimer = 0;
        }
        
        // Update hearts
        foreach (var heart in _hearts)
        {
            heart.Update();
        }
        _hearts.RemoveAll(h => !h.IsActive);
        
        // Double shot powerup spawn logic - ogni 15-25 secondi
        _doubleShotSpawnTimer++;
        if (_doubleShotSpawnTimer > 450 + _random.Next(300))
        {
            int powerupX = _random.Next(5, 95);
            _doubleShotPowerups.Add(new DoubleShotPowerup(powerupX, 0));
            _doubleShotSpawnTimer = 0;
        }
        
        // Update double shot powerups
        foreach (var powerup in _doubleShotPowerups)
        {
            powerup.Update();
        }
        _doubleShotPowerups.RemoveAll(p => !p.IsActive);
        
        // Update new powerups (SpeedBoost, TripleShot, Shield, RapidFire, LaserWeapon)
        foreach (var powerup in _powerUps)
        {
            powerup.Update();
        }
        _powerUps.RemoveAll(p => !p.IsActive);
        
        // Super Alien spawn logic - ogni 20-30 secondi, fonde 2 alieni dalla formazione
        _superAlienSpawnTimer--;
        if (_superAlienSpawnTimer <= 0 && _superAliens.Count == 0) // Max 1 super alien alla volta
        {
            var activeAliens = _alienFormation.GetAliens().Where(a => a.IsActive).ToList();
            if (activeAliens.Count >= 2)
            {
                // Prendi 2 alieni casuali
                var alien1 = activeAliens[_random.Next(activeAliens.Count)];
                activeAliens.Remove(alien1);
                var alien2 = activeAliens[_random.Next(activeAliens.Count)];
                
                // Posizione media tra i 2 alieni
                int startX = (alien1.X + alien2.X) / 2;
                int startY = (alien1.Y + alien2.Y) / 2;
                
                // Disattiva i 2 alieni normali
                alien1.IsActive = false;
                alien2.IsActive = false;
                
                // Crea super alieno
                _superAliens.Add(new SuperAlien(startX, startY));
                
                _superAlienSpawnTimer = _random.Next(600, 900); // Reset timer 20-30 secondi
            }
            else
            {
                _superAlienSpawnTimer = 300; // Riprova tra 10 secondi se non ci sono abbastanza alieni
            }
        }
        
        // Update super aliens
        foreach (var superAlien in _superAliens)
        {
            superAlien.Update();
        }
        _superAliens.RemoveAll(s => !s.IsActive);
        
        // Nuclear Missile spawn logic - ogni 30-50 secondi
        _nuclearMissileSpawnTimer--;
        if (_nuclearMissileSpawnTimer <= 0)
        {
            int missileX = _random.Next(10, 90);
            _nuclearMissiles.Add(new NuclearMissile(missileX, 0));
            _nuclearMissileSpawnTimer = _random.Next(900, 1500); // Reset timer 30-50 secondi
        }
        
        // Update nuclear missiles
        foreach (var missile in _nuclearMissiles.Where(m => m.IsActive).ToList())
        {
            missile.Update();
            
            // Se esploso, crea fungo atomico
            if (missile.HasExploded)
            {
                missile.IsActive = false;
                _radioactiveMushrooms.Add(new RadioactiveMushroom(missile.X, missile.Y));
            }
        }
        _nuclearMissiles.RemoveAll(m => !m.IsActive);
        
        // Update radioactive mushrooms
        foreach (var mushroom in _radioactiveMushrooms)
        {
            mushroom.Update();
            
            // Controlla se il giocatore è nella zona radioattiva
            if (mushroom.IsPlayerInRadiation(_player.X, _player.Y, 800, 600))
            {
                // Danneggia il giocatore se non ha lo scudo attivo
                // Le radiazioni NON possono uccidere, lasciano sempre almeno 1 vita
                if (!_player.HasProtectiveShield && _player.Lives > 1)
                {
                    // Rallenta il danno: 1 danno ogni 30 frames (1 secondo)
                    if (_frameCount % 30 == 0)
                    {
                        _player.TakeDamage(); // Danno ridotto dalle radiazioni
                    }
                }
            }
        }
        _radioactiveMushrooms.RemoveAll(m => !m.IsActive);
        
            // Update craters
            foreach (var crater in _craters)
            {
                crater.Update();
            }
            _craters.RemoveAll(c => !c.IsActive);
            
            // Update smoke particles
            foreach (var smoke in _smokeParticles)
            {
                smoke.Update();
            }
            _smokeParticles.RemoveAll(s => !s.IsActive);
            
        // Snake spawn logic - ogni 20 secondi (600 frames a 30 FPS), 1 solo snake centrale
        _snakeSpawnTimer++;
        if (_snake1 == null && _snakeSpawnTimer > 600) // 600 frames = 20 secondi a 30 FPS
        {
            _snake1 = new Snake(50, 0, _player.X, _player.Y);    // Snake centrale
            _snakeSpawnTimer = 0;
            OnSnakeSpawned?.Invoke();
        }
        
        // Update snake 1
        if (_snake1 != null && _snake1.IsActive)
        {
            _snake1.Update();
        }
        else if (_snake1 != null && !_snake1.IsActive)
        {
            _snake1 = null; // Rimuove lo snake per permettere il respawn
        }
        
        // Update random snakes (spawned by Cortana)
        foreach (var snake in _randomSnakes.Where(s => s.IsActive).ToList())
        {
            snake.Update();
        }
        _randomSnakes.RemoveAll(s => !s.IsActive);
        
        // Update Pac-Man Chase
        if (_pacmanChase != null && _pacmanChase.IsActive)
        {
            _pacmanChase.Update();
        }
        else if (_pacmanChase != null && !_pacmanChase.IsActive)
        {
            _pacmanChase = null;
        }
        
        // Gandalf timer
        if (_gandalfActive)
        {
            _gandalfTimer--;
            if (_gandalfTimer <= 0)
            {
                _gandalfActive = false;
            }
        }
        
        // Check if player needs Gandalf rescue
        CheckGandalfRescue();
        
        // Gandalf ogni 30 secondi (900 frames a 30 FPS) - più frequente
        _gandalfMinuteTimer++;
        if (_gandalfMinuteTimer >= 900 && !_gandalfActive)
        {
            ActivateGandalf();
            _gandalfMinuteTimer = 0;
        }
        
        // Check if aliens shoot
        var shooter = _alienFormation.GetRandomShooter();
        if (shooter != null)
        {
            _bullets.Add(shooter.Shoot());
            OnShoot?.Invoke(shooter.X, shooter.Y, false);
        }
        
        // Check collisions
        CheckCollisions();
        
        // Check game over conditions
        CheckGameStatus();
    }
    
    private void CheckCollisions()
    {
        // Player bullets vs UFO
        if (_ufo.IsActive && !_ufo.HasBeenHit)
        {
            foreach (var bullet in _bullets.Where(b => b.IsActive && b.Type == EntityType.PlayerBullet))
            {
                if (_ufo.CollidesWith(bullet))
                {
                    bullet.IsActive = false;
                    _ufo.IsActive = false;
                    _ufo.HasBeenHit = true;
                    _player.AddScore(_ufo.BonusScore);
                    
                    // Trigger UFO explosion (cyan color for bonus)
                    OnExplosion?.Invoke(_ufo.X, _ufo.Y, Color.Cyan);
                    OnUFODestroyed?.Invoke(_ufo.BonusScore);
                    break;
                }
            }
        }
        
        // Player bullets vs TriangularUFO (1000 punti!)
        if (_triangularUFO.IsActive && !_triangularUFO.HasBeenHit)
        {
            foreach (var bullet in _bullets.Where(b => b.IsActive && b.Type == EntityType.PlayerBullet))
            {
                if (_triangularUFO.CollidesWith(bullet))
                {
                    bullet.IsActive = false;
                    _triangularUFO.IsActive = false;
                    _triangularUFO.HasBeenHit = true;
                    _player.AddScore(_triangularUFO.BonusScore); // 1000 punti
                    
                    // Trigger UFO triangolare explosion (verde lime brillante)
                    OnExplosion?.Invoke(_triangularUFO.X, _triangularUFO.Y, Color.LimeGreen);
                    OnUFODestroyed?.Invoke(_triangularUFO.BonusScore);
                    break;
                }
            }
        }
        
        // Player bullets vs Aliens
        foreach (var bullet in _bullets.Where(b => b.IsActive && b.Type == EntityType.PlayerBullet))
        {
            foreach (var alien in _alienFormation.GetAliens().Where(a => a.IsActive && !a.IsFlying)) // Skip flying aliens
            {
                if (bullet.CollidesWith(alien))
                {
                    bullet.IsActive = false;
                    alien.IsActive = false;
                    _player.AddScore(alien.PointValue);
                    
                    // Drop PowerUp casualmente (15% probabilità)
                    if (_random.Next(100) < 15)
                    {
                        PowerUpType randomType = (PowerUpType)_random.Next(4); // 4 tipi di powerup
                        _powerUps.Add(new PowerUp(alien.X, alien.Y, randomType));
                    }
                    
                    // Trigger explosion event
                    Color explosionColor = alien.Type switch
                    {
                        EntityType.AlienType1 => Color.Red,
                        EntityType.AlienType2 => Color.Yellow,
                        _ => Color.Magenta
                    };
                    OnExplosion?.Invoke(alien.X, alien.Y, explosionColor);
                    OnAlienHit?.Invoke(alien.X, alien.Y);
                    break;
                }
            }
        }
        
        // Player bullets vs Shields
        foreach (var bullet in _bullets.Where(b => b.IsActive && b.Type == EntityType.PlayerBullet))
        {
            foreach (var shield in _shields.Where(s => s.IsActive))
            {
                if (bullet.CollidesWith(shield))
                {
                    bullet.IsActive = false;
                    shield.TakeDamage();
                    break;
                }
            }
        }
        
        // Alien bullets vs Player
        foreach (var bullet in _bullets.Where(b => b.IsActive && b.Type == EntityType.AlienBullet))
        {
            if (bullet.CollidesWith(_player))
            {
                bullet.IsActive = false;
                
                // Se ha scudo protettivo, il colpo viene assorbito
                if (!_player.HasProtectiveShield)
                {
                    _player.TakeDamage();
                    OnPlayerHit?.Invoke();
                }
                else
                {
                    // Esplosione sul scudo (effetto visivo cyan)
                    OnExplosion?.Invoke(_player.X, _player.Y, Color.Cyan);
                }
                break;
            }
        }
        
        // Alien bullets vs Shields
        foreach (var bullet in _bullets.Where(b => b.IsActive && b.Type == EntityType.AlienBullet))
        {
            foreach (var shield in _shields.Where(s => s.IsActive))
            {
                if (bullet.CollidesWith(shield))
                {
                    bullet.IsActive = false;
                    shield.TakeDamage();
                    break;
                }
            }
        }
        
        // Asteroids vs Player
        foreach (var asteroid in _asteroids.Where(a => a.IsActive))
        {
            if (asteroid.CollidesWith(_player))
            {
                asteroid.IsActive = false;
                
                if (!_player.HasProtectiveShield)
                {
                    _player.TakeDamage();
                    OnPlayerHit?.Invoke();
                }
                
                OnExplosion?.Invoke(asteroid.X, asteroid.Y, Color.Orange);
            }
        }
        
        // Asteroids vs Shields
        foreach (var asteroid in _asteroids.Where(a => a.IsActive))
        {
            foreach (var shield in _shields.Where(s => s.IsActive))
            {
                if (asteroid.CollidesWith(shield))
                {
                    asteroid.IsActive = false;
                    shield.TakeDamage();
                    OnExplosion?.Invoke(asteroid.X, asteroid.Y, Color.Gray);
                    break;
                }
            }
        }
        
        // Player bullets vs Snake 1 (sinistro) - 1000 punti
        if (_snake1 != null && _snake1.IsActive)
        {
            foreach (var bullet in _bullets.Where(b => b.IsActive && b.Type == EntityType.PlayerBullet))
            {
                if (bullet.CollidesWith(_snake1))
                {
                    bullet.IsActive = false;
                    _snake1.IsActive = false;
                    _player.AddScore(1000);
                    OnExplosion?.Invoke(_snake1.X, _snake1.Y, Color.Green);
                    OnAlienHit?.Invoke(_snake1.X, _snake1.Y);
                    
                    // Spawn Pac-Man se non già presente
                    SpawnPacManChase();
                    break;
                }
            }
        }
        
        // Player bullets vs random snakes (spawned by Cortana) - 1000 punti
        foreach (var snake in _randomSnakes.Where(s => s.IsActive).ToList())
        {
            foreach (var bullet in _bullets.Where(b => b.IsActive && b.Type == EntityType.PlayerBullet))
            {
                if (bullet.CollidesWith(snake))
                {
                    bullet.IsActive = false;
                    snake.IsActive = false;
                    _player.AddScore(1000);
                    OnExplosion?.Invoke(snake.X, snake.Y, Color.Green);
                    OnAlienHit?.Invoke(snake.X, snake.Y);
                    
                    // Spawn Pac-Man se non già presente
                    SpawnPacManChase();
                    break;
                }
            }
        }
        
        // Player bullets vs Pac-Man Ghost - 500 punti
        if (_pacmanChase != null && _pacmanChase.IsActive && _pacmanChase.GhostAlive)
        {
            foreach (var bullet in _bullets.Where(b => b.IsActive && b.Type == EntityType.PlayerBullet))
            {
                if (_pacmanChase.IsGhostHit(bullet.X, bullet.Y))
                {
                    bullet.IsActive = false;
                    _pacmanChase.KillGhost();
                    _player.AddScore(500);
                    OnExplosion?.Invoke(_pacmanChase.X, _pacmanChase.Y, Color.Pink);
                    OnAlienHit?.Invoke(_pacmanChase.X, _pacmanChase.Y);
                    
                    // Pac-Man ringrazia!
                    OnPacManMessage?.Invoke(_pacmanChase.GetThankYouMessage());
                    break;
                }
            }
        }
        
        // Hearts vs Shields - heal damaged shields and recreate missing ones
        foreach (var heart in _hearts.Where(h => h.IsActive))
        {
            foreach (var shield in _shields.Where(s => s.IsActive && s.Health < 3))
            {
                if (heart.CollidesWith(shield))
                {
                    heart.IsActive = false;
                    shield.Health = 3; // Cura completamente
                    
                    // Ricrea parte delle difese (aggiungi nuovi segmenti)
                    int[] shieldPositions = { 20, 40, 60, 80 };
                    foreach (var x in shieldPositions)
                    {
                        int activeSegments = _shields.Count(s => s.IsActive && Math.Abs(s.X - x) < 6);
                        if (activeSegments < 5) // Se mancano segmenti
                        {
                            // Ricrea i segmenti mancanti
                            for (int i = 0; i < 5; i++)
                            {
                                if (!_shields.Any(s => s.IsActive && s.X == x + i && s.Y == 28))
                                {
                                    _shields.Add(new Shield(x + i, 28));
                                }
                            }
                        }
                    }
                    
                    // Pink heart explosion effect
                    OnExplosion?.Invoke(heart.X, heart.Y, Color.Pink);
                    break;
                }
            }
        }
        
        // Double shot powerup vs Player
        foreach (var powerup in _doubleShotPowerups.Where(p => p.IsActive))
        {
            if (powerup.CollidesWith(_player))
            {
                powerup.IsActive = false;
                _player.EnableDoubleShot(); // Attiva doppio colpo
                // Yellow explosion effect for powerup
                OnExplosion?.Invoke(powerup.X, powerup.Y, Color.Yellow);
            }
        }
        
        // New PowerUps vs Player (SpeedBoost, TripleShot, Shield, RapidFire)
        foreach (var powerup in _powerUps.Where(p => p.IsActive))
        {
            if (powerup.CollidesWith(_player))
            {
                powerup.IsActive = false;
                ApplyPowerUp(powerup.Type, powerup.Duration);
                
                // Explosion effect con colore del powerup
                Color powerUpColor = powerup.Type switch
                {
                    PowerUpType.SpeedBoost => Color.Cyan,
                    PowerUpType.TripleShot => Color.Orange,
                    PowerUpType.Shield => Color.LightBlue,
                    PowerUpType.RapidFire => Color.Yellow,
                    _ => Color.White
                };
                OnExplosion?.Invoke(powerup.X, powerup.Y, powerUpColor);
                OnPowerUpCollected?.Invoke(powerup.Type);
            }
        }
        
        // Player bullets vs Boss Fight
        if (_bossFight != null && _bossFight.IsActive)
        {
            foreach (var bullet in _bullets.Where(b => b.IsActive && b.Type == EntityType.PlayerBullet))
            {
                foreach (var boss in _bossFight.Bosses.Where(b => !b.IsDestroyed()))
                {
                    // IMPORTANTE: Usa boss.CollidesWith(bullet) invece di bullet.CollidesWith(boss)
                    // perché Boss ha un override che gestisce la conversione coordinate pixel
                    if (boss.CollidesWith(bullet))
                    {
                        bullet.IsActive = false;
                        boss.Hit();
                        
                        // Esplosione al colpo
                        OnExplosion?.Invoke(boss.X, boss.Y, Color.FromArgb(255, 100, 100));
                        
                        // Se il boss è distrutto, aggiungi punti
                        if (boss.IsDestroyed())
                        {
                            OnAlienHit?.Invoke(boss.X, boss.Y);
                        }
                        break;
                    }
                }
            }
        }
        
        // Player bullets vs Super Alien - 500 punti, droppa Laser Weapon
        foreach (var superAlien in _superAliens.Where(s => s.IsActive).ToList())
        {
            foreach (var bullet in _bullets.Where(b => b.IsActive && b.Type == EntityType.PlayerBullet).ToList())
            {
                if (bullet.CollidesWith(superAlien))
                {
                    bullet.IsActive = false;
                    
                    // Super alien prende danno
                    bool destroyed = superAlien.TakeDamage();
                    
                    if (destroyed)
                    {
                        superAlien.IsActive = false;
                        _player.AddScore(SuperAlien.ScoreValue); // 500 punti
                        
                        // Droppa arma laser
                        _powerUps.Add(new LaserWeapon(superAlien.X, superAlien.Y));
                        
                        // Esplosione magenta
                        OnExplosion?.Invoke(superAlien.X, superAlien.Y, Color.Magenta);
                        OnAlienHit?.Invoke(superAlien.X, superAlien.Y);
                    }
                    else
                    {
                        // Colpo andato a segno ma non distrutto
                        OnExplosion?.Invoke(superAlien.X, superAlien.Y, Color.FromArgb(255, 150, 0, 150));
                    }
                    
                    break;
                }
            }
        }
    }
    
    private void CheckGandalfRescue()
    {
        // Gandalf appare se:
        // 1) Giocatore ha solo 1 vita rimanente
        // 2) Meno di 5 scudi attivi
        // 3) Gandalf non è già attivo
        
        int activeShields = _shields.Count(s => s.IsActive);
        
        if (!_gandalfActive && _player.Lives == 1 && activeShields < 5)
        {
            ActivateGandalf();
        }
        
        // Update Gandalf timer
        if (_gandalfActive)
        {
            _gandalfTimer--;
            if (_gandalfTimer <= 0)
            {
                _gandalfActive = false;
            }
        }
    }
    
    private void ActivateGandalf()
    {
        // GANDALF APPARE!
        _gandalfActive = true;
        _gandalfTimer = 120; // 4 secondi
        OnGandalfAppears?.Invoke();
        
        // Gandalf ripara gli scudi danneggiati
        foreach (var shield in _shields)
        {
            if (shield.IsActive && shield.Health < 3)
            {
                shield.Health = 3; // Ripristina a salute piena
            }
        }
        
        // Aggiunge nuovi scudi se troppo pochi
        int activeShields = _shields.Count(s => s.IsActive);
        if (activeShields < 3)
        {
            int[] shieldPositions = { 20, 40, 60, 80 };
            foreach (var x in shieldPositions)
            {
                bool hasShieldHere = _shields.Any(s => s.IsActive && Math.Abs(s.X - x) < 3);
                if (!hasShieldHere)
                {
                    for (int i = 0; i < 5; i++)
                    {
                        _shields.Add(new Shield(x + i, 28));
                    }
                    break; // Aggiunge solo un gruppo alla volta
                }
            }
        }
    }
    
    private void CheckGameStatus()
    {
        // Check if player lost all lives - GAME OVER
        if (_player.Lives <= 0)
        {
            IsGameOver = true;
            OnGameOver?.Invoke();
            return;
        }
        
        // Check if aliens reached bottom - GAME OVER
        if (_alienFormation.HasReachedBottom(35))
        {
            IsGameOver = true;
            OnGameOver?.Invoke();
            return;
        }
        
        // Update Boss Fight (anche se non attivo, per gestire il timer di delay dopo completamento)
        if (_bossFight != null)
        {
            _bossFight.Update();
        }
        
        // Controlla se il boss fight è completato E il delay è finito
        if (_bossFight != null && _bossFight.IsReadyToRemove())
        {
            int reward = _bossFight.GetReward();
            if (_bossFight.IsSuccessful)
            {
                _player.AddScore(reward);
                OnBossFightComplete?.Invoke(reward);
            }
            else
            {
                // Boss hanno vinto, mostra messaggio (già visualizzato nel Draw)
                OnBossFightFailed?.Invoke();
            }
            
            // Boss fight terminato, avanza al livello successivo
            _bossFight = null;
            AdvanceToNextLevel();
        }
        
        // Check if all aliens destroyed - inizia boss fight
        if (_alienFormation.AliveCount == 0 && _bossFight == null)
        {
            // Accumula punteggio totale
            TotalScore = _player.Score;
            
            // Verifica se siamo al livello 10 DOPO aver completato il boss fight
            // Per ora, avvia boss fight per tutti i livelli 1-10
            StartBossFight();
        }
    }
    
    private void StartBossFight()
    {
        // Crea boss fight con dimensioni in pixel (800x600 approssimativo)
        // Usa Width/Height del rendering, ma dobbiamo passare valori ragionevoli
        // 800x600 è una dimensione standard, i boss saranno centrati
        _bossFight = new BossFight(800, 600);
        _bossFight.Start();
        OnBossFightStart?.Invoke(CurrentLevel);
    }
    
    private void AdvanceToNextLevel()
    {
        // Verifica se abbiamo completato il livello 10 (finale)
        if (CurrentLevel >= 10)
        {
            // Completato livello 10 - VITTORIA FINALE!
            IsVictory = true;
            OnVictory?.Invoke();
            return; // Non incrementare oltre
        }
        
        CurrentLevel++;
        OnLevelComplete?.Invoke(CurrentLevel);
        
        // Ripristina alien formation con velocità aumentata
        float speedMultiplier = 1.0f + (CurrentLevel - 1) * 0.15f; // +15% per livello
        _alienFormation = new AlienFormation();
        _alienFormation.IncreaseSpeed(speedMultiplier);
        
        // Ripristina scudi (opzionale, solo parzialmente)
        if (CurrentLevel % 3 == 0) // Ogni 3 livelli ripristina scudi
        {
            CreateShields();
        }
        
        // Pulisci proiettili
        _bullets.Clear();
        
        // NON resettare IsVictory, continuiamo a giocare
        IsVictory = false;
    }
    
    public void PlayerMoveLeft()
    {
        _player.MoveLeft();
    }
    
    public void PlayerMoveRight()
    {
        _player.MoveRight(95);
    }
    
    public void PlayerShoot()
    {
        var bullets = _player.ShootDouble();
        if (bullets != null)
        {
            _bullets.AddRange(bullets);
            OnShoot?.Invoke(_player.X, _player.Y, true);
        }
    }
    
    public void SetPlayerPosition(int x)
    {
        _player.X = Math.Clamp(x, 0, 99);
    }
    
    public void UpdatePlayerShootState()
    {
        // Player can shoot again when there are no active player bullets
        if (!_bullets.Any(b => b.IsActive && b.Type == EntityType.PlayerBullet))
        {
            _player.CanShoot = true;
        }
    }
    
    public void ActivateCortana()
    {
        // Ripristina tutte le barriere
        CreateShields();
        
        // Notifica evento
        OnCortanaActivated?.Invoke();
    }
    
    public void SpawnRandomSnake(int randomX)
    {
        // Spawna uno snake casuale alla posizione X indicata
        var newSnake = new Snake(randomX, 0, _player.X, _player.Y);
        _randomSnakes.Add(newSnake);
    }
    
    private void SpawnPacManChase()
    {
        // Spawna Pac-Man solo se non è già presente
        if (_pacmanChase == null || !_pacmanChase.IsActive)
        {
            int spawnX = _random.Next(20, 80); // Posizione X casuale
            _pacmanChase = new PacManChase(spawnX, -5); // Parte fuori schermo in alto
        }
    }
    
    public IEnumerable<Entity> GetAllEntities()
    {
        var entities = new List<Entity> { _player };
        
        if (_ufo.IsActive)
        {
            entities.Add(_ufo);
        }
        
        if (_snake1 != null && _snake1.IsActive)
        {
            entities.Add(_snake1);
        }
        
        // Add random snakes spawned by Cortana
        entities.AddRange(_randomSnakes.Where(s => s.IsActive));
        
        entities.AddRange(_alienFormation.GetAliens());
        entities.AddRange(_bullets);
        entities.AddRange(_shields);
        entities.AddRange(_asteroids);
        entities.AddRange(_comets);
        entities.AddRange(_hearts);
        return entities.Where(e => e.IsActive);
    }
    
    public int GetAnimationFrame() => _frameCount / 10;
    
    private void HandleLightningStrike(List<System.Drawing.Point> strikePositions)
    {
        // I fulmini colpiscono fino a 5 alieni nelle posizioni indicate
        var aliens = _alienFormation.GetAliens().ToList();
        int aliensHit = 0;
        
        foreach (var pos in strikePositions)
        {
            if (aliensHit >= 5) break; // Max 5 alieni per fulmine
            
            // Trova l'alieno più vicino alla posizione del fulmine
            var nearestAlien = aliens
                .Where(a => a.IsActive)
                .OrderBy(a => Math.Abs(a.X - pos.X) + Math.Abs(a.Y - pos.Y))
                .FirstOrDefault();
            
            if (nearestAlien != null)
            {
                nearestAlien.IsActive = false;
                _player.AddScore(nearestAlien.PointValue);
                OnExplosion?.Invoke(nearestAlien.X, nearestAlien.Y, Color.Yellow);
                OnAlienHit?.Invoke(nearestAlien.X, nearestAlien.Y);
                aliens.Remove(nearestAlien);
                aliensHit++;
            }
        }
        
        // Notifica il colpo di fulmine per effetti grafici
        OnLightningStrike?.Invoke(strikePositions);
        
        // Check victory - ma solo se non c'è un boss fight attivo!
        // Se c'è un boss fight, la vittoria viene gestita dal completamento del boss fight
        if (_alienFormation.GetAliens().All(a => !a.IsActive) && _bossFight == null)
        {
            // Tutti gli alieni morti e nessun boss fight in corso
            // NON impostare vittoria qui, lascia che StartBossFight gestisca il flusso
            // (il controllo in Update() a riga 947 si occuperà di avviare il boss fight)
        }
    }
    
    private void HandleWindPush(int direction)
    {
        // Il vento sposta gli scudi di 1 unità nella direzione indicata
        foreach (var shield in _shields.Where(s => s.IsActive))
        {
            int newX = shield.X + direction;
            
            // Previeni che gli scudi escano dallo schermo
            if (newX >= 5 && newX <= 95)
            {
                shield.X = newX;
            }
        }
    }
    
    private void HandleWeatherChange(string weatherName)
    {
        // Notifica il cambio meteo per mostrare "CLIMA ALERT!"
        OnWeatherChange?.Invoke(weatherName);
    }
    
    private void ApplyPowerUp(PowerUpType type, int duration)
    {
        switch (type)
        {
            case PowerUpType.SpeedBoost:
                _player.EnableSpeedBoost(duration);
                break;
                
            case PowerUpType.TripleShot:
                _player.EnableTripleShot(duration);
                break;
                
            case PowerUpType.Shield:
                _player.EnableProtectiveShield(duration);
                break;
                
            case PowerUpType.RapidFire:
                _player.EnableRapidFire(duration);
                break;
                
            case PowerUpType.LaserWeapon:
                _player.EnableLaserWeapon(duration);
                break;
        }
    }
}
