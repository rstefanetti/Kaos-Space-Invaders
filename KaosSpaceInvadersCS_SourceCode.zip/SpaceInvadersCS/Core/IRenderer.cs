namespace SpaceInvaders;

public interface IRenderer
{
    void Render(GameEngine engine);
    void ShowWelcomeScreen();
}
