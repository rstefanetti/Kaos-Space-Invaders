using System.Diagnostics;

namespace SpaceInvaders;

public class ConsoleGame
{
    private GameEngine? _engine;
    private readonly ConsoleRenderer _renderer;
    private readonly InputHandler _inputHandler;
    private bool _isRunning;
    private const int TargetFPS = 30;
    private const int FrameTime = 1000 / TargetFPS;
    
    public ConsoleGame()
    {
        _renderer = new ConsoleRenderer();
        _inputHandler = new InputHandler();
        _isRunning = false;
    }
    
    public void Run()
    {
        _renderer.ShowWelcomeScreen();
        StartNewGame();
        
        var stopwatch = Stopwatch.StartNew();
        long lastFrameTime = 0;
        
        _isRunning = true;
        
        while (_isRunning)
        {
            long currentTime = stopwatch.ElapsedMilliseconds;
            long deltaTime = currentTime - lastFrameTime;
            
            if (deltaTime >= FrameTime)
            {
                lastFrameTime = currentTime;
                
                // Process input
                _isRunning = _inputHandler.ProcessInput();
                
                // Update game state
                if (_engine != null)
                {
                    _engine.Update();
                    _engine.UpdatePlayerShootState();
                    
                    // Render
                    _renderer.Render(_engine);
                }
                
                // Small sleep to prevent CPU burning
                Thread.Sleep(1);
            }
        }
        
        Console.Clear();
        Console.WriteLine("\nThanks for playing Space Invaders!");
        Console.WriteLine($"Final Score: {_engine?.Player.Score ?? 0}");
        Console.WriteLine($"High Score: {_engine?.HighScore ?? 0}");
        Console.WriteLine("\nPress any key to exit...");
        Console.ReadKey();
    }
    
    private void StartNewGame()
    {
        _engine = new GameEngine();
        SetupInputBindings();
    }
    
    private void SetupInputBindings()
    {
        if (_engine == null) return;
        
        // Movement
        _inputHandler.RegisterKeyBinding(ConsoleKey.LeftArrow, () => _engine.PlayerMoveLeft());
        _inputHandler.RegisterKeyBinding(ConsoleKey.A, () => _engine.PlayerMoveLeft());
        
        _inputHandler.RegisterKeyBinding(ConsoleKey.RightArrow, () => _engine.PlayerMoveRight());
        _inputHandler.RegisterKeyBinding(ConsoleKey.D, () => _engine.PlayerMoveRight());
        
        // Shooting
        _inputHandler.RegisterKeyBinding(ConsoleKey.Spacebar, () => _engine.PlayerShoot());
        
        // Restart
        _inputHandler.RegisterKeyBinding(ConsoleKey.R, () =>
        {
            if (_engine.IsGameOver || _engine.IsVictory)
            {
                StartNewGame();
            }
        });
    }
}
