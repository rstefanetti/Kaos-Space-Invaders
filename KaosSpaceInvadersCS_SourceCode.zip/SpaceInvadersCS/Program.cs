// KAOS Space Invaders, RS 2025
using System.Windows.Forms;
using SpaceInvaders.GraphicsMode;

Application.EnableVisualStyles();
Application.SetCompatibleTextRenderingDefault(false);

// Start the game
Application.Run(new GameForm());
