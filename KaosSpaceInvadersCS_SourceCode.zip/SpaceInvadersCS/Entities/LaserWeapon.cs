using System;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace SpaceInvaders.Entities;

/// <summary>
/// Arma laser che droppa dal SuperAlien.
/// Dura 8 secondi e permette di sparare laser potenti.
/// </summary>
public class LaserWeapon : PowerUp
{
    private float _glowPhase;
    private int _particleFrame;
    
    public LaserWeapon(int x, int y) : base(x, y, PowerUpType.LaserWeapon)
    {
        Duration = 240; // 8 secondi a 30 FPS
        _glowPhase = 0;
        _particleFrame = 0;
    }
    
    public override void Update()
    {
        base.Update();
        _glowPhase += 0.2f;
        _particleFrame++;
    }
    
    public override void Draw(Graphics g)
    {
        if (!IsActive) return;
        
        int screenX = X * 8;
        int screenY = Y * 17;
        int size = Size;
        
        g.SmoothingMode = SmoothingMode.AntiAlias;
        
        // Alone laser rosso pulsante
        float pulseScale = 1.0f + (float)Math.Sin(_glowPhase) * 0.3f;
        int glowSize = (int)(size * 2.5f * pulseScale);
        
        using (var glowPath = new GraphicsPath())
        {
            glowPath.AddEllipse(screenX - glowSize / 2, screenY - glowSize / 2, glowSize, glowSize);
            using (var glowBrush = new PathGradientBrush(glowPath))
            {
                glowBrush.CenterColor = Color.FromArgb(180, 255, 0, 0); // Rosso laser
                glowBrush.SurroundColors = new[] { Color.FromArgb(0, 255, 0, 0) };
                g.FillPath(glowBrush, glowPath);
            }
        }
        
        // Simbolo laser (cristallo rosso a forma di rombo)
        Point[] diamond = new Point[]
        {
            new Point(screenX, screenY - size / 2),           // Top
            new Point(screenX + size / 2, screenY),           // Right
            new Point(screenX, screenY + size / 2),           // Bottom
            new Point(screenX - size / 2, screenY)            // Left
        };
        
        using (var laserBrush = new LinearGradientBrush(
            new Rectangle(screenX - size / 2, screenY - size / 2, size, size),
            Color.FromArgb(255, 255, 50, 50),   // Rosso chiaro
            Color.FromArgb(255, 150, 0, 0),     // Rosso scuro
            45f))
        {
            g.FillPolygon(laserBrush, diamond);
        }
        
        // Bordo brillante
        using (var borderPen = new Pen(Color.FromArgb(255, 255, 100, 100), 2))
        {
            g.DrawPolygon(borderPen, diamond);
        }
        
        // Nucleo centrale brillante
        using (var coreBrush = new SolidBrush(Color.FromArgb(200, 255, 255, 255)))
        {
            g.FillEllipse(coreBrush, screenX - 4, screenY - 4, 8, 8);
        }
        
        // Raggi laser che ruotano
        using (var rayPen = new Pen(Color.FromArgb(150, 255, 0, 0), 2))
        {
            for (int i = 0; i < 4; i++)
            {
                float angle = (_particleFrame * 3 + i * 90) % 360;
                int rayLength = size;
                int endX = screenX + (int)(Math.Cos(angle * Math.PI / 180) * rayLength);
                int endY = screenY + (int)(Math.Sin(angle * Math.PI / 180) * rayLength);
                
                g.DrawLine(rayPen, screenX, screenY, endX, endY);
            }
        }
        
        // Particelle rosse orbitanti
        for (int i = 0; i < 8; i++)
        {
            float orbitAngle = (_particleFrame * 4 + i * 45) % 360;
            float orbitRadius = size * 0.8f;
            int particleX = screenX + (int)(Math.Cos(orbitAngle * Math.PI / 180) * orbitRadius);
            int particleY = screenY + (int)(Math.Sin(orbitAngle * Math.PI / 180) * orbitRadius);
            
            using (var particleBrush = new SolidBrush(Color.FromArgb(220, 255, 50, 50)))
            {
                g.FillEllipse(particleBrush, particleX - 3, particleY - 3, 6, 6);
            }
        }
        
        // Testo "LASER"
        using (var font = new Font("Arial", 8, FontStyle.Bold))
        using (var textBrush = new SolidBrush(Color.White))
        using (var shadowBrush = new SolidBrush(Color.Black))
        {
            string text = "LASER";
            SizeF textSize = g.MeasureString(text, font);
            g.DrawString(text, font, shadowBrush, screenX - textSize.Width / 2 + 1, screenY + size / 2 + 6);
            g.DrawString(text, font, textBrush, screenX - textSize.Width / 2, screenY + size / 2 + 5);
        }
    }
}
