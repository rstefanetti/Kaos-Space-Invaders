using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;

namespace SpaceInvaders.Entities;

/// <summary>
/// Tipo di boss
/// </summary>
public enum BossType
{
    Gandalf,
    Cortana,
    ObiWan,
    Yoda
}

/// <summary>
/// Singolo boss che ruota sul disco
/// </summary>
public class Boss : Entity
{
    public new BossType Type { get; } // new nasconde Entity.Type
    public int HitPoints { get; private set; }
    public const int MaxHitPoints = 3;
    public int Size { get; } = 80; // Dimensione del boss
    private float _angle;
    private readonly int _orbitRadius;
    private readonly int _centerX;
    private readonly int _centerY;
    private readonly float _rotationSpeed;
    private int _hitFlashTimer;
    
    public Boss(BossType type, int centerX, int centerY, int orbitRadius, float startAngle, float rotationSpeed) 
        : base(0, 0, EntityType.None)
    {
        Type = type;
        HitPoints = MaxHitPoints;
        _angle = startAngle;
        _centerX = centerX;
        _centerY = centerY;
        _orbitRadius = orbitRadius;
        _rotationSpeed = rotationSpeed;
        _hitFlashTimer = 0;
        
        UpdatePosition();
    }
    
    public override char GetSprite(int frame) => '◉'; // Sprite cerchio per boss
    
    public override void Update()
    {
        // Ruota attorno al centro
        _angle += _rotationSpeed;
        if (_angle > 360) _angle -= 360;
        
        UpdatePosition();
        
        if (_hitFlashTimer > 0)
            _hitFlashTimer--;
    }
    
    private void UpdatePosition()
    {
        // Calcola posizione sul disco circolare
        double angleRad = _angle * Math.PI / 180.0;
        X = _centerX + (int)(Math.Cos(angleRad) * _orbitRadius) - Size / 2;
        Y = _centerY + (int)(Math.Sin(angleRad) * _orbitRadius) - Size / 2;
    }
    
    public void Hit()
    {
        if (HitPoints > 0)
        {
            HitPoints--;
            _hitFlashTimer = 10; // Flash bianco per 10 frames
        }
    }
    
    public bool IsDestroyed() => HitPoints <= 0;
    
    /// <summary>
    /// Override di CollidesWith per gestire coordinate pixel del boss vs coordinate gioco dei bullet
    /// Assume bullet abbia coordinate 0-100 (gioco), boss abbia coordinate pixel (800x600)
    /// </summary>
    public new bool CollidesWith(Entity other)
    {
        if (!IsActive || !other.IsActive) return false;
        
        // Converti coordinate bullet da unità gioco a pixel
        // Assumiamo schermo 800x600 (come passato al costruttore BossFight)
        int bulletPixelX = other.X * 8; // 800 / 100 = 8
        int bulletPixelY = other.Y * 17; // 600 / 36 ≈ 16.67, arrotondiamo a 17
        
        // Centro del boss
        int bossCenterX = X + Size / 2;
        int bossCenterY = Y + Size / 2;
        
        // Raggio di collisione aumentato per tolleranza
        int collisionRadius = Size / 2 + 15; // Aggiungiamo 15 pixel di tolleranza
        
        // Distanza dal centro del boss al bullet
        int dx = bulletPixelX - bossCenterX;
        int dy = bulletPixelY - bossCenterY;
        int distanceSquared = dx * dx + dy * dy;
        
        // Collisione se la distanza è minore del raggio
        return distanceSquared <= (collisionRadius * collisionRadius);
    }
    
    public void Draw(Graphics g)
    {
        if (IsDestroyed()) return;
        
        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        
        // Flash bianco quando colpito
        if (_hitFlashTimer > 0)
        {
            using var flashBrush = new SolidBrush(Color.FromArgb(200, 255, 255, 255));
            g.FillEllipse(flashBrush, X - 5, Y - 5, Size + 10, Size + 10);
        }
        
        // Glow colorato attorno al boss
        using (var glowBrush = new SolidBrush(Color.FromArgb(100, GetBossColor())))
        {
            g.FillEllipse(glowBrush, X - 10, Y - 10, Size + 20, Size + 20);
        }
        
        // Carica e disegna immagine del boss
        try
        {
            string imagePath = GetBossImagePath();
            if (File.Exists(imagePath))
            {
                using var bossImage = Image.FromFile(imagePath);
                g.DrawImage(bossImage, X, Y, Size, Size);
            }
            else
            {
                // Fallback: cerchio colorato se immagine non trovata
                DrawFallbackCircle(g);
            }
        }
        catch
        {
            // Fallback in caso di errore
            DrawFallbackCircle(g);
        }
        
        // Barra energia
        DrawHealthBar(g);
    }
    
    private string GetBossImagePath()
    {
        string fileName = Type switch
        {
            BossType.Gandalf => "gandalf.png",
            BossType.Cortana => "cortana.png",
            BossType.ObiWan => "obiwan.png",
            BossType.Yoda => "YodaAttack.png",
            _ => "gandalf.png"
        };
        
        // Prova prima nella directory corrente, poi nella bin
        string currentDir = Path.Combine(Directory.GetCurrentDirectory(), fileName);
        if (File.Exists(currentDir))
            return currentDir;
        
        // Prova directory relativa
        return fileName;
    }
    
    private void DrawFallbackCircle(Graphics g)
    {
        // Cerchio di sfondo
        using (var bgBrush = new System.Drawing.Drawing2D.LinearGradientBrush(
            new Rectangle(X, Y, Size, Size),
            Color.FromArgb(220, GetBossColor()),
            Color.FromArgb(255, GetDarkerColor(GetBossColor())),
            45f))
        {
            g.FillEllipse(bgBrush, X, Y, Size, Size);
        }
        
        // Bordo
        using (var borderPen = new Pen(Color.White, 3))
        {
            g.DrawEllipse(borderPen, X, Y, Size, Size);
        }
        
        // Nome del boss
        using (var font = new Font("Arial", 10, FontStyle.Bold))
        using (var textBrush = new SolidBrush(Color.White))
        using (var shadowBrush = new SolidBrush(Color.Black))
        {
            string name = Type.ToString();
            var textSize = g.MeasureString(name, font);
            int textX = X + (Size - (int)textSize.Width) / 2;
            int textY = Y + (Size - (int)textSize.Height) / 2;
            
            // Ombra
            g.DrawString(name, font, shadowBrush, textX + 1, textY + 1);
            // Testo
            g.DrawString(name, font, textBrush, textX, textY);
        }
    }
    
    private void DrawHealthBar(Graphics g)
    {
        int barWidth = 60;
        int barHeight = 6;
        int barX = X + (Size - barWidth) / 2;
        int barY = Y + Size - 15;
        
        // Sfondo barra
        using (var bgBrush = new SolidBrush(Color.FromArgb(100, 0, 0, 0)))
        {
            g.FillRectangle(bgBrush, barX, barY, barWidth, barHeight);
        }
        
        // HP rimanenti
        int hpWidth = (barWidth * HitPoints) / MaxHitPoints;
        Color hpColor = HitPoints switch
        {
            3 => Color.Green,
            2 => Color.Yellow,
            1 => Color.Red,
            _ => Color.Gray
        };
        
        using (var hpBrush = new SolidBrush(hpColor))
        {
            g.FillRectangle(hpBrush, barX, barY, hpWidth, barHeight);
        }
        
        // Bordo barra
        using (var borderPen = new Pen(Color.White, 1))
        {
            g.DrawRectangle(borderPen, barX, barY, barWidth, barHeight);
        }
    }
    
    private Color GetBossColor()
    {
        return Type switch
        {
            BossType.Gandalf => Color.FromArgb(200, 200, 200),  // Grigio (Gandalf il Grigio)
            BossType.Cortana => Color.FromArgb(100, 150, 255),  // Blu (Cortana AI)
            BossType.ObiWan => Color.FromArgb(100, 200, 255),   // Azzurro (Lightsaber blu)
            BossType.Yoda => Color.FromArgb(100, 255, 100),     // Verde (Yoda)
            _ => Color.White
        };
    }
    
    private Color GetDarkerColor(Color color)
    {
        return Color.FromArgb(
            Math.Max(0, color.R - 100),
            Math.Max(0, color.G - 100),
            Math.Max(0, color.B - 100)
        );
    }
}

/// <summary>
/// Sistema Boss Fight: 4 boss che ruotano su un disco, 20 secondi per eliminarli tutti
/// </summary>
public class BossFight
{
    public List<Boss> Bosses { get; }
    public int TimeRemaining { get; private set; } // In frames (20 secondi = 600 frames a 30 FPS)
    public bool IsActive { get; private set; }
    public bool IsCompleted { get; private set; }
    public bool IsSuccessful { get; private set; } // True se tutti i boss sono stati uccisi in tempo
    
    private readonly int _centerX;
    private readonly int _centerY;
    private readonly int _orbitRadius;
    private const int TotalTime = 600; // 20 secondi a 30 FPS
    private const int BossReward = 5000;
    private const int CompletionDelay = 90; // 3 secondi di delay dopo completamento (a 30 FPS)
    private int _completionTimer; // Timer per mostrare il messaggio finale
    
    public BossFight(int screenWidth, int screenHeight)
    {
        _centerX = screenWidth / 2;
        _centerY = screenHeight / 2 - 50;
        _orbitRadius = 150;
        
        Bosses = new List<Boss>();
        TimeRemaining = TotalTime;
        IsActive = false;
        IsCompleted = false;
        IsSuccessful = false;
        _completionTimer = 0;
    }
    
    public void Start()
    {
        IsActive = true;
        IsCompleted = false;
        IsSuccessful = false;
        TimeRemaining = TotalTime;
        _completionTimer = 0;
        
        Bosses.Clear();
        
        // Crea i 4 boss posizionati a 90 gradi l'uno dall'altro
        Bosses.Add(new Boss(BossType.Gandalf, _centerX, _centerY, _orbitRadius, 0, 1.5f));
        Bosses.Add(new Boss(BossType.Cortana, _centerX, _centerY, _orbitRadius, 90, 1.5f));
        Bosses.Add(new Boss(BossType.ObiWan, _centerX, _centerY, _orbitRadius, 180, 1.5f));
        Bosses.Add(new Boss(BossType.Yoda, _centerX, _centerY, _orbitRadius, 270, 1.5f));
    }
    
    public void Update()
    {
        if (!IsActive)
        {
            // Se completato, gestisci il timer di delay per mostrare il messaggio
            if (IsCompleted && _completionTimer > 0)
            {
                _completionTimer--;
            }
            return;
        }
        
        // Aggiorna timer
        TimeRemaining--;
        
        // Aggiorna posizioni boss
        foreach (var boss in Bosses)
        {
            boss.Update();
        }
        
        // Controlla se tutti i boss sono stati distrutti
        if (Bosses.All(b => b.IsDestroyed()))
        {
            IsCompleted = true;
            IsSuccessful = true;
            IsActive = false;
            _completionTimer = CompletionDelay; // Avvia timer di 3 secondi
        }
        
        // Controlla se il tempo è scaduto
        if (TimeRemaining <= 0)
        {
            IsCompleted = true;
            IsSuccessful = false;
            IsActive = false;
            _completionTimer = CompletionDelay; // Avvia timer di 3 secondi
        }
    }
    
    public void Draw(Graphics g, int screenWidth, int screenHeight)
    {
        // Mostra la scena sia durante che dopo il completamento (per il messaggio finale)
        if (!IsActive && !IsCompleted) return;
        
        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        
        // Sfondo semi-trasparente scuro
        using (var bgBrush = new SolidBrush(Color.FromArgb(150, 0, 0, 20)))
        {
            g.FillRectangle(bgBrush, 0, 0, screenWidth, screenHeight);
        }
        
        // Disco centrale (piattaforma)
        DrawDisk(g);
        
        // Boss
        foreach (var boss in Bosses)
        {
            boss.Draw(g);
        }
        
        // Timer e UI
        DrawUI(g, screenWidth);
    }
    
    private void DrawDisk(Graphics g)
    {
        // Disco centrale con effetto 3D
        int diskSize = _orbitRadius * 2 + 100;
        int diskX = _centerX - diskSize / 2;
        int diskY = _centerY - diskSize / 2;
        
        // Ombra disco
        using (var shadowBrush = new SolidBrush(Color.FromArgb(100, 0, 0, 0)))
        {
            g.FillEllipse(shadowBrush, diskX + 10, diskY + 10, diskSize, diskSize);
        }
        
        // Disco principale con gradiente radiale
        using (var diskPath = new System.Drawing.Drawing2D.GraphicsPath())
        {
            diskPath.AddEllipse(diskX, diskY, diskSize, diskSize);
            using (var diskBrush = new System.Drawing.Drawing2D.PathGradientBrush(diskPath))
            {
                diskBrush.CenterColor = Color.FromArgb(100, 80, 80, 150);
                diskBrush.SurroundColors = new[] { Color.FromArgb(200, 20, 20, 60) };
                g.FillEllipse(diskBrush, diskX, diskY, diskSize, diskSize);
            }
        }
        
        // Anelli concentrici sul disco
        for (int i = 1; i <= 3; i++)
        {
            int ringSize = diskSize - (i * 60);
            int ringX = _centerX - ringSize / 2;
            int ringY = _centerY - ringSize / 2;
            
            using (var ringPen = new Pen(Color.FromArgb(80, 150, 150, 200), 2))
            {
                g.DrawEllipse(ringPen, ringX, ringY, ringSize, ringSize);
            }
        }
        
        // Bordo esterno luminoso
        using (var borderPen = new Pen(Color.FromArgb(180, 255, 255, 255), 3))
        {
            g.DrawEllipse(borderPen, diskX, diskY, diskSize, diskSize);
        }
    }
    
    private void DrawUI(Graphics g, int screenWidth)
    {
        // Messaggio finale se completato
        if (IsCompleted)
        {
            using (var resultFont = new Font("Arial", 48, FontStyle.Bold))
            using (var shadowBrush = new SolidBrush(Color.Black))
            {
                string resultText;
                Color resultColor;
                
                if (IsSuccessful)
                {
                    resultText = "BOSS SCONFITTI! +5000 PUNTI!";
                    resultColor = Color.FromArgb(255, 50, 255, 50);
                }
                else
                {
                    resultText = "BOSS VINCONO!";
                    resultColor = Color.FromArgb(255, 255, 50, 50);
                }
                
                var resultSize = g.MeasureString(resultText, resultFont);
                int resultX = (screenWidth - (int)resultSize.Width) / 2;
                int resultY = 250;
                
                // Ombra
                g.DrawString(resultText, resultFont, shadowBrush, resultX + 4, resultY + 4);
                // Testo
                using (var resultBrush = new SolidBrush(resultColor))
                {
                    g.DrawString(resultText, resultFont, resultBrush, resultX, resultY);
                }
            }
            
            return; // Non mostrare timer/boss rimanenti se completato
        }
        
        // Titolo "BOSS FIGHT!" (solo durante la battaglia)
        using (var titleFont = new Font("Arial", 32, FontStyle.Bold))
        using (var titleBrush = new SolidBrush(Color.FromArgb(255, 255, 50, 50)))
        using (var shadowBrush = new SolidBrush(Color.Black))
        {
            string title = "BOSS FIGHT!";
            var titleSize = g.MeasureString(title, titleFont);
            int titleX = (screenWidth - (int)titleSize.Width) / 2;
            int titleY = 30;
            
            // Ombra
            g.DrawString(title, titleFont, shadowBrush, titleX + 3, titleY + 3);
            // Testo
            g.DrawString(title, titleFont, titleBrush, titleX, titleY);
        }
        
        // Timer
        int secondsRemaining = TimeRemaining / 30;
        Color timerColor = secondsRemaining > 10 ? Color.White : Color.Red;
        
        using (var timerFont = new Font("Arial", 24, FontStyle.Bold))
        using (var timerBrush = new SolidBrush(timerColor))
        using (var shadowBrush = new SolidBrush(Color.Black))
        {
            string timerText = $"Tempo: {secondsRemaining}s";
            var timerSize = g.MeasureString(timerText, timerFont);
            int timerX = (screenWidth - (int)timerSize.Width) / 2;
            int timerY = 80;
            
            // Ombra
            g.DrawString(timerText, timerFont, shadowBrush, timerX + 2, timerY + 2);
            // Testo
            g.DrawString(timerText, timerFont, timerBrush, timerX, timerY);
        }
        
        // Boss rimanenti
        int bossesRemaining = Bosses.Count(b => !b.IsDestroyed());
        using (var bossFont = new Font("Arial", 18, FontStyle.Bold))
        using (var bossBrush = new SolidBrush(Color.Yellow))
        using (var shadowBrush = new SolidBrush(Color.Black))
        {
            string bossText = $"Boss rimanenti: {bossesRemaining}/4";
            var bossSize = g.MeasureString(bossText, bossFont);
            int bossX = (screenWidth - (int)bossSize.Width) / 2;
            int bossY = 120;
            
            // Ombra
            g.DrawString(bossText, bossFont, shadowBrush, bossX + 2, bossY + 2);
            // Testo
            g.DrawString(bossText, bossFont, bossBrush, bossX, bossY);
        }
    }
    
    /// <summary>
    /// Verifica se il boss fight è pronto per essere rimosso (completato + delay finito)
    /// </summary>
    public bool IsReadyToRemove()
    {
        return IsCompleted && _completionTimer <= 0;
    }
    
    public int GetReward()
    {
        return IsSuccessful ? BossReward : 0;
    }
}
