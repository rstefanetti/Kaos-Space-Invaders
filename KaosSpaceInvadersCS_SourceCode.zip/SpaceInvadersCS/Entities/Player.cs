namespace SpaceInvaders;

public class Player : Entity
{
    public int Lives { get; set; }
    public int Score { get; set; }
    public bool CanShoot { get; set; }
    public bool HasDoubleShot { get; private set; }
    private int _doubleShotTimer;
    public bool HasProtectiveShield { get; private set; }
    private int _shieldCycleTimer;
    private int _shieldDurationTimer;
    private const int ShieldCycleTime = 1200; // 40 secondi a 30 FPS
    private const int ShieldDuration = 600; // 20 secondi a 30 FPS
    
    // Nuovi PowerUp
    public bool HasSpeedBoost { get; private set; }
    private int _speedBoostTimer;
    public bool HasTripleShot { get; private set; }
    private int _tripleShotTimer;
    public bool HasRapidFire { get; private set; }
    private int _rapidFireTimer;
    private int _rapidFireCooldown; // Riduce il cooldown tra colpi
    public bool HasLaserWeapon { get; private set; }
    private int _laserWeaponTimer;
    
    // Sistema energia (2 colpi prima di perdere vita)
    public int Energy { get; private set; }
    public const int MaxEnergy = 2;
    
    public Player(int x, int y) : base(x, y, EntityType.Player)
    {
        Lives = 5; // Cambiato da 3 a 5
        Energy = MaxEnergy; // Inizia con energia piena
        Score = 0;
        CanShoot = true;
        HasDoubleShot = false;
        _doubleShotTimer = 0;
        HasProtectiveShield = false;
        _shieldCycleTimer = ShieldCycleTime; // Inizia il ciclo
        _shieldDurationTimer = 0;
        
        // Inizializza nuovi powerup
        HasSpeedBoost = false;
        _speedBoostTimer = 0;
        HasTripleShot = false;
        _tripleShotTimer = 0;
        HasRapidFire = false;
        _rapidFireTimer = 0;
        _rapidFireCooldown = 0;
        HasLaserWeapon = false;
        _laserWeaponTimer = 0;
    }
    
    public override char GetSprite(int frame) => '▲';
    
    public override void Update()
    {
        // Player updates are handled by input
        // Update double shot timer
        if (_doubleShotTimer > 0)
        {
            _doubleShotTimer--;
            if (_doubleShotTimer == 0)
            {
                HasDoubleShot = false;
            }
        }
        
        // Update new powerup timers
        if (_speedBoostTimer > 0)
        {
            _speedBoostTimer--;
            if (_speedBoostTimer == 0)
            {
                HasSpeedBoost = false;
            }
        }
        
        if (_tripleShotTimer > 0)
        {
            _tripleShotTimer--;
            if (_tripleShotTimer == 0)
            {
                HasTripleShot = false;
            }
        }
        
        if (_rapidFireTimer > 0)
        {
            _rapidFireTimer--;
            if (_rapidFireTimer == 0)
            {
                HasRapidFire = false;
            }
        }
        
        if (_rapidFireCooldown > 0)
        {
            _rapidFireCooldown--;
        }
        
        if (_laserWeaponTimer > 0)
        {
            _laserWeaponTimer--;
            if (_laserWeaponTimer == 0)
            {
                HasLaserWeapon = false;
            }
        }
        
        // Gestione scudo ciclico
        if (HasProtectiveShield)
        {
            // Scudo attivo: conta durata
            _shieldDurationTimer--;
            if (_shieldDurationTimer <= 0)
            {
                HasProtectiveShield = false;
                _shieldCycleTimer = ShieldCycleTime; // Riavvia ciclo
            }
        }
        else
        {
            // Scudo inattivo: conta ciclo
            _shieldCycleTimer--;
            if (_shieldCycleTimer <= 0)
            {
                HasProtectiveShield = true;
                _shieldDurationTimer = ShieldDuration;
            }
        }
    }
    
    public void EnableDoubleShot()
    {
        HasDoubleShot = true;
        _doubleShotTimer = 300; // 10 secondi a 30 FPS
    }
    
    public void MoveLeft()
    {
        if (X > 1) X--;
    }
    
    public void MoveRight(int maxX)
    {
        if (X < maxX - 1) X++;
    }
    
    public Bullet? Shoot()
    {
        if (!CanShoot) return null;
        
        CanShoot = false;
        return new Bullet(X, Y - 1, EntityType.PlayerBullet, -1);
    }
    
    public List<Bullet>? ShootDouble()
    {
        if (!CanShoot) return null;
        
        CanShoot = false;
        
        if (HasTripleShot)
        {
            // Spara tre colpi (sinistra, centro, destra)
            return new List<Bullet>
            {
                new Bullet(X - 1, Y - 1, EntityType.PlayerBullet, -1),
                new Bullet(X, Y - 1, EntityType.PlayerBullet, -1),
                new Bullet(X + 1, Y - 1, EntityType.PlayerBullet, -1)
            };
        }
        else if (HasDoubleShot)
        {
            // Spara due colpi paralleli
            return new List<Bullet>
            {
                new Bullet(X - 1, Y - 1, EntityType.PlayerBullet, -1),
                new Bullet(X + 1, Y - 1, EntityType.PlayerBullet, -1)
            };
        }
        else
        {
            // Sparo singolo normale
            return new List<Bullet>
            {
                new Bullet(X, Y - 1, EntityType.PlayerBullet, -1)
            };
        }
    }
    
    public void TakeDamage()
    {
        // Scala prima l'energia
        Energy--;
        
        // Se l'energia è esaurita, perde una vita
        if (Energy < 0)
        {
            Lives--;
            if (Lives > 0)
            {
                Energy = MaxEnergy; // Ripristina energia solo se ha ancora vite
            }
            else
            {
                Energy = 0; // Nessuna energia se morto
            }
        }
        
        IsActive = Lives > 0;
    }
    
    public void AddLife()
    {
        Lives++;
    }
    
    public void AddScore(int points)
    {
        Score += points;
    }
    
    // Nuovi metodi per PowerUp
    public void EnableSpeedBoost(int duration)
    {
        HasSpeedBoost = true;
        _speedBoostTimer = duration;
    }
    
    public void EnableTripleShot(int duration)
    {
        HasTripleShot = true;
        _tripleShotTimer = duration;
    }
    
    public void EnableProtectiveShield(int duration)
    {
        HasProtectiveShield = true;
        _shieldDurationTimer = duration;
        _shieldCycleTimer = 0; // Reset del ciclo automatico
    }
    
    public void EnableRapidFire(int duration)
    {
        HasRapidFire = true;
        _rapidFireTimer = duration;
    }
    
    public void EnableLaserWeapon(int duration)
    {
        HasLaserWeapon = true;
        _laserWeaponTimer = duration;
    }
    
    public int GetMoveSpeed()
    {
        // Velocità aumentata con SpeedBoost
        return HasSpeedBoost ? 2 : 1;
    }
    
    public bool CanShootRapid()
    {
        // RapidFire permette di sparare più rapidamente
        if (HasRapidFire && _rapidFireCooldown == 0)
        {
            _rapidFireCooldown = 5; // Cooldown ridotto (invece di 15-20)
            return true;
        }
        return CanShoot;
    }
}
