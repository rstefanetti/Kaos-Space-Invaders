namespace SpaceInvaders;

public enum EntityType
{
    None,
    Player,
    AlienType1,
    AlienType2,
    AlienType3,
    PlayerBullet,
    AlienBullet,
    Shield,
    UFO,
    TriangularUFO, // UFO triangolare (1000 punti)
    Asteroid,
    Comet,
    Heart,
    Powerup,
    Snake
}

public abstract class Entity
{
    public int X { get; set; }
    public int Y { get; set; }
    public bool IsActive { get; set; }
    public EntityType Type { get; set; }
    public int Health { get; set; }
    
    protected Entity(int x, int y, EntityType type)
    {
        X = x;
        Y = y;
        Type = type;
        IsActive = true;
        Health = 1;
    }
    
    public abstract char GetSprite(int frame);
    public abstract void Update();
    
    public bool CollidesWith(Entity other)
    {
        if (!IsActive || !other.IsActive) return false;
        
        // Use hitbox with tolerance for better collision detection
        int hitboxSize = 2; // Tolerance in console units
        
        return Math.Abs(X - other.X) <= hitboxSize && 
               Math.Abs(Y - other.Y) <= hitboxSize;
    }
}
