using System;

namespace SpaceInvaders.Entities;

// Heart powerup that falls and heals shields
public class Heart : SpaceInvaders.Entity
{
    private float _fallSpeed = 0.5f; // Rallentata da 1.0 a 0.5
    public float PulsePhase { get; private set; }
    
    public Heart(int x, int y) : base(x, y, EntityType.Heart)
    {
        PulsePhase = 0;
    }
    
    public override void Update()
    {
        if (!IsActive) return;
        
        // Fall down
        Y += (int)_fallSpeed;
        
        // Pulse animation
        PulsePhase += 0.1f;
        if (PulsePhase > Math.PI * 2) PulsePhase -= (float)(Math.PI * 2);
        
        // Deactivate when off screen
        if (Y > 36) // Console height is ~36
        {
            IsActive = false;
        }
    }
    
    public override char GetSprite(int frame)
    {
        return '♥';
    }
}
