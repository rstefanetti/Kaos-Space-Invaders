namespace SpaceInvaders;

public class Shield : Entity
{
    public Shield(int x, int y) : base(x, y, EntityType.Shield)
    {
        Health = 3; // Can take 3 hits
    }
    
    public override char GetSprite(int frame)
    {
        return Health switch
        {
            3 => '█',
            2 => '▓',
            1 => '▒',
            _ => ' '
        };
    }
    
    public override void Update()
    {
        // Shields are static
    }
    
    public void TakeDamage()
    {
        Health--;
        if (Health <= 0)
        {
            IsActive = false;
        }
    }
}
