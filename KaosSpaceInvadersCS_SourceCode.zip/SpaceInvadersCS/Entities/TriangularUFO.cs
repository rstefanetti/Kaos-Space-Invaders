using System.Drawing;
using System.Drawing.Drawing2D;

namespace SpaceInvaders;

public class TriangularUFO : Entity
{
    private readonly Random _random;
    private int _direction; // 1 = right, -1 = left
    private const int BonusPoints = 1000;
    public int Width { get; set; }
    public int Height { get; set; }
    
    public int BonusScore => BonusPoints;
    public bool HasBeenHit { get; set; }
    private float _glowPhase;
    
    public TriangularUFO(Random random) : base(0, 26, EntityType.TriangularUFO) // Y=26 è sopra le difese (che sono a Y=28-30)
    {
        _random = random;
        _direction = _random.Next(2) == 0 ? 1 : -1;
        
        // UFO triangolare parte da sinistra o destra
        X = _direction == 1 ? 0 : 99;
        Y = 26; // Appena sopra le difese
        Width = 5;
        Height = 3;
        IsActive = false;
        HasBeenHit = false;
        _glowPhase = 0;
    }
    
    public void Spawn()
    {
        _direction = _random.Next(2) == 0 ? 1 : -1;
        X = _direction == 1 ? 0 : 99;
        Y = 26;
        IsActive = true;
        HasBeenHit = false;
        _glowPhase = 0;
    }
    
    public override void Update()
    {
        if (!IsActive) return;
        
        X += _direction * 2; // Velocità 2 (più veloce dell'UFO normale)
        _glowPhase += 0.1f;
        
        // Disattiva quando esce dallo schermo
        if (X < -10 || X > 110)
        {
            IsActive = false;
        }
    }
    
    public override char GetSprite(int frame)
    {
        return '▲'; // Triangolo per UFO triangolare
    }
    
    public bool CollidesWith(Entity other)
    {
        if (!IsActive || !other.IsActive) return false;
        
        return other.X >= X && other.X < X + Width &&
               other.Y >= Y && other.Y < Y + Height;
    }
    
    public void Draw(Graphics g, int screenWidth, int screenHeight)
    {
        if (!IsActive) return;
        
        g.SmoothingMode = SmoothingMode.AntiAlias;
        
        // Converti coordinate di gioco in coordinate pixel
        int pixelX = X * (screenWidth / 100);
        int pixelY = Y * (screenHeight / 36);
        int pixelWidth = Width * (screenWidth / 100);
        int pixelHeight = Height * (screenHeight / 36);
        
        // OMBRA 3D sotto l'UFO
        using (var shadowPath = new GraphicsPath())
        {
            Point[] shadowTriangle = new Point[]
            {
                new Point(pixelX + pixelWidth / 2, pixelY + 3), // Punta in alto (offset ombra)
                new Point(pixelX - 5 + 3, pixelY + pixelHeight + 3), // Base sinistra
                new Point(pixelX + pixelWidth + 5 + 3, pixelY + pixelHeight + 3) // Base destra
            };
            shadowPath.AddPolygon(shadowTriangle);
            
            using (var shadowBrush = new PathGradientBrush(shadowPath))
            {
                shadowBrush.CenterColor = Color.FromArgb(100, 0, 0, 0);
                shadowBrush.SurroundColors = new[] { Color.FromArgb(0, 0, 0, 0) };
                g.FillPath(shadowBrush, shadowPath);
            }
        }
        
        // TRIANGOLO PRINCIPALE con gradiente metallico
        Point[] triangle = new Point[]
        {
            new Point(pixelX + pixelWidth / 2, pixelY), // Punta in alto
            new Point(pixelX - 5, pixelY + pixelHeight), // Base sinistra
            new Point(pixelX + pixelWidth + 5, pixelY + pixelHeight) // Base destra
        };
        
        using (var trianglePath = new GraphicsPath())
        {
            trianglePath.AddPolygon(triangle);
            
            // Gradiente metallico verde-lime
            using (var metalBrush = new PathGradientBrush(trianglePath))
            {
                metalBrush.CenterColor = Color.FromArgb(200, 180, 255, 100); // Centro chiaro lime
                metalBrush.SurroundColors = new[] { Color.FromArgb(255, 50, 150, 30) }; // Bordi verde scuro
                g.FillPath(metalBrush, trianglePath);
            }
        }
        
        // GLOW ESTERNO pulsante
        float glowIntensity = 0.5f + 0.5f * (float)Math.Sin(_glowPhase);
        using (var glowPen = new Pen(Color.FromArgb((int)(120 * glowIntensity), 100, 255, 100), 4))
        {
            g.DrawPolygon(glowPen, triangle);
        }
        
        // BORDO FLUORESCENTE lime brillante
        using (var borderPen = new Pen(Color.FromArgb(255, 150, 255, 150), 2))
        {
            g.DrawPolygon(borderPen, triangle);
        }
        
        // LUCI AI VERTICI del triangolo (3 luci)
        float lightPulse = 0.7f + 0.3f * (float)Math.Sin(_glowPhase * 2);
        
        // Luce punta superiore (gialla)
        using (var topLightBrush = new SolidBrush(Color.FromArgb((int)(200 * lightPulse), 255, 255, 100)))
        {
            g.FillEllipse(topLightBrush, triangle[0].X - 4, triangle[0].Y - 4, 8, 8);
        }
        
        // Luce base sinistra (rossa)
        using (var leftLightBrush = new SolidBrush(Color.FromArgb((int)(200 * lightPulse), 255, 100, 100)))
        {
            g.FillEllipse(leftLightBrush, triangle[1].X - 3, triangle[1].Y - 3, 6, 6);
        }
        
        // Luce base destra (blu)
        using (var rightLightBrush = new SolidBrush(Color.FromArgb((int)(200 * lightPulse), 100, 100, 255)))
        {
            g.FillEllipse(rightLightBrush, triangle[2].X - 3, triangle[2].Y - 3, 6, 6);
        }
        
        // SIMBOLO ALIENO al centro (occhio)
        int centerX = pixelX + pixelWidth / 2;
        int centerY = pixelY + pixelHeight / 2 + 5;
        
        using (var eyeBrush = new SolidBrush(Color.FromArgb(220, 255, 50, 50)))
        {
            g.FillEllipse(eyeBrush, centerX - 6, centerY - 4, 12, 8);
        }
        
        using (var pupilBrush = new SolidBrush(Color.FromArgb(255, 0, 0, 0)))
        {
            g.FillEllipse(pupilBrush, centerX - 3, centerY - 2, 6, 4);
        }
        
        // Highlight nell'occhio
        using (var highlightBrush = new SolidBrush(Color.FromArgb(180, 255, 255, 255)))
        {
            g.FillEllipse(highlightBrush, centerX - 1, centerY - 1, 3, 2);
        }
    }
}
