namespace SpaceInvaders;

public class Bullet : Entity
{
    public int VelocityY { get; private set; }
    
    public Bullet(int x, int y, EntityType type, int velocityY) : base(x, y, type)
    {
        VelocityY = velocityY;
    }
    
    public override char GetSprite(int frame)
    {
        return Type == EntityType.PlayerBullet ? '│' : '┃';
    }
    
    public override void Update()
    {
        Y += VelocityY;
        
        // Deactivate if out of bounds
        if (Y < 0 || Y > 35)
        {
            IsActive = false;
        }
    }
}
