using System;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace SpaceInvaders.Entities;

/// <summary>
/// Super alieno creato dalla fusione di 2 nemici normali.
/// Si muove in modo erratico e droppa un'arma laser quando sconfitto.
/// </summary>
public class SuperAlien : Entity
{
    public int HitPoints { get; private set; }
    public float VelocityX { get; set; }
    public float VelocityY { get; set; }
    public float FloatX { get; set; }
    public float FloatY { get; set; }
    public int AnimationFrame { get; private set; }
    public float Rotation { get; private set; }
    public const int ScoreValue = 500;
    
    private Random _random;
    private int _directionChangeTimer;
    private const int DirectionChangeInterval = 60; // Cambia direzione ogni 60 frames
    private float _pulsePhase;
    
    public SuperAlien(int startX, int startY) : base(startX, startY, EntityType.AlienType1)
    {
        HitPoints = 3; // Richiede 3 colpi per essere distrutto
        FloatX = startX;
        FloatY = startY;
        _random = new Random(startX + startY + Environment.TickCount);
        
        // Velocità iniziale casuale
        VelocityX = _random.Next(-3, 4) * 0.5f;
        VelocityY = _random.Next(-2, 3) * 0.5f;
        
        _directionChangeTimer = DirectionChangeInterval;
        _pulsePhase = 0;
        Rotation = 0;
    }
    
    public override void Update()
    {
        if (!IsActive) return;
        
        // Aggiorna posizione
        FloatX += VelocityX;
        FloatY += VelocityY;
        
        X = (int)FloatX;
        Y = (int)FloatY;
        
        // Cambia direzione periodicamente per movimento erratico
        _directionChangeTimer--;
        if (_directionChangeTimer <= 0)
        {
            VelocityX = _random.Next(-4, 5) * 0.6f;
            VelocityY = _random.Next(-3, 4) * 0.5f;
            _directionChangeTimer = DirectionChangeInterval;
        }
        
        // Rimbalza ai bordi
        if (FloatX <= 5)
        {
            FloatX = 5;
            VelocityX = Math.Abs(VelocityX);
        }
        if (FloatX >= 95)
        {
            FloatX = 95;
            VelocityX = -Math.Abs(VelocityX);
        }
        if (FloatY <= 5)
        {
            FloatY = 5;
            VelocityY = Math.Abs(VelocityY);
        }
        if (FloatY >= 31)
        {
            FloatY = 31;
            VelocityY = -Math.Abs(VelocityY);
        }
        
        // Animazione
        AnimationFrame = (AnimationFrame + 1) % 60;
        _pulsePhase += 0.15f;
        Rotation += 2f;
    }
    
    public override char GetSprite(int frame) => '☠'; // Super alien sprite
    
    public bool TakeDamage()
    {
        HitPoints--;
        return HitPoints <= 0;
    }
    
    public void Draw(Graphics g, int screenWidth, int screenHeight)
    {
        if (!IsActive) return;
        
        int screenX = (int)(FloatX * (screenWidth / 100f));
        int screenY = (int)(FloatY * (screenHeight / 36f));
        int size = 50; // Più grande dei nemici normali
        
        g.SmoothingMode = SmoothingMode.AntiAlias;
        
        // Salva stato grafico
        var state = g.Save();
        
        // Trasforma per rotazione
        g.TranslateTransform(screenX, screenY);
        g.RotateTransform(Rotation);
        
        // Alone pulsante (più grande)
        float pulseScale = 1.0f + (float)Math.Sin(_pulsePhase) * 0.2f;
        int glowSize = (int)(size * 1.5f * pulseScale);
        
        using (var glowPath = new GraphicsPath())
        {
            glowPath.AddEllipse(-glowSize / 2, -glowSize / 2, glowSize, glowSize);
            using (var glowBrush = new PathGradientBrush(glowPath))
            {
                glowBrush.CenterColor = Color.FromArgb(150, 255, 0, 255); // Magenta brillante
                glowBrush.SurroundColors = new[] { Color.FromArgb(0, 255, 0, 255) };
                g.FillPath(glowBrush, glowPath);
            }
        }
        
        // Corpo principale (fusione di due alieni)
        using (var bodyBrush = new LinearGradientBrush(
            new Rectangle(-size / 2, -size / 2, size, size),
            Color.FromArgb(255, 200, 0, 200), // Magenta chiaro
            Color.FromArgb(255, 100, 0, 150), // Magenta scuro
            LinearGradientMode.Vertical))
        {
            g.FillEllipse(bodyBrush, -size / 2, -size / 2, size, size);
        }
        
        // Bordo brillante
        using (var borderPen = new Pen(Color.FromArgb(255, 255, 100, 255), 3))
        {
            g.DrawEllipse(borderPen, -size / 2, -size / 2, size, size);
        }
        
        // Occhi (4 occhi per indicare fusione di 2 alieni)
        using (var eyeBrush = new SolidBrush(Color.FromArgb(255, 255, 255, 0))) // Giallo
        {
            int eyeSize = 8;
            g.FillEllipse(eyeBrush, -15, -10, eyeSize, eyeSize);
            g.FillEllipse(eyeBrush, -5, -10, eyeSize, eyeSize);
            g.FillEllipse(eyeBrush, 5, -10, eyeSize, eyeSize);
            g.FillEllipse(eyeBrush, 15, -10, eyeSize, eyeSize);
        }
        
        // Pupille rosse
        using (var pupilBrush = new SolidBrush(Color.Red))
        {
            int pupilSize = 4;
            g.FillEllipse(pupilBrush, -13, -8, pupilSize, pupilSize);
            g.FillEllipse(pupilBrush, -3, -8, pupilSize, pupilSize);
            g.FillEllipse(pupilBrush, 7, -8, pupilSize, pupilSize);
            g.FillEllipse(pupilBrush, 17, -8, pupilSize, pupilSize);
        }
        
        // Tentacoli ondulati
        using (var tentaclePen = new Pen(Color.FromArgb(200, 150, 0, 200), 3))
        {
            for (int i = 0; i < 4; i++)
            {
                float angle = i * 90f;
                float waveOffset = (float)Math.Sin(_pulsePhase + i) * 5f;
                
                g.DrawLine(tentaclePen, 
                    0, 0,
                    (int)((size / 2 + waveOffset) * Math.Cos(angle * Math.PI / 180)),
                    (int)((size / 2 + waveOffset) * Math.Sin(angle * Math.PI / 180)));
            }
        }
        
        // Barra vita
        g.ResetTransform();
        g.TranslateTransform(screenX, screenY);
        
        int barWidth = 40;
        int barHeight = 5;
        int barY = size / 2 + 10;
        
        // Sfondo barra
        using (var barBgBrush = new SolidBrush(Color.FromArgb(150, 0, 0, 0)))
        {
            g.FillRectangle(barBgBrush, -barWidth / 2, barY, barWidth, barHeight);
        }
        
        // Vita rimanente
        float healthPercent = (float)HitPoints / 3f;
        int healthWidth = (int)(barWidth * healthPercent);
        
        Color healthColor = healthPercent > 0.5f ? Color.Lime : 
                           healthPercent > 0.25f ? Color.Yellow : Color.Red;
        
        using (var healthBrush = new SolidBrush(healthColor))
        {
            g.FillRectangle(healthBrush, -barWidth / 2, barY, healthWidth, barHeight);
        }
        
        // Ripristina stato grafico
        g.Restore(state);
        
        // Particelle magenta che orbitano
        for (int i = 0; i < 6; i++)
        {
            float orbitAngle = (AnimationFrame * 6 + i * 60) % 360;
            float orbitRadius = size * 0.7f;
            int particleX = screenX + (int)(Math.Cos(orbitAngle * Math.PI / 180) * orbitRadius);
            int particleY = screenY + (int)(Math.Sin(orbitAngle * Math.PI / 180) * orbitRadius);
            
            using (var particleBrush = new SolidBrush(Color.FromArgb(200, 255, 0, 255)))
            {
                g.FillEllipse(particleBrush, particleX - 3, particleY - 3, 6, 6);
            }
        }
    }
}
