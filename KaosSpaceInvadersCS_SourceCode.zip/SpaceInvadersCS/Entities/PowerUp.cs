using System;
using System.Drawing;

namespace SpaceInvaders.Entities;

/// <summary>
/// Tipi di potenziamenti disponibili
/// </summary>
public enum PowerUpType
{
    SpeedBoost,     // Velocità aumentata
    TripleShot,     // Spara 3 proiettili contemporaneamente
    Shield,         // Scudo protettivo
    RapidFire,      // Fuoco rapido
    LaserWeapon     // Arma laser (droppa da SuperAlien)
}

/// <summary>
/// Potenziamento che viene droppato dai nemici e raccoglibile dal giocatore
/// </summary>
public class PowerUp : Entity
{
    public new PowerUpType Type { get; } // new nasconde Entity.Type
    public int Duration { get; protected set; } // Durata in frames (secondi * 30 FPS) - protected set per LaserWeapon
    public int Size { get; } = 30; // Dimensione del powerup
    private float _floatOffset;
    private const float FloatSpeed = 0.05f;
    private const int FallSpeed = 2;
    private int _glowPhase;
    
    public PowerUp(int x, int y, PowerUpType type) : base(x, y, EntityType.Powerup)
    {
        Type = type;
        // Durata tra 5 e 8 secondi (150-240 frames a 30 FPS)
        Duration = new Random().Next(150, 240);
        _floatOffset = 0;
        _glowPhase = 0;
    }
    
    public override char GetSprite(int frame) => '◆'; // Sprite diamante per powerup
    
    public override void Update()
    {
        // Cade lentamente verso il basso
        Y += FallSpeed;
        
        // Effetto fluttuante
        _floatOffset += FloatSpeed;
        if (_floatOffset > Math.PI * 2)
        {
            _floatOffset -= (float)(Math.PI * 2);
        }
        
        // Effetto glow pulsante
        _glowPhase = (_glowPhase + 2) % 255;
    }
    
    public virtual void Draw(Graphics g)
    {
        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        
        // Calcola offset fluttuante
        int floatY = Y + (int)(Math.Sin(_floatOffset) * 5);
        
        // Glow esterno pulsante
        int glowAlpha = 100 + (int)(Math.Sin(_glowPhase * Math.PI / 127.5) * 80);
        using (var glowBrush = new SolidBrush(Color.FromArgb(glowAlpha, GetPowerUpColor())))
        {
            g.FillEllipse(glowBrush, X - 5, floatY - 5, Size + 10, Size + 10);
        }
        
        // Sfondo del power-up (cerchio)
        using (var bgBrush = new System.Drawing.Drawing2D.LinearGradientBrush(
            new Rectangle(X, floatY, Size, Size),
            Color.FromArgb(200, GetPowerUpColor()),
            Color.FromArgb(255, GetDarkerColor(GetPowerUpColor())),
            45f))
        {
            g.FillEllipse(bgBrush, X, floatY, Size, Size);
        }
        
        // Bordo luminoso
        using (var borderPen = new Pen(Color.FromArgb(255, 255, 255, 255), 2))
        {
            g.DrawEllipse(borderPen, X, floatY, Size, Size);
        }
        
        // Icona del power-up
        DrawIcon(g, X + Size / 2, floatY + Size / 2);
        
        // Particelle decorative
        DrawParticles(g, X + Size / 2, floatY + Size / 2);
    }
    
    private void DrawIcon(Graphics g, int centerX, int centerY)
    {
        using var iconPen = new Pen(Color.White, 2);
        using var iconBrush = new SolidBrush(Color.White);
        
        switch (Type)
        {
            case PowerUpType.SpeedBoost:
                // Frecce verso destra (velocità)
                DrawSpeedIcon(g, centerX, centerY, iconPen);
                break;
                
            case PowerUpType.TripleShot:
                // Tre linee verticali (tre colpi)
                DrawTripleShotIcon(g, centerX, centerY, iconPen);
                break;
                
            case PowerUpType.Shield:
                // Scudo
                DrawShieldIcon(g, centerX, centerY, iconPen, iconBrush);
                break;
                
            case PowerUpType.RapidFire:
                // Fulmine (fuoco rapido)
                DrawLightningIcon(g, centerX, centerY, iconBrush);
                break;
        }
    }
    
    private void DrawSpeedIcon(Graphics g, int x, int y, Pen pen)
    {
        // Tre frecce orizzontali
        Point[] arrow1 = { new Point(x - 10, y - 6), new Point(x, y - 6), new Point(x - 3, y - 9) };
        Point[] arrow2 = { new Point(x - 10, y), new Point(x + 3, y), new Point(x, y - 3) };
        Point[] arrow3 = { new Point(x - 10, y + 6), new Point(x, y + 6), new Point(x - 3, y + 9) };
        
        g.DrawLines(pen, arrow1);
        g.DrawLines(pen, arrow2);
        g.DrawLines(pen, arrow3);
    }
    
    private void DrawTripleShotIcon(Graphics g, int x, int y, Pen pen)
    {
        // Tre proiettili verticali
        g.DrawLine(pen, x - 8, y - 8, x - 8, y + 8);
        g.DrawLine(pen, x, y - 8, x, y + 8);
        g.DrawLine(pen, x + 8, y - 8, x + 8, y + 8);
        
        // Punte
        g.DrawLine(pen, x - 8, y - 8, x - 11, y - 5);
        g.DrawLine(pen, x - 8, y - 8, x - 5, y - 5);
        g.DrawLine(pen, x, y - 8, x - 3, y - 5);
        g.DrawLine(pen, x, y - 8, x + 3, y - 5);
        g.DrawLine(pen, x + 8, y - 8, x + 5, y - 5);
        g.DrawLine(pen, x + 8, y - 8, x + 11, y - 5);
    }
    
    private void DrawShieldIcon(Graphics g, int x, int y, Pen pen, Brush brush)
    {
        // Forma a scudo
        Point[] shield = {
            new Point(x, y - 10),
            new Point(x + 8, y - 5),
            new Point(x + 8, y + 5),
            new Point(x, y + 10),
            new Point(x - 8, y + 5),
            new Point(x - 8, y - 5)
        };
        
        using (var shieldBrush = new SolidBrush(Color.FromArgb(150, 255, 255, 255)))
        {
            g.FillPolygon(shieldBrush, shield);
        }
        g.DrawPolygon(pen, shield);
        
        // Croce centrale
        g.DrawLine(pen, x, y - 7, x, y + 7);
        g.DrawLine(pen, x - 5, y, x + 5, y);
    }
    
    private void DrawLightningIcon(Graphics g, int x, int y, Brush brush)
    {
        // Fulmine stilizzato
        Point[] lightning = {
            new Point(x - 2, y - 10),
            new Point(x + 2, y - 3),
            new Point(x + 5, y - 3),
            new Point(x - 3, y + 5),
            new Point(x, y),
            new Point(x - 5, y),
            new Point(x + 3, y - 8)
        };
        
        g.FillPolygon(brush, lightning);
    }
    
    private void DrawParticles(Graphics g, int centerX, int centerY)
    {
        // Particelle decorative che orbitano
        Color particleColor = GetPowerUpColor();
        using var particleBrush = new SolidBrush(Color.FromArgb(200, particleColor));
        
        for (int i = 0; i < 4; i++)
        {
            double angle = (_glowPhase + i * 90) * Math.PI / 180.0;
            int px = centerX + (int)(Math.Cos(angle) * 18);
            int py = centerY + (int)(Math.Sin(angle) * 18);
            g.FillEllipse(particleBrush, px - 2, py - 2, 4, 4);
        }
    }
    
    private Color GetPowerUpColor()
    {
        return Type switch
        {
            PowerUpType.SpeedBoost => Color.FromArgb(0, 255, 255),    // Cyan
            PowerUpType.TripleShot => Color.FromArgb(255, 165, 0),    // Arancione
            PowerUpType.Shield => Color.FromArgb(100, 200, 255),      // Blu chiaro
            PowerUpType.RapidFire => Color.FromArgb(255, 255, 0),     // Giallo
            _ => Color.White
        };
    }
    
    private Color GetDarkerColor(Color color)
    {
        return Color.FromArgb(
            Math.Max(0, color.R - 80),
            Math.Max(0, color.G - 80),
            Math.Max(0, color.B - 80)
        );
    }
    
    public new bool CollidesWith(Entity other) // new invece di override
    {
        // Collisione circolare più precisa
        int dx = (X + Size / 2) - (other.X + 1);
        int dy = (Y + Size / 2) - (other.Y + 1);
        int distance = (int)Math.Sqrt(dx * dx + dy * dy);
        
        return distance < (Size / 2 + 2);
    }
}
