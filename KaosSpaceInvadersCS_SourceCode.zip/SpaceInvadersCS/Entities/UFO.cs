namespace SpaceInvaders;

public class UFO : Entity
{
    private readonly Random _random;
    private int _direction; // 1 = right, -1 = left
    private int _bonusScore;
    public int Width { get; set; }
    public int Height { get; set; }
    
    public int BonusScore => _bonusScore;
    public bool HasBeenHit { get; set; }
    
    public UFO(Random random) : base(0, 2, EntityType.UFO)
    {
        _random = random;
        _direction = _random.Next(2) == 0 ? 1 : -1;
        
        // UFO starts from left or right edge
        X = _direction == 1 ? 0 : 99;
        Y = 2; // Top of screen
        Width = 4;
        Height = 2;
        IsActive = false;
        HasBeenHit = false;
        
        // Random bonus score: 50, 100, 150, 200, 250, 300
        _bonusScore = (_random.Next(6) + 1) * 50;
    }
    
    public void Spawn()
    {
        _direction = _random.Next(2) == 0 ? 1 : -1;
        X = _direction == 1 ? 0 : 99;
        Y = 2;
        IsActive = true;
        HasBeenHit = false;
        _bonusScore = (_random.Next(6) + 1) * 50;
    }
    
    public override void Update()
    {
        if (!IsActive) return;
        
        X += _direction; // Rallentato da 2 a 1
        
        // Deactivate when off screen
        if (X < -5 || X > 105)
        {
            IsActive = false;
        }
    }
    
    public override char GetSprite(int frame)
    {
        return '◊'; // Diamond character for UFO
    }
    
    public bool CollidesWith(Entity other)
    {
        if (!IsActive || !other.IsActive) return false;
        
        return other.X >= X && other.X < X + Width &&
               other.Y >= Y && other.Y < Y + Height;
    }
}
