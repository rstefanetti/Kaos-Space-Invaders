using System;
using System.Drawing;

namespace SpaceInvaders.Entities;

/// <summary>
/// Gabbiano che svolazza casualmente sullo schermo
/// </summary>
public class Seagull : Entity
{
    private readonly Random _random;
    private float _velocityX;
    private float _velocityY;
    private float _wingPhase; // Fase animazione ali
    private readonly float _wingSpeed;
    private int _changeDirectionTimer;
    private const int ChangeDirectionInterval = 120; // Cambia direzione ogni 4 secondi
    
    public Seagull(Random random, int startX, int startY) : base(startX, startY, EntityType.None)
    {
        _random = random;
        _velocityX = (float)(_random.NextDouble() * 2 - 1); // -1 a 1
        _velocityY = (float)(_random.NextDouble() * 0.5 - 0.25); // -0.25 a 0.25
        _wingPhase = 0;
        _wingSpeed = 0.3f + (float)_random.NextDouble() * 0.2f; // Velocità ali variabile
        _changeDirectionTimer = ChangeDirectionInterval;
    }
    
    public override char GetSprite(int frame) => '~'; // Sprite gabbiano
    
    public override void Update()
    {
        // Aggiorna posizione (in coordinate pixel)
        X += (int)(_velocityX * 2);
        Y += (int)_velocityY;
        
        // Aggiorna animazione ali
        _wingPhase += _wingSpeed;
        if (_wingPhase > Math.PI * 2) _wingPhase -= (float)(Math.PI * 2);
        
        // Cambia direzione casualmente
        _changeDirectionTimer--;
        if (_changeDirectionTimer <= 0)
        {
            _changeDirectionTimer = ChangeDirectionInterval;
            _velocityX += (float)(_random.NextDouble() * 1 - 0.5);
            _velocityY += (float)(_random.NextDouble() * 0.4 - 0.2);
            
            // Limita velocità
            _velocityX = Math.Clamp(_velocityX, -2f, 2f);
            _velocityY = Math.Clamp(_velocityY, -0.5f, 0.5f);
        }
        
        // Se esce dallo schermo, riappare dall'altro lato
        if (X < -50) X = 850;
        if (X > 850) X = -50;
        if (Y < 50) Y = 50;
        if (Y > 500) Y = 500;
    }
    
    public void Draw(Graphics g)
    {
        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        
        // Calcola angolo battito ali (-20° a +20°)
        float wingAngle = (float)(Math.Sin(_wingPhase) * 20);
        
        // Determina direzione (sinistra o destra)
        bool flyingRight = _velocityX > 0;
        
        // Corpo del gabbiano
        int bodyWidth = 30;
        int bodyHeight = 15;
        
        using (var bodyBrush = new SolidBrush(Color.White))
        {
            g.FillEllipse(bodyBrush, X - bodyWidth / 2, Y - bodyHeight / 2, bodyWidth, bodyHeight);
        }
        
        // Testa
        int headSize = 12;
        int headX = flyingRight ? X + bodyWidth / 3 : X - bodyWidth / 3;
        using (var headBrush = new SolidBrush(Color.White))
        {
            g.FillEllipse(headBrush, headX - headSize / 2, Y - bodyHeight / 2 - 5, headSize, headSize);
        }
        
        // Becco
        Point[] beakPoints = flyingRight 
            ? new[] {
                new Point(headX + headSize / 2, Y - bodyHeight / 2),
                new Point(headX + headSize / 2 + 8, Y - bodyHeight / 2 - 2),
                new Point(headX + headSize / 2 + 8, Y - bodyHeight / 2 + 2)
              }
            : new[] {
                new Point(headX - headSize / 2, Y - bodyHeight / 2),
                new Point(headX - headSize / 2 - 8, Y - bodyHeight / 2 - 2),
                new Point(headX - headSize / 2 - 8, Y - bodyHeight / 2 + 2)
              };
        
        using (var beakBrush = new SolidBrush(Color.Orange))
        {
            g.FillPolygon(beakBrush, beakPoints);
        }
        
        // Occhio
        int eyeX = flyingRight ? headX + 2 : headX - 2;
        g.FillEllipse(Brushes.Black, eyeX, Y - bodyHeight / 2 - 3, 3, 3);
        
        // Ali con animazione
        DrawWing(g, X - bodyWidth / 4, Y, wingAngle, flyingRight ? -1 : 1);
        DrawWing(g, X + bodyWidth / 4, Y, wingAngle, flyingRight ? 1 : -1);
        
        // Ombra sotto
        using (var shadowBrush = new SolidBrush(Color.FromArgb(50, 0, 0, 0)))
        {
            g.FillEllipse(shadowBrush, X - bodyWidth / 2 + 5, Y + bodyHeight / 2 + 3, bodyWidth - 10, 5);
        }
    }
    
    private void DrawWing(Graphics g, int centerX, int centerY, float angle, int direction)
    {
        // Salva stato grafico
        var state = g.Save();
        
        // Trasla al centro dell'ala
        g.TranslateTransform(centerX, centerY);
        
        // Ruota l'ala
        g.RotateTransform(angle * direction);
        
        // Disegna ala (forma curva)
        Point[] wingPoints = {
            new Point(0, 0),
            new Point(direction * 5, -8),
            new Point(direction * 15, -15),
            new Point(direction * 25, -18),
            new Point(direction * 20, -10),
            new Point(direction * 10, -5)
        };
        
        using (var wingBrush = new SolidBrush(Color.FromArgb(240, 240, 240)))
        using (var wingPen = new Pen(Color.LightGray, 1))
        {
            g.FillPolygon(wingBrush, wingPoints);
            g.DrawPolygon(wingPen, wingPoints);
        }
        
        // Ripristina stato grafico
        g.Restore(state);
    }
}
