namespace SpaceInvaders;

public class Asteroid : Entity
{
    private readonly Random _random;
    private float _rotation;
    private readonly float _rotationSpeed;
    public int Size { get; private set; }
    
    public Asteroid(int x, int y) : base(x, y, EntityType.Asteroid)
    {
        _random = new Random();
        Size = 3 + _random.Next(3); // Size 3-5
        _rotation = (float)_random.NextDouble() * 360f;
        _rotationSpeed = ((float)_random.NextDouble() - 0.5f) * 10f;
    }
    
    public float Rotation => _rotation;
    
    public override char GetSprite(int frame)
    {
        return '●'; // Cerchio pieno per asteroide
    }
    
    public override void Update()
    {
        Y += 1; // Cade verso il basso
        _rotation += _rotationSpeed;
        
        // Disattiva se esce dallo schermo (ma mantieni Y per cratere)
        if (Y > 35)
        {
            IsActive = false;
        }
    }
}
