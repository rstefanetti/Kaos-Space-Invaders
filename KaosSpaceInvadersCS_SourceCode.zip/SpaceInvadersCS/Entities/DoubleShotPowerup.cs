using System;

namespace SpaceInvaders.Entities;

// Double shot powerup that falls and enables parallel shooting
public class DoubleShotPowerup : SpaceInvaders.Entity
{
    private float _fallSpeed = 0.6f;
    public float GlowPhase { get; private set; }
    
    public DoubleShotPowerup(int x, int y) : base(x, y, EntityType.Powerup)
    {
        GlowPhase = 0;
    }
    
    public override void Update()
    {
        if (!IsActive) return;
        
        // Fall down
        Y += (int)_fallSpeed;
        
        // Glow animation
        GlowPhase += 0.15f;
        if (GlowPhase > Math.PI * 2) GlowPhase -= (float)(Math.PI * 2);
        
        // Deactivate when off screen
        if (Y > 36)
        {
            IsActive = false;
        }
    }
    
    public override char GetSprite(int frame)
    {
        return '◈'; // Double diamond
    }
}
