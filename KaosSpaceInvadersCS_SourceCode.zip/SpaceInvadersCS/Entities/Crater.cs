namespace SpaceInvaders;

using System.Drawing;

/// <summary>
/// Cratere creato dall'impatto di un asteroide
/// </summary>
public class Crater
{
    public int X { get; set; }
    public int Y { get; set; }
    public int Size { get; set; }
    public int Duration { get; set; }
    public int MaxDuration { get; private set; }
    public bool IsActive => Duration > 0;
    public Color CraterColor { get; set; }
    private int _smokeTimer;
    private readonly Random _random;
    
    public event Action<float, float>? OnSmokeEmit; // Evento per emettere fumo (x, y)
    
    public Crater(int x, int y, int size, int duration = 300)
    {
        X = x;
        Y = y;
        Size = size;
        Duration = duration;
        MaxDuration = duration;
        CraterColor = Color.FromArgb(80, 40, 30); // Marrone scuro
        _smokeTimer = 0;
        _random = new Random();
    }
    
    public void Update()
    {
        if (Duration > 0)
        {
            Duration--;
            
            // Emetti fumo ogni 5 frames per i primi 300 frames (10 secondi)
            if (Duration > MaxDuration - 300)
            {
                _smokeTimer++;
                if (_smokeTimer >= 5)
                {
                    _smokeTimer = 0;
                    // Emetti fumo con leggera variazione di posizione
                    float offsetX = (float)(_random.NextDouble() - 0.5) * Size;
                    OnSmokeEmit?.Invoke(X + offsetX, Y);
                }
            }
        }
    }
    
    /// <summary>
    /// Opacità del cratere che diminuisce nel tempo
    /// </summary>
    public float GetOpacity()
    {
        return (float)Duration / MaxDuration;
    }
}
