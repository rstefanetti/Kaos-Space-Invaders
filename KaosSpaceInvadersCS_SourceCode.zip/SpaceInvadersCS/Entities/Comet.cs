namespace SpaceInvaders;

public class Comet : Entity
{
    private readonly int _speedX;
    private readonly int _speedY;
    public int TailLength { get; private set; }
    
    public Comet(int x, int y, int speedX, int speedY) : base(x, y, EntityType.Comet)
    {
        _speedX = speedX;
        _speedY = speedY;
        TailLength = 5 + new Random().Next(5); // 5-10 particelle di coda
    }
    
    public override char GetSprite(int frame)
    {
        return '☄'; // Stella cometa
    }
    
    public override void Update()
    {
        X += _speedX;
        Y += _speedY;
        
        // Disattiva se esce dallo schermo
        if (X < 0 || X > 100 || Y < 0 || Y > 36)
        {
            IsActive = false;
        }
    }
}
