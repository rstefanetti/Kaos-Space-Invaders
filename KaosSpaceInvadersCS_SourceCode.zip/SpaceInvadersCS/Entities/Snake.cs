namespace SpaceInvaders;

public class Snake : Entity
{
    private List<(int X, int Y)> _bodySegments;
    private int _moveTimer;
    private int _currentPathIndex;
    private List<(int X, int Y)> _path;
    private const int MoveDelay = 2; // Muove ogni 2 frames
    private const int SegmentCount = 15; // Lunghezza serpente
    public const int PointValue = 1000;
    private int _playerX;
    private int _playerY;
    
    public IEnumerable<(int X, int Y)> BodySegments => _bodySegments;
    
    public Snake(int startX, int startY, int playerX, int playerY) : base(startX, startY, EntityType.Snake)
    {
        _bodySegments = new List<(int X, int Y)>();
        _bodySegments.Add((startX, startY));
        _moveTimer = 0;
        _currentPathIndex = 0;
        _playerX = playerX;
        _playerY = playerY;
        _path = GeneratePath(startX, startY, playerX, playerY);
    }
    
    private List<(int X, int Y)> GeneratePath(int startX, int startY, int targetX, int targetY)
    {
        // Crea un percorso che scende, si avvicina alla nave e fa un giro attorno
        var path = new List<(int X, int Y)>();
        
        // Fase 1: Scendi verso la nave (dall'alto verso il basso)
        int currentX = startX;
        int currentY = startY;
        
        while (currentY < targetY - 5)
        {
            currentY++;
            path.Add((currentX, currentY));
        }
        
        // Fase 2: Avvicinati orizzontalmente alla nave
        int direction = currentX < targetX ? 1 : -1;
        while (Math.Abs(currentX - targetX) > 8)
        {
            currentX += direction;
            path.Add((currentX, currentY));
        }
        
        // Fase 3: Giro attorno alla nave (circolare)
        // Centro del cerchio: posizione nave
        int radius = 8;
        double angleStep = Math.PI / 16; // 32 punti per il cerchio completo
        
        for (double angle = 0; angle < Math.PI * 2; angle += angleStep)
        {
            int circleX = targetX + (int)(Math.Cos(angle) * radius);
            int circleY = targetY + (int)(Math.Sin(angle) * radius);
            path.Add((circleX, circleY));
        }
        
        // Fase 4: Risali e esci dallo schermo
        currentX = path[path.Count - 1].X;
        currentY = path[path.Count - 1].Y;
        
        while (currentY > -5)
        {
            currentY--;
            path.Add((currentX, currentY));
        }
        
        return path;
    }
    
    public override char GetSprite(int frame) => '~';
    
    public override void Update()
    {
        _moveTimer++;
        
        if (_moveTimer >= MoveDelay)
        {
            _moveTimer = 0;
            
            // Muovi il serpente lungo il percorso
            if (_currentPathIndex < _path.Count)
            {
                var nextPos = _path[_currentPathIndex];
                _currentPathIndex++;
                
                // Aggiungi la nuova posizione della testa
                _bodySegments.Insert(0, nextPos);
                
                // Mantieni la lunghezza del serpente costante
                if (_bodySegments.Count > SegmentCount)
                {
                    _bodySegments.RemoveAt(_bodySegments.Count - 1);
                }
                
                // Aggiorna la posizione dell'entità (testa)
                X = nextPos.X;
                Y = nextPos.Y;
            }
            else
            {
                // Percorso completato, disattiva il serpente
                IsActive = false;
            }
        }
    }
    
    public bool CollidesWith(Bullet bullet)
    {
        // Controlla collisione con qualsiasi segmento del corpo
        foreach (var segment in _bodySegments)
        {
            if (Math.Abs(segment.X - bullet.X) <= 1 && Math.Abs(segment.Y - bullet.Y) <= 1)
            {
                return true;
            }
        }
        return false;
    }
    
    public void Draw(Graphics g)
    {
        if (!IsActive) return;
        
        // Abilita anti-aliasing per un aspetto migliore
        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        
        // Disegna il corpo del serpente (segmenti verdi)
        using var bodyBrush = new SolidBrush(Color.FromArgb(0, 200, 0));
        using var bodyPen = new Pen(Color.FromArgb(0, 150, 0), 2);
        
        // Disegna i segmenti del corpo
        for (int i = _bodySegments.Count - 1; i > 0; i--)
        {
            var segment = _bodySegments[i];
            int screenX = segment.X * 8;
            int screenY = segment.Y * 15;
            
            // Disegna un cerchio per ogni segmento
            g.FillEllipse(bodyBrush, screenX - 6, screenY - 6, 12, 12);
            g.DrawEllipse(bodyPen, screenX - 6, screenY - 6, 12, 12);
            
            // Disegna linea di connessione al segmento precedente
            if (i < _bodySegments.Count - 1)
            {
                var prevSegment = _bodySegments[i + 1];
                int prevScreenX = prevSegment.X * 8;
                int prevScreenY = prevSegment.Y * 15;
                
                using var connectPen = new Pen(Color.FromArgb(0, 180, 0), 4);
                g.DrawLine(connectPen, screenX, screenY, prevScreenX, prevScreenY);
            }
        }
        
        // Disegna la testa (più grande e con occhi)
        if (_bodySegments.Count > 0)
        {
            var head = _bodySegments[0];
            int headScreenX = head.X * 8;
            int headScreenY = head.Y * 15;
            
            // Testa più grande
            using var headBrush = new SolidBrush(Color.FromArgb(100, 255, 100));
            g.FillEllipse(headBrush, headScreenX - 8, headScreenY - 8, 16, 16);
            g.DrawEllipse(bodyPen, headScreenX - 8, headScreenY - 8, 16, 16);
            
            // Occhi gialli
            using var eyeBrush = new SolidBrush(Color.Yellow);
            g.FillEllipse(eyeBrush, headScreenX - 4, headScreenY - 3, 3, 3);
            g.FillEllipse(eyeBrush, headScreenX + 1, headScreenY - 3, 3, 3);
            
            // Pupille nere
            using var pupilBrush = new SolidBrush(Color.Black);
            g.FillEllipse(pupilBrush, headScreenX - 3, headScreenY - 2, 2, 2);
            g.FillEllipse(pupilBrush, headScreenX + 2, headScreenY - 2, 2, 2);
            
            // Lingua rossa biforcuta (animata)
            double tonguePhase = Math.Sin(_moveTimer * 0.2);
            int tongueLength = 6 + (int)(tonguePhase * 2);
            using var tonguePen = new Pen(Color.Red, 2);
            g.DrawLine(tonguePen, headScreenX, headScreenY + 4, headScreenX - 2, headScreenY + 4 + tongueLength);
            g.DrawLine(tonguePen, headScreenX, headScreenY + 4, headScreenX + 2, headScreenY + 4 + tongueLength);
        }
        
        // Ripristina smoothing mode
        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.Default;
    }
}
