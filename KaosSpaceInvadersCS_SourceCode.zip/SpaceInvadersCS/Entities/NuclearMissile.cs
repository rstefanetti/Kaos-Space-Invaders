using System;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace SpaceInvaders.Entities;

/// <summary>
/// Missile nucleare che cade dal cielo e crea un fungo atomico radioattivo.
/// </summary>
public class NuclearMissile : Entity
{
    public float FloatY { get; set; }
    public float VelocityY { get; set; }
    public bool HasExploded { get; private set; }
    private int _trailFrame;
    
    public NuclearMissile(int x, int startY = 0) : base(x, startY, EntityType.AlienBullet)
    {
        FloatY = startY;
        VelocityY = 2.5f; // Velocità di caduta
        HasExploded = false;
        _trailFrame = 0;
    }
    
    public override void Update()
    {
        if (!IsActive) return;
        
        if (!HasExploded)
        {
            FloatY += VelocityY;
            Y = (int)FloatY;
            _trailFrame++;
            
            // Accelera mentre cade
            VelocityY += 0.05f;
            
            // Esplode quando tocca il suolo (Y >= 34)
            if (Y >= 34)
            {
                HasExploded = true;
            }
        }
    }
    
    public override char GetSprite(int frame) => '☢'; // Missile nucleare sprite
    
    public void Draw(Graphics g, int screenWidth, int screenHeight)
    {
        if (!IsActive || HasExploded) return;
        
        int screenX = X * (screenWidth / 100);
        int screenY = (int)(FloatY * (screenHeight / 36f));
        
        g.SmoothingMode = SmoothingMode.AntiAlias;
        
        // Scia di fumo dietro al missile
        for (int i = 0; i < 5; i++)
        {
            int trailY = screenY - i * 15;
            int alpha = 150 - i * 30;
            int trailSize = 8 + i * 2;
            
            using (var smokeBrush = new SolidBrush(Color.FromArgb(alpha, 100, 100, 100)))
            {
                g.FillEllipse(smokeBrush, screenX - trailSize / 2, trailY - trailSize / 2, trailSize, trailSize);
            }
        }
        
        // Corpo del missile (forma allungata)
        using (var missileBrush = new LinearGradientBrush(
            new Rectangle(screenX - 8, screenY - 25, 16, 30),
            Color.FromArgb(255, 150, 150, 150), // Grigio metallico
            Color.FromArgb(255, 80, 80, 80),    // Grigio scuro
            LinearGradientMode.Vertical))
        {
            g.FillRectangle(missileBrush, screenX - 6, screenY - 20, 12, 25);
        }
        
        // Punta del missile (triangolo)
        Point[] tip = new Point[]
        {
            new Point(screenX, screenY - 30),
            new Point(screenX - 6, screenY - 20),
            new Point(screenX + 6, screenY - 20)
        };
        
        using (var tipBrush = new SolidBrush(Color.FromArgb(255, 180, 0, 0))) // Rosso
        {
            g.FillPolygon(tipBrush, tip);
        }
        
        // Alette stabilizzatrici
        Point[] fin1 = new Point[]
        {
            new Point(screenX - 6, screenY - 5),
            new Point(screenX - 12, screenY + 5),
            new Point(screenX - 6, screenY + 5)
        };
        
        Point[] fin2 = new Point[]
        {
            new Point(screenX + 6, screenY - 5),
            new Point(screenX + 12, screenY + 5),
            new Point(screenX + 6, screenY + 5)
        };
        
        using (var finBrush = new SolidBrush(Color.FromArgb(255, 100, 100, 100)))
        {
            g.FillPolygon(finBrush, fin1);
            g.FillPolygon(finBrush, fin2);
        }
        
        // Simbolo radioattivo sulla punta
        using (var symbolBrush = new SolidBrush(Color.Yellow))
        using (var font = new Font("Arial", 8, FontStyle.Bold))
        {
            g.DrawString("☢", font, symbolBrush, screenX - 6, screenY - 18);
        }
        
        // Fiamme dal motore
        int flameLength = 10 + (int)(Math.Sin(_trailFrame * 0.3f) * 5);
        using (var flameBrush = new LinearGradientBrush(
            new Rectangle(screenX - 5, screenY + 5, 10, flameLength),
            Color.FromArgb(255, 255, 200, 0),  // Giallo
            Color.FromArgb(0, 255, 0, 0),      // Rosso trasparente
            LinearGradientMode.Vertical))
        {
            g.FillEllipse(flameBrush, screenX - 5, screenY + 5, 10, flameLength);
        }
    }
}
