using System;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace SpaceInvaders.Entities;

/// <summary>
/// Fungo atomico radioattivo creato dall'esplosione di un missile nucleare.
/// Emette radiazioni che danneggiano il giocatore se non ha lo scudo attivo.
/// </summary>
public class RadioactiveMushroom : Entity
{
    public int Lifetime { get; private set; }
    public int MaxLifetime { get; } = 300; // 10 secondi
    public int RadiationRadius { get; private set; }
    private int _animationFrame;
    private float _pulsePhase;
    private Random _random;
    
    public RadioactiveMushroom(int x, int y) : base(x, y, EntityType.None)
    {
        Lifetime = MaxLifetime;
        RadiationRadius = 80; // Raggio delle radiazioni in pixel
        _animationFrame = 0;
        _pulsePhase = 0;
        _random = new Random(x + y + Environment.TickCount);
    }
    
    public override void Update()
    {
        if (!IsActive) return;
        
        Lifetime--;
        if (Lifetime <= 0)
        {
            IsActive = false;
        }
        
        _animationFrame++;
        _pulsePhase += 0.1f;
    }
    
    public override char GetSprite(int frame) => '☢'; // Fungo radioattivo sprite
    
    public bool IsPlayerInRadiation(int playerX, int playerY, int screenWidth, int screenHeight)
    {
        if (!IsActive) return false;
        
        int mushroomScreenX = X * (screenWidth / 100);
        int mushroomScreenY = Y * (screenHeight / 36);
        int playerScreenX = playerX * (screenWidth / 100);
        int playerScreenY = playerY * (screenHeight / 36);
        
        int distanceX = playerScreenX - mushroomScreenX;
        int distanceY = playerScreenY - mushroomScreenY;
        int distance = (int)Math.Sqrt(distanceX * distanceX + distanceY * distanceY);
        
        return distance <= RadiationRadius;
    }
    
    public void Draw(Graphics g, int screenWidth, int screenHeight)
    {
        if (!IsActive) return;
        
        int screenX = X * (screenWidth / 100);
        int screenY = Y * (screenHeight / 36);
        
        g.SmoothingMode = SmoothingMode.AntiAlias;
        
        // Opacità che diminuisce con il tempo
        float opacity = (float)Lifetime / MaxLifetime;
        int baseAlpha = (int)(255 * opacity);
        
        // Alone radioattivo verde pulsante
        float pulseScale = 1.0f + (float)Math.Sin(_pulsePhase) * 0.2f;
        int glowRadius = (int)(RadiationRadius * pulseScale);
        
        using (var glowPath = new GraphicsPath())
        {
            glowPath.AddEllipse(screenX - glowRadius, screenY - glowRadius, glowRadius * 2, glowRadius * 2);
            using (var glowBrush = new PathGradientBrush(glowPath))
            {
                glowBrush.CenterColor = Color.FromArgb(Math.Min(150, baseAlpha), 0, 255, 0); // Verde radioattivo
                glowBrush.SurroundColors = new[] { Color.FromArgb(0, 0, 255, 0) };
                g.FillPath(glowBrush, glowPath);
            }
        }
        
        // Particelle radioattive che fluttuano
        for (int i = 0; i < 20; i++)
        {
            float angle = (i * 18 + _animationFrame * 2) % 360;
            float radius = _random.Next(20, RadiationRadius);
            float verticalOffset = (float)Math.Sin(_animationFrame * 0.05f + i) * 10;
            
            int particleX = screenX + (int)(Math.Cos(angle * Math.PI / 180) * radius);
            int particleY = screenY + (int)(Math.Sin(angle * Math.PI / 180) * radius) + (int)verticalOffset;
            
            int particleAlpha = Math.Min(200, baseAlpha);
            using (var particleBrush = new SolidBrush(Color.FromArgb(particleAlpha, 0, 255, 0)))
            {
                int particleSize = 3 + _random.Next(3);
                g.FillEllipse(particleBrush, particleX - particleSize / 2, particleY - particleSize / 2, 
                    particleSize, particleSize);
            }
        }
        
        // Stelo del fungo (colonna di fumo)
        int stemWidth = 20;
        int stemHeight = 40;
        
        using (var stemBrush = new LinearGradientBrush(
            new Rectangle(screenX - stemWidth / 2, screenY - stemHeight, stemWidth, stemHeight),
            Color.FromArgb(Math.Min(200, baseAlpha), 100, 100, 100), // Grigio
            Color.FromArgb(Math.Min(150, baseAlpha), 50, 50, 50),    // Grigio scuro
            LinearGradientMode.Vertical))
        {
            g.FillRectangle(stemBrush, screenX - stemWidth / 2, screenY - stemHeight, stemWidth, stemHeight);
        }
        
        // Cappello del fungo (nuvola tonda)
        int capWidth = 50;
        int capHeight = 30;
        
        using (var capBrush = new LinearGradientBrush(
            new Rectangle(screenX - capWidth / 2, screenY - stemHeight - capHeight, capWidth, capHeight),
            Color.FromArgb(Math.Min(220, baseAlpha), 150, 150, 100), // Giallo sporco
            Color.FromArgb(Math.Min(180, baseAlpha), 100, 80, 50),   // Marrone
            LinearGradientMode.Vertical))
        {
            g.FillEllipse(capBrush, screenX - capWidth / 2, screenY - stemHeight - capHeight, capWidth, capHeight);
        }
        
        // Bordo del cappello
        using (var capPen = new Pen(Color.FromArgb(Math.Min(200, baseAlpha), 200, 150, 0), 2))
        {
            g.DrawEllipse(capPen, screenX - capWidth / 2, screenY - stemHeight - capHeight, capWidth, capHeight);
        }
        
        // Simbolo radioattivo sul fungo
        using (var symbolFont = new Font("Arial", 16, FontStyle.Bold))
        using (var symbolBrush = new SolidBrush(Color.FromArgb(Math.Min(255, baseAlpha), 0, 255, 0)))
        using (var symbolShadow = new SolidBrush(Color.FromArgb(Math.Min(150, baseAlpha), 0, 0, 0)))
        {
            string symbol = "☢";
            SizeF symbolSize = g.MeasureString(symbol, symbolFont);
            g.DrawString(symbol, symbolFont, symbolShadow, 
                screenX - symbolSize.Width / 2 + 1, screenY - stemHeight - capHeight + 6);
            g.DrawString(symbol, symbolFont, symbolBrush, 
                screenX - symbolSize.Width / 2, screenY - stemHeight - capHeight + 5);
        }
        
        // Fumo che sale dalla cima
        for (int i = 0; i < 5; i++)
        {
            int smokeY = screenY - stemHeight - capHeight - i * 10 - (_animationFrame % 30);
            int smokeSize = 8 + i * 3;
            int smokeAlpha = Math.Min(100 - i * 15, baseAlpha / 2);
            
            if (smokeAlpha > 0)
            {
                using (var smokeBrush = new SolidBrush(Color.FromArgb(smokeAlpha, 80, 80, 60)))
                {
                    g.FillEllipse(smokeBrush, screenX - smokeSize / 2, smokeY, smokeSize, smokeSize);
                }
            }
        }
        
        // Testo avviso "RADIAZIONI!"
        if (Lifetime > 60) // Mostra solo i primi secondi
        {
            using (var warnFont = new Font("Arial", 10, FontStyle.Bold))
            using (var warnBrush = new SolidBrush(Color.FromArgb(Math.Min(255, baseAlpha), 255, 0, 0)))
            using (var warnShadow = new SolidBrush(Color.FromArgb(Math.Min(200, baseAlpha), 0, 0, 0)))
            {
                string warning = "RADIAZIONI!";
                SizeF warnSize = g.MeasureString(warning, warnFont);
                
                // Oscillazione verticale
                float warnY = screenY - stemHeight - capHeight - 30 + (float)Math.Sin(_pulsePhase * 2) * 5;
                
                g.DrawString(warning, warnFont, warnShadow, 
                    screenX - warnSize.Width / 2 + 1, warnY + 1);
                g.DrawString(warning, warnFont, warnBrush, 
                    screenX - warnSize.Width / 2, warnY);
            }
        }
    }
}
