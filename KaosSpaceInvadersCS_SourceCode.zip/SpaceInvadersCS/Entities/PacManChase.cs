using System.Drawing;
using System.Drawing.Drawing2D;

namespace SpaceInvaders.Entities;

/// <summary>
/// Pac-Man inseguito da un fantasmino che scende dallo schermo
/// Appare dopo aver ucciso un serpente
/// </summary>
public class PacManChase : Entity
{
    private int _ghostX;
    private int _ghostY;
    private float _pacmanMouthAngle;
    private int _animationFrame;
    private bool _ghostAlive;
    private bool _celebrating;
    private int _celebrationTimer;
    private int _messageTimer;
    private const int CelebrationDuration = 90; // 3 secondi
    private const int DescentSpeed = 1;
    
    public bool GhostAlive => _ghostAlive;
    public bool IsCelebrating => _celebrating;
    public bool ShouldRemove => _messageTimer <= 0 && _celebrating;
    
    public PacManChase(int startX, int startY) : base(startX, startY, EntityType.UFO) // Usa UFO come tipo generico
    {
        // Pac-Man parte davanti
        X = startX;
        Y = startY;
        
        // Fantasmino parte dietro
        _ghostX = startX - 10; // 10 unità dietro
        _ghostY = startY;
        
        _ghostAlive = true;
        _celebrating = false;
        _pacmanMouthAngle = 0;
        _animationFrame = 0;
        _celebrationTimer = 0;
        _messageTimer = 0;
    }
    
    public override void Update()
    {
        if (!IsActive) return;
        
        _animationFrame++;
        
        if (_celebrating)
        {
            // Pac-Man festeggia (salta su e giù)
            _celebrationTimer++;
            _messageTimer++;
            
            if (_celebrationTimer >= CelebrationDuration)
            {
                IsActive = false; // Scompare
            }
            return;
        }
        
        // Movimento verso il basso
        Y += DescentSpeed;
        if (_ghostAlive)
        {
            _ghostY += DescentSpeed;
        }
        
        // Animazione bocca Pac-Man
        _pacmanMouthAngle = (float)(Math.Sin(_animationFrame * 0.2) * 30);
        
        // Disattiva se esce dallo schermo
        if (Y > 40) // 40 unità = fuori schermo
        {
            IsActive = false;
        }
    }
    
    public void KillGhost()
    {
        if (_ghostAlive)
        {
            _ghostAlive = false;
            _celebrating = true;
            _celebrationTimer = 0;
            _messageTimer = 0;
        }
    }
    
    public bool IsGhostHit(int bulletX, int bulletY)
    {
        if (!_ghostAlive) return false;
        
        // Controlla collisione con fantasmino (circa 3x3 unità)
        int ghostScreenX = _ghostX * 8;
        int ghostScreenY = _ghostY * 15;
        int bulletScreenX = bulletX * 8;
        int bulletScreenY = bulletY * 15;
        
        return Math.Abs(ghostScreenX - bulletScreenX) < 20 &&
               Math.Abs(ghostScreenY - bulletScreenY) < 20;
    }
    
    public void Draw(Graphics g, int offsetX, int offsetY)
    {
        if (!IsActive) return;
        
        int pacmanScreenX = X * 8 + offsetX;
        int pacmanScreenY = Y * 15 + offsetY;
        
        // Disegna fantasmino se vivo
        if (_ghostAlive)
        {
            int ghostScreenX = _ghostX * 8 + offsetX;
            int ghostScreenY = _ghostY * 15 + offsetY;
            DrawGhost(g, ghostScreenX, ghostScreenY);
        }
        
        // Disegna Pac-Man
        if (_celebrating)
        {
            DrawCelebratingPacman(g, pacmanScreenX, pacmanScreenY);
        }
        else
        {
            DrawPacman(g, pacmanScreenX, pacmanScreenY);
        }
    }
    
    private void DrawPacman(Graphics g, int screenX, int screenY)
    {
        g.SmoothingMode = SmoothingMode.AntiAlias;
        
        // Corpo giallo di Pac-Man
        using (var pacmanBrush = new SolidBrush(Color.Yellow))
        {
            // Calcola angoli per la bocca aperta/chiusa
            float startAngle = 45 + _pacmanMouthAngle;
            float sweepAngle = 360 - (_pacmanMouthAngle * 2) - 90;
            
            g.FillPie(pacmanBrush, screenX - 12, screenY - 12, 24, 24, startAngle, sweepAngle);
        }
        
        // Bordo arancione
        using (var borderPen = new Pen(Color.Orange, 2))
        {
            float startAngle = 45 + _pacmanMouthAngle;
            float sweepAngle = 360 - (_pacmanMouthAngle * 2) - 90;
            g.DrawPie(borderPen, screenX - 12, screenY - 12, 24, 24, startAngle, sweepAngle);
        }
        
        // Occhio
        using (var eyeBrush = new SolidBrush(Color.Black))
        {
            g.FillEllipse(eyeBrush, screenX - 4, screenY - 8, 4, 4);
        }
    }
    
    private void DrawCelebratingPacman(Graphics g, int screenX, int screenY)
    {
        g.SmoothingMode = SmoothingMode.AntiAlias;
        
        // Pac-Man salta su e giù
        int bounceOffset = (int)(Math.Sin(_celebrationTimer * 0.3) * 5);
        screenY += bounceOffset;
        
        // Pac-Man felice (bocca chiusa, smile)
        using (var pacmanBrush = new SolidBrush(Color.Yellow))
        {
            g.FillEllipse(pacmanBrush, screenX - 14, screenY - 14, 28, 28);
        }
        
        using (var borderPen = new Pen(Color.Orange, 2))
        {
            g.DrawEllipse(borderPen, screenX - 14, screenY - 14, 28, 28);
        }
        
        // Occhi felici (^_^)
        using (var eyeBrush = new SolidBrush(Color.Black))
        {
            // Occhio sinistro (arco)
            g.DrawArc(new Pen(Color.Black, 2), screenX - 8, screenY - 6, 6, 6, 0, 180);
            // Occhio destro (arco)
            g.DrawArc(new Pen(Color.Black, 2), screenX + 2, screenY - 6, 6, 6, 0, 180);
        }
        
        // Bocca sorridente
        using (var smilePen = new Pen(Color.Black, 2))
        {
            g.DrawArc(smilePen, screenX - 8, screenY, 16, 10, 180, 180);
        }
        
        // Stella di gioia sopra la testa
        DrawStar(g, screenX, screenY - 25, 8, Color.Gold);
    }
    
    private void DrawGhost(Graphics g, int screenX, int screenY)
    {
        g.SmoothingMode = SmoothingMode.AntiAlias;
        
        // Colore fantasmino (rosso/rosa tipo Blinky)
        Color ghostColor = Color.FromArgb(255, 100, 100);
        
        // Corpo del fantasmino
        using (var ghostBrush = new SolidBrush(ghostColor))
        {
            // Testa rotonda
            g.FillEllipse(ghostBrush, screenX - 10, screenY - 10, 20, 20);
            
            // Corpo con ondulazioni alla base
            Point[] bodyPoints = new Point[]
            {
                new Point(screenX - 10, screenY),
                new Point(screenX - 10, screenY + 10),
                new Point(screenX - 7, screenY + 13),
                new Point(screenX - 3, screenY + 10),
                new Point(screenX + 0, screenY + 13),
                new Point(screenX + 3, screenY + 10),
                new Point(screenX + 7, screenY + 13),
                new Point(screenX + 10, screenY + 10),
                new Point(screenX + 10, screenY)
            };
            g.FillPolygon(ghostBrush, bodyPoints);
        }
        
        // Occhi bianchi
        using (var eyeWhiteBrush = new SolidBrush(Color.White))
        {
            g.FillEllipse(eyeWhiteBrush, screenX - 7, screenY - 5, 6, 8);
            g.FillEllipse(eyeWhiteBrush, screenX + 1, screenY - 5, 6, 8);
        }
        
        // Pupille nere (guardano Pac-Man)
        using (var pupilBrush = new SolidBrush(Color.Blue))
        {
            g.FillEllipse(pupilBrush, screenX - 5, screenY - 2, 3, 3);
            g.FillEllipse(pupilBrush, screenX + 3, screenY - 2, 3, 3);
        }
    }
    
    private void DrawStar(Graphics g, int centerX, int centerY, int size, Color color)
    {
        Point[] starPoints = new Point[10];
        double angle = -Math.PI / 2; // Start from top
        
        for (int i = 0; i < 10; i++)
        {
            double radius = (i % 2 == 0) ? size : size / 2.0;
            starPoints[i] = new Point(
                (int)(centerX + radius * Math.Cos(angle)),
                (int)(centerY + radius * Math.Sin(angle))
            );
            angle += Math.PI / 5;
        }
        
        using (var starBrush = new SolidBrush(color))
        {
            g.FillPolygon(starBrush, starPoints);
        }
    }
    
    public string GetThankYouMessage()
    {
        return "Mi hai salvato Bob!";
    }
    
    public override char GetSprite(int animationFrame)
    {
        // Non usato per PacManChase (rendering custom)
        return ' ';
    }
}
