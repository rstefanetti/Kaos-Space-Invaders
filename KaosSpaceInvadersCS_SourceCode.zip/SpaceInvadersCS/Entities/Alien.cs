namespace SpaceInvaders;

public class Alien : Entity
{
    private static readonly Random _random = new();
    public int PointValue { get; private set; }
    public int AnimationFrame { get; set; }
    
    // Flying behavior
    public bool IsFlying { get; private set; }
    private float _originalX;
    private float _originalY;
    private float _flyingTimer;
    private float _flyAngle;
    private const float FlyDuration = 120f; // 4 seconds at 30 FPS
    private const float FlyRadius = 3f;
    
    public Alien(int x, int y, EntityType type) : base(x, y, type)
    {
        PointValue = type switch
        {
            EntityType.AlienType1 => 50,
            EntityType.AlienType2 => 30,
            EntityType.AlienType3 => 20,
            _ => 10
        };
        AnimationFrame = 0;
        IsFlying = false;
        _flyingTimer = 0;
        _flyAngle = 0;
    }
    
    public override char GetSprite(int frame)
    {
        return Type switch
        {
            EntityType.AlienType1 => frame % 2 == 0 ? '▼' : '▽',
            EntityType.AlienType2 => frame % 2 == 0 ? '◆' : '◇',
            EntityType.AlienType3 => frame % 2 == 0 ? '●' : '○',
            _ => '?'
        };
    }
    
    public override void Update()
    {
        // Update flying behavior
        if (IsFlying)
        {
            _flyingTimer++;
            
            if (_flyingTimer >= FlyDuration)
            {
                // Return to original position
                IsFlying = false;
                X = (int)_originalX;
                Y = (int)_originalY;
                _flyingTimer = 0;
            }
            else
            {
                // Fly in circular pattern
                _flyAngle += 0.1f;
                float offsetX = (float)Math.Cos(_flyAngle) * FlyRadius;
                float offsetY = (float)Math.Sin(_flyAngle) * FlyRadius;
                X = (int)(_originalX + offsetX);
                Y = (int)(_originalY + offsetY);
            }
        }
        
        // 1% chance to start flying (only if not already flying)
        if (!IsFlying && _random.Next(0, 3000) < 1)
        {
            StartFlying();
        }
    }
    
    public void StartFlying()
    {
        if (!IsFlying)
        {
            IsFlying = true;
            _originalX = X;
            _originalY = Y;
            _flyingTimer = 0;
            _flyAngle = (float)(_random.NextDouble() * Math.PI * 2);
        }
    }
    
    public bool ShouldShoot()
    {
        return _random.Next(0, 200) < 1; // 0.5% chance per frame (ridotto ulteriormente)
    }
    
    public Bullet Shoot()
    {
        return new Bullet(X, Y + 1, EntityType.AlienBullet, 1);
    }
}
